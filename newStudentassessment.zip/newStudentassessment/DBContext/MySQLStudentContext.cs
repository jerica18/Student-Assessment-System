﻿using MySql.Data.MySqlClient;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace newStudentassessment.DBContext
{
    public class MySQLStudentContext : IStudent
    {
        private string _constr = Helpers.MYSqlHelpers.GetConnectionString();

        public void StudentRemove(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("DeleteStudent", conn))
                {
                    cmd.CommandType= CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_studentID", id);

                    conn.Open();
                    cmd.ExecuteNonQuery();

                    
                    conn.Close();
                }
            }
        }

        public Student GetByID(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("prcSearchStudentByID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_studentID", id);
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read()) return null;

                        Student student = new Student()
                        {
                            studentid = Convert.ToInt32(reader["student_id"]),
                            User_name = reader["user_name"].ToString(),
                            User_password = reader["user_password"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            MiddleName = reader["MiddleName"].ToString(),
                            FirstName = reader["FirstName"].ToString(),
                            Contact_number = reader["contact_number"].ToString(),
                            Email = reader["email"].ToString()
                        };
                        student.setAccountID(Convert.ToInt32(reader["account_id"]));
                        conn.Close();
                        return student;
                    }
                }
            }
        }

        public Student GetbyLname( string lname)
        {
           
            using (MySqlConnection conn = new MySqlConnection (_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand ("prcSearchStudentBylname", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Lname", lname);
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader ())
                    {
                        if (!reader.Read()) return null;
                        {
                            Student student = new Student()
                            {
                                studentid = Convert.ToInt32(reader["student_id"]),
                                User_name = reader["user_name"].ToString(),
                                User_password = reader["user_password"].ToString(),
                                LastName = reader["LastName"].ToString(),
                                MiddleName = reader["MiddleName"].ToString(),
                                FirstName = reader["FirstName"].ToString(),
                                Contact_number = reader["contact_number"].ToString(),
                                Email = reader["email"].ToString()
                            };
                            student.setAccountID(Convert.ToInt32(reader["account_id"]));
                            conn.Close();
                            return student;
                            
                        }
                        
                    }

                }
            }
            
        }

        public List<Student> GetStudentList()
        {
            List<Student> studentlist = new List<Student>();

            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("prcStudentlist", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open ();

                    using (MySqlDataReader reader = cmd.ExecuteReader ())
                    {
                        while (reader.Read())
                        {
                            Student student = new Student()
                            {
                                studentid = Convert.ToInt32(reader["student_id"]),
                                User_name = reader["user_name"].ToString(),
                                User_password = reader["user_password"].ToString(),
                                LastName = reader["LastName"].ToString(),
                                MiddleName = reader["MiddleName"].ToString(),
                                FirstName = reader["FirstName"].ToString(),
                                Contact_number = reader["contact_number"].ToString(),
                                Email = reader["email"].ToString()

                            };
                            student.setAccountID(Convert.ToInt32(reader["account_id"]));
                            studentlist.Add(student);
                        }
                    }
                    conn.Close();
                }
            }
            return studentlist;
        }

        public void Updatestudent(Student e)
        {
                using (MySqlConnection conn = new MySqlConnection(_constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand("UpdateStudent", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("sp_studentID", e.studentid);
                        cmd.Parameters.AddWithValue("sp_accountID", e.accountID);
                        cmd.Parameters.AddWithValue("sp_lname", e.LastName);
                        cmd.Parameters.AddWithValue("sp_mname", e.MiddleName);
                        cmd.Parameters.AddWithValue("sp_fname", e.FirstName);
                        cmd.Parameters.AddWithValue("sp_contact", e.Contact_number);
                        cmd.Parameters.AddWithValue("sp_email", e.Email);

                        conn.Open();
                        cmd.ExecuteNonQuery();

                        
                        conn.Close();
                    }
                }
           
        }
    }
}
