﻿using MySql.Data.MySqlClient;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.DBContext
{
    public class MySQLAssignmentContext : IAssignment
    {
        private string _constr = Helpers.MYSqlHelpers.GetConnectionString();
        public List<Assignment> GetAssignmentList()
        {
            List<Assignment> AssignList = new List<Assignment>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("getAssignmentList", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Assignment assignment = new Assignment()
                            {
                                Assignment_ID = Convert.ToInt32(reader["assignment_id"]),
                                TeacherId = reader["employee_id"] != DBNull.Value
                                ? (int?)Convert.ToInt32(reader["employee_id"])
                                : null,
                                term_id = Convert.ToInt32(reader["term_id"]),
                                SubjectID = Convert.ToInt32(reader["subject_id"]),
                                Assignment_Schedule = reader["assignment_schedule"].ToString(),
                                Start_time = reader["start_time"].ToString(),
                                End_time = reader["end_time"].ToString()
                            };
                            AssignList.Add(assignment);
                        }
                    }
                }
            }
            return AssignList;
        }

        public Assignment GetByAssignmentID(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("getbyAssignmentID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_assignmentID", id);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {

                        if (!reader.Read())
                            return null;
                        Assignment assignment = new Assignment()
                        {
                            Assignment_ID = Convert.ToInt32(reader["assignment_id"]),
                            TeacherId = reader["employee_id"] != DBNull.Value
                                ? (int?)Convert.ToInt32(reader["employee_id"])
                                : null,
                            term_id = Convert.ToInt32(reader["term_id"]),
                            SubjectID = Convert.ToInt32(reader["subject_id"]),
                            Assignment_Schedule = reader["assignment_schedule"].ToString(),
                            Start_time = reader["start_time"].ToString(),
                            End_time = reader["end_time"].ToString()
                        };
                        conn.Close();
                        return assignment;
                    }
                }
            }
        }

        public List<Assignment> GetByEmpID(int id)
        {
            List<Assignment> AssignList = new List<Assignment>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("getbyEmployeeID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_empID", id);
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Assignment assignment = new Assignment()
                            {
                                Assignment_ID = Convert.ToInt32(reader["assignment_id"]),
                                TeacherId = reader["employee_id"] != DBNull.Value
                                ? (int?)Convert.ToInt32(reader["employee_id"])
                                : null,
                                term_id = Convert.ToInt32(reader["term_id"]),
                                SubjectID = Convert.ToInt32(reader["subject_id"]),
                                Assignment_Schedule = reader["assignment_schedule"].ToString(),
                                Start_time = reader["start_time"].ToString(),
                                End_time = reader["end_time"].ToString()
                            };
                            AssignList.Add(assignment);
                        }
                    }
                }
            }
            return AssignList;
        }

        public void RemoveAssignmet(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("deleteAssignment", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_assignmentID", id);

                    conn.Open();
                    cmd.ExecuteNonQuery();

                    conn.Close();
                }
            }
        }

        public void SaveAssignment(Assignment e)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("AddAssignment", conn))
                {
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("sp_employeeID", e.TeacherId);
                        cmd.Parameters.AddWithValue("sp_termID", e.term_id);
                        cmd.Parameters.AddWithValue("sp_subjectID", e.SubjectID);
                        cmd.Parameters.AddWithValue("sp_assignment_schedule", e.Assignment_Schedule);
                        cmd.Parameters.AddWithValue("sp_starttime", e.Start_time);
                        cmd.Parameters.AddWithValue("sp_endtime", e.End_time);


                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public void UpdateAssignment(Assignment e)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            using (MySqlCommand cmd = new MySqlCommand("UpdateAssignment", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("sp_assignmentID", e.Assignment_ID);
                cmd.Parameters.AddWithValue("sp_employeeID", e.TeacherId); 
                cmd.Parameters.AddWithValue("sp_termID", e.term_id); 
                cmd.Parameters.AddWithValue("sp_subjectID", e.SubjectID); 
                cmd.Parameters.AddWithValue("sp_assignment_schedule", e.Assignment_Schedule); 
                cmd.Parameters.AddWithValue("sp_starttime", e.Start_time);
                cmd.Parameters.AddWithValue("sp_endtime", e.End_time);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

    }
}
