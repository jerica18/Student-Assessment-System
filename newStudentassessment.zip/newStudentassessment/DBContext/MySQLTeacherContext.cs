﻿using MySql.Data.MySqlClient;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newStudentassessment.DBContext
{
    public class MySQLTeacherContext : ITeacher
    {
        private string _constr = Helpers.MYSqlHelpers.GetConnectionString();
        public Teacher GetbyDepartment(string dep)
        {
            throw new NotImplementedException();
        }

        public Teacher GetByID(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetTeacherByID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_empId", id);
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read()) return null;

                        Teacher teacher = new Teacher()
                        {
                            TeacherId = Convert.ToInt32(reader["employee_id"]),
                            DepartmentID = Convert.ToInt32(reader["department_id"]),
                            DepartmentName = reader["department_name"].ToString(),
                            User_name = reader["user_name"].ToString(),
                            User_password = reader["user_password"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            MiddleName = reader["MiddleName"].ToString(),
                            FirstName = reader["FirstName"].ToString(),
                            Contact_number = reader["Contact_number"].ToString(),
                            Email = reader["email"].ToString()
                        };
                        teacher.setAccountID(Convert.ToInt32(reader["account_id"]));
                        conn.Close();
                        return teacher;
                    }
                }
            }
        }

        public Teacher GetbyLname(string lname)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("prcgetteacherbylname", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Lname", lname);
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read()) return null;

                        Teacher teacher = new Teacher()
                        {
                            TeacherId = Convert.ToInt32(reader["employee_id"]),
                            DepartmentID = Convert.ToInt32(reader["department_id"]),
                            DepartmentName = reader["department_name"].ToString(),
                            User_name = reader["user_name"].ToString(),
                            User_password = reader["user_password"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            MiddleName = reader["MiddleName"].ToString(),
                            FirstName = reader["FirstName"].ToString(),
                            Contact_number = reader["Contact_number"].ToString(),
                            Email = reader["email"].ToString()
                        };
                        teacher.setAccountID(Convert.ToInt32(reader["account_id"]));
                        conn.Close();
                        return teacher;
                    }
                }
            }
        }

       



        public List<Teacher> GetTeacherList()
        {
            List<Teacher> teacherlist = new List<Teacher>();

            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("prcTeacherlist", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Teacher teacher = new Teacher()
                            {
                                TeacherId = Convert.ToInt32(reader["employee_id"]),
                                DepartmentID = Convert.ToInt32(reader["department_id"]),
                                DepartmentName = reader["department_name"].ToString(),
                                User_name = reader["user_name"].ToString(),
                                User_password = reader["user_password"].ToString(),
                                LastName = reader["LastName"].ToString(),
                                MiddleName = reader["MiddleName"].ToString(),
                                FirstName = reader["FirstName"].ToString(),
                                Contact_number = reader["Contact_number"].ToString(),
                                Email = reader["email"].ToString()
                            };
                            teacher.setAccountID(Convert.ToInt32(reader["account_id"]));
                            teacherlist.Add(teacher);
                        }
                    }
                    conn.Close();
                }
            }
            return teacherlist;
        }

        public void TeacherRemove(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("DeleteEmployee", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_employeeID", id);

                    conn.Open();
                    cmd.ExecuteNonQuery();

                   
                    conn.Close();
                }
            }
        }

        public void UpdateTeacher(Teacher e)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand("prcupdateteacher", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("sp_empID", e.TeacherId);
                        cmd.Parameters.AddWithValue("sp_departmentID", e.DepartmentID);
                        cmd.Parameters.AddWithValue("sp_account_id", e.accountID);
                        cmd.Parameters.AddWithValue("sp_LastName", e.LastName);
                        cmd.Parameters.AddWithValue("sp_MiddleName", e.MiddleName);
                        cmd.Parameters.AddWithValue("sp_FirstName", e.FirstName);
                        cmd.Parameters.AddWithValue("sp_contactnumber", e.Contact_number);
                        cmd.Parameters.AddWithValue("sp_email", e.Email);

                        conn.Open();
                        cmd.ExecuteNonQuery();

                       
                        conn.Close();
                    }
            }
           
        }
    }
    
}
