﻿using K4os.Compression.LZ4.Internal;
using MySql.Data.MySqlClient;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.DBContext
{
    public class MySQLTermContext : IAcademicTerm
    {
        private string _constr = Helpers.MYSqlHelpers.GetConnectionString();
        public List<AcademicTerm> gettermbysemester(string sem)
        {
            List<AcademicTerm> term = new List<AcademicTerm>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("gettermbysemester", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_semester", sem);
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {

                            AcademicTerm t = new AcademicTerm()
                            {
                                term_id = Convert.ToInt32(reader["term_id"]),
                                school_year = reader["School_year"].ToString(),
                                semester = reader["semester"].ToString(),
                                start_date = reader["start_date"].ToString(),
                                end_date = reader["end_date"].ToString()

                            };
                            term.Add(t);
                        }
                    }

                }
            }
            return term;
        }

        public AcademicTerm gettermbytermid(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            using (MySqlCommand cmd = new MySqlCommand("gettermbytermID", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("sp_termid", id);

                conn.Open();

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    if (!reader.Read())
                        return null;

                    return new AcademicTerm()
                    {
                        term_id = Convert.ToInt32(reader["term_id"]),
                        school_year = reader["school_year"].ToString(),
                        semester = reader["semester"].ToString(),
                        start_date = reader["start_date"].ToString(),
                        end_date = reader["end_date"].ToString()
                    };
                }
            }
        }


        public List<AcademicTerm> Gettermlist()
        {
            List<AcademicTerm> term = new List<AcademicTerm>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("gettermlist", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            AcademicTerm t = new AcademicTerm()
                            {
                                term_id = Convert.ToInt32(reader["term_id"]),
                                school_year = reader["School_year"].ToString(),
                                semester = reader["semester"].ToString(),
                                start_date = reader["start_date"].ToString(),
                                end_date = reader["end_date"].ToString()

                            };
                            term.Add(t);
                        }
                    }

                }
            }
            return term;
        }

        public void removeTerm(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("deleteterm", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_termId", id);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void saveTerm(AcademicTerm e)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("AddTerm", conn))
                {
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("sp_schoolyear", e.school_year);
                        cmd.Parameters.AddWithValue("sp_semester", e.semester);
                        cmd.Parameters.AddWithValue("sp_startdate", e.start_date);
                        cmd.Parameters.AddWithValue("sp_enddate", e.end_date);


                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public void updateTerm(AcademicTerm e)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("UpdateTerm", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_termID", e.term_id);
                    cmd.Parameters.AddWithValue("sp_schoolyear", e.school_year);
                    cmd.Parameters.AddWithValue("sp_semester", e.semester);
                    cmd.Parameters.AddWithValue("sp_startdate", e.start_date);
                    cmd.Parameters.AddWithValue("sp_enddate", e.end_date);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
