﻿using MySql.Data.MySqlClient;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace newStudentassessment.DBContext
{
    public class MySQLSection : ISection
    {
        private string _constr = Helpers.MYSqlHelpers.GetConnectionString();
        public List<Section> GetByCourseID(int id)
        {
            List<Section> sectionlist = new List<Section>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetSectionByCourseID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_courseid", id);
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read()) return null;

                        Section section = new Section()
                        {
                            sectionID = Convert.ToInt32(reader["section_id"]),
                            course_id = Convert.ToInt32(reader["course_id"]),
                            sectionName = reader["section_name"].ToString(),
                            year_level = reader["year_level"].ToString()

                        };
                        sectionlist.Add(section);
                    }
                }
            }
            return sectionlist;
        }

        public Section GetBySectionID(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetSectionBySectionID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_sectionid", id);
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read()) return null;

                        Section section = new Section()
                        {
                            sectionID = Convert.ToInt32(reader["section_id"]),
                            course_id = Convert.ToInt32(reader["course_id"]),
                            sectionName = reader["section_name"].ToString(),
                            year_level = reader["year_level"].ToString()

                        };
                       conn.Close();
                       return section;
                    }
                }
            }
        }

        public List<Section> GetSectionList()
        {
            List<Section> sectionlist = new List<Section>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetSectionList", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Section section = new Section()
                            {
                                sectionID = Convert.ToInt32(reader["section_id"]),
                                course_id = Convert.ToInt32(reader["course_id"]),
                                sectionName = reader["section_name"].ToString(),
                                year_level = reader["year_level"].ToString()
                            };
                            sectionlist.Add(section);

                        }
                    }
                }
            }
            return sectionlist;
        }

        public List<Section> GetSectionName(string name)
        {
            List<Section> sectionlist = new List<Section>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetBySectionName", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_sectionname", name);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Section section = new Section()
                            {
                                sectionID = Convert.ToInt32(reader["section_id"]),
                                course_id = Convert.ToInt32(reader["course_id"]),
                                sectionName = reader["section_name"].ToString(),
                                year_level = reader["year_level"].ToString()
                            };
                            sectionlist.Add(section);
                            
                        }
                    }
                }
            }
            return sectionlist;
        }

        public void RemoveSection(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("DeleteSection", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_sectionID", id);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void SaveSection(Section e)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("Addsection", conn))
                {
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("sp_section_name", e.sectionName);
                        cmd.Parameters.AddWithValue("sp_year_level", e.year_level);
                        cmd.Parameters.AddWithValue("sp_course_id", e.course_id);


                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
            }
        }

        public void UpdateSection(Section e)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("UpdateSection", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_sectionID", e.sectionID);
                    cmd.Parameters.AddWithValue("sp_section_name", e.sectionName);
                    cmd.Parameters.AddWithValue("sp_year_level", e.year_level);
                    cmd.Parameters.AddWithValue("sp_course_id", e.course_id);

                    conn.Open();
                    cmd.ExecuteNonQuery();

                    conn.Close();
                }
            }
        }
    }
}
