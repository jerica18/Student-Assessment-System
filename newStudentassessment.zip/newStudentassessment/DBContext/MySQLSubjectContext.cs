﻿using MySql.Data.MySqlClient;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace newStudentassessment.DBContext
{
    public class MySQLSubjectContext : Isubject
    {
        private string _constr = Helpers.MYSqlHelpers.GetConnectionString();



        

        public List<subject> getbycourseid(int id)
        {
            List<subject> courselist = new List<subject>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("getBycourseid", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_courseid", id);
                    conn.Open();


                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            subject s = new subject()
                            {
                                SubjectID = Convert.ToInt32(reader["subject_id"]),
                                CourseId = Convert.ToInt32(reader["course_id"]),
                                SubjectName = reader["subject_name"].ToString(),
                                SubjectCode = reader["subject_code"].ToString(),
                                SubjectStatus = reader["subject_status"].ToString(),
                                

                            };
                            courselist.Add(s);
                        }
                    }
                }
            }
            return courselist;
        }

        public List<subject> getbysubjectcode(string code)
        {
            List<subject> courselist = new List<subject>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("getBysubjectcode", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_subjectcode", code);
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            subject s = new subject()
                            {
                                SubjectID = Convert.ToInt32(reader["subject_id"]),
                                CourseId = Convert.ToInt32(reader["course_id"]),
                                SubjectName = reader["subject_name"].ToString(),
                                SubjectCode = reader["subject_code"].ToString(),
                                SubjectStatus = reader["subject_status"].ToString(),
                               
                            };
                            courselist.Add(s);
                        }
                    }
                }
            }
            return courselist;
        }


        public List<subject> GetSubjects()
        {
            List<subject> courselist = new List<subject>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("getsubjectlist", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            subject s = new subject()
                            {
                                SubjectID = Convert.ToInt32(reader["subject_id"]),
                                CourseId = Convert.ToInt32(reader["course_id"]),
                                SubjectName = reader["subject_name"].ToString(),
                                SubjectCode = reader["subject_code"].ToString(),
                                SubjectStatus = reader["subject_status"].ToString(),
                                
                            };
                            courselist.Add(s);
                        }
                    }
                }
            }
            return courselist;
        
        }



        public void RemoveSubject(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("deletesubject", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_subject_id", id);

                    conn.Open();
                    cmd.ExecuteNonQuery();

                   
                    conn.Close();
                }
            }
        }


        public void SaveSubject(subject e)
        {
                using (MySqlConnection conn = new MySqlConnection(_constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand("AddSubject", conn))
                    {
                        {
                            cmd.CommandType = CommandType.StoredProcedure;

                            
                            cmd.Parameters.AddWithValue("sp_courseid", e.CourseId);
                            cmd.Parameters.AddWithValue("sp_subjectname", e.SubjectName);
                            cmd.Parameters.AddWithValue("sp_subjectcode", e.SubjectCode);
                            cmd.Parameters.AddWithValue("sp_subjectstatus", e.SubjectStatus);


                            conn.Open();
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

               
           
        }

       

        public void UpdateSubject(subject e)
        {

            try
            {
                using (MySqlConnection conn = new MySqlConnection(_constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand("prcUpdateSubject", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("sp_subjectid", e.SubjectID);
                        cmd.Parameters.AddWithValue("sp_courseid", e.CourseId);
                        cmd.Parameters.AddWithValue("sp_subjectname", e.SubjectName);
                        cmd.Parameters.AddWithValue("sp_subjectcode", e.SubjectCode);
                        cmd.Parameters.AddWithValue("sp_subjectstatus", e.SubjectStatus);

                        conn.Open();
                        cmd.ExecuteNonQuery();

                       
                        conn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating Subject record: " + ex.Message,
                  "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

}
