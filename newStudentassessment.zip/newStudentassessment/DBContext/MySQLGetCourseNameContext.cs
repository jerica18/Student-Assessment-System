﻿using MySql.Data.MySqlClient;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.DBContext
{
    public class MySQLGetCourseNameContext : ICourseName
    {
        private string _constr = Helpers.MYSqlHelpers.GetConnectionString();
        public List<Course> GetCoursenames()
        {
            List<Course> courselist = new List<Course>();
            using (MySqlConnection conn = new MySqlConnection(_constr))
            {
                using (MySqlCommand cmd = new MySqlCommand("getcourses", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Course c = new Course()
                            {
                                CourseId = Convert.ToInt32(reader["course_id"]),
                                CourseName = reader["course_name"].ToString()

                            };
                            courselist.Add(c);
                        }
                    }
                }
            }
            return courselist;
        }

    }
}
