﻿using MySql.Data.MySqlClient;
using newStudentassessment.DBContext;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using newStudentassessment.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newStudentassessment
{
    public partial class TeacherInformation : Form
    {
        ITeacher MySQLContext = new MySQLTeacherContext();
        public TeacherInformation()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                Teacher_repo repo = new Teacher_repo(MySQLContext);

                int Teacherid = Convert.ToInt32(DGVTeacherinfo.SelectedRows[0].Cells["TeacherId"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    repo.deleteTeacherByID(Teacherid);
                    MessageBox.Show("Teacher record deleted successfully.");
                    showteachers();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void DGVTeacherinfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DGVTeacherinfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGVTeacherinfo.MultiSelect = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Teacher_repo repo = new Teacher_repo(MySQLContext);

                Teacher teacher = new Teacher();

                teacher.TeacherId = Convert.ToInt32(DGVTeacherinfo.SelectedRows[0].Cells["TeacherId"].Value);
                teacher.setAccountID(Convert.ToInt32(txtaccountid.Text));
                teacher.DepartmentID = Convert.ToInt32(txtdep.Text);
                teacher.LastName = txtlastname.Text;
                teacher.FirstName = txtfirstname.Text;
                teacher.MiddleName = txtmiddlename.Text;
                teacher.Contact_number = txtcontactnum.Text;
                teacher.Email = txtemail.Text;

                repo.updateTeacherRec(teacher);
                MessageBox.Show("Updated Teacher Record.", "Updated Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                showteachers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtaccountid.Clear();
            txtdep.Clear();
            txtlastname.Clear();
            txtfirstname.Clear();
            txtmiddlename.Clear();
            txtcontactnum.Clear();
            txtemail.Clear();
            
        }

        private void showteachers()
        {
            try
            {
                Teacher_repo repo = new Teacher_repo(MySQLContext);
                List<Teacher> teacher = repo.getteachers();
                DGVTeacherinfo.DataSource = teacher;
                DGVTeacherinfo.Columns["Id"].Visible = false;
                DGVTeacherinfo.Columns["Account_Type"].Visible = false;
                DGVTeacherinfo.Columns["accountID"].Visible = false;
                DGVTeacherinfo.Columns["DepartmentID"].Visible = false;



            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Teachers: " + ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Teacher_repo repo = new Teacher_repo(MySQLContext);

            string search = txtsearch.Text.Trim();
            BindingSource bs = new BindingSource();

            if (int.TryParse(search, out int teacherid))
            {
                Teacher teacher = repo.getTeacherByID(teacherid);
                if (teacher != null)
                    bs.Add(teacher);
            }
            else
            {
                Teacher iTeacher = repo.getTeacherByLname(search);
                if (iTeacher != null)
                    bs.Add(iTeacher);
            }

            DGVTeacherinfo.DataSource = bs;

        }

        private void TeacherInformation_Load(object sender, EventArgs e)
        {
            showteachers();
            

        }

     


        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string teacher = txtsearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(teacher))
            {
                showteachers();
            }
        }

        private void DGVTeacherinfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVTeacherinfo.Rows[e.RowIndex];

                int teacher = Convert.ToInt32(row.Cells["TeacherId"].Value);
                txtaccountid.Text = row.Cells["accountID"].Value.ToString();
                txtdep.Text = row.Cells["DepartmentID"].Value.ToString() ;
                txtfirstname.Text = row.Cells["FirstName"].Value.ToString();
                txtmiddlename.Text = row.Cells["MiddleName"].Value.ToString();
                txtlastname.Text = row.Cells["LastName"].Value.ToString();
                txtcontactnum.Text = row.Cells["contact_number"].Value.ToString();
                txtemail.Text = row.Cells["email"].Value.ToString();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            Form1 mainForm = new Form1();
            mainForm.Show();
            this.Close();
        }
    }
}
