﻿namespace newStudentassessment
{
    partial class StudentInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtcontactnum = new System.Windows.Forms.TextBox();
            this.lblContactnumber = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtmiddlename = new System.Windows.Forms.TextBox();
            this.lblMiddlename = new System.Windows.Forms.Label();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.DGVStudentinfo = new System.Windows.Forms.DataGridView();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblAccountID = new System.Windows.Forms.Label();
            this.lblstudentinfo = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtaccountid = new System.Windows.Forms.TextBox();
            this.btndashboard = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVStudentinfo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1803, 69);
            this.panel1.TabIndex = 4;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(254, 561);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(416, 42);
            this.txtemail.TabIndex = 91;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(132, 575);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(47, 16);
            this.lblEmail.TabIndex = 90;
            this.lblEmail.Text = "Email :";
            // 
            // txtcontactnum
            // 
            this.txtcontactnum.Location = new System.Drawing.Point(254, 500);
            this.txtcontactnum.Multiline = true;
            this.txtcontactnum.Name = "txtcontactnum";
            this.txtcontactnum.Size = new System.Drawing.Size(416, 42);
            this.txtcontactnum.TabIndex = 89;
            // 
            // lblContactnumber
            // 
            this.lblContactnumber.AutoSize = true;
            this.lblContactnumber.Location = new System.Drawing.Point(132, 514);
            this.lblContactnumber.Name = "lblContactnumber";
            this.lblContactnumber.Size = new System.Drawing.Size(109, 16);
            this.lblContactnumber.TabIndex = 88;
            this.lblContactnumber.Text = "Contact Number :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(749, 130);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 87;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtmiddlename
            // 
            this.txtmiddlename.Location = new System.Drawing.Point(254, 438);
            this.txtmiddlename.Multiline = true;
            this.txtmiddlename.Name = "txtmiddlename";
            this.txtmiddlename.Size = new System.Drawing.Size(416, 42);
            this.txtmiddlename.TabIndex = 86;
            // 
            // lblMiddlename
            // 
            this.lblMiddlename.AutoSize = true;
            this.lblMiddlename.Location = new System.Drawing.Point(132, 452);
            this.lblMiddlename.Name = "lblMiddlename";
            this.lblMiddlename.Size = new System.Drawing.Size(94, 16);
            this.lblMiddlename.TabIndex = 85;
            this.lblMiddlename.Text = "Middle Name :";
            // 
            // txtfirstname
            // 
            this.txtfirstname.Location = new System.Drawing.Point(254, 381);
            this.txtfirstname.Multiline = true;
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(416, 42);
            this.txtfirstname.TabIndex = 84;
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.Location = new System.Drawing.Point(132, 395);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(78, 16);
            this.lblFirstname.TabIndex = 83;
            this.lblFirstname.Text = "First Name :";
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(871, 125);
            this.txtsearch.Multiline = true;
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(430, 42);
            this.txtsearch.TabIndex = 82;
            this.txtsearch.TextChanged += new System.EventHandler(this.txtsearch_TextChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(421, 652);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 81;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(269, 652);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 80;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtlastname
            // 
            this.txtlastname.Location = new System.Drawing.Point(254, 323);
            this.txtlastname.Multiline = true;
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(416, 42);
            this.txtlastname.TabIndex = 79;
            // 
            // DGVStudentinfo
            // 
            this.DGVStudentinfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVStudentinfo.Location = new System.Drawing.Point(749, 212);
            this.DGVStudentinfo.Name = "DGVStudentinfo";
            this.DGVStudentinfo.RowHeadersWidth = 51;
            this.DGVStudentinfo.RowTemplate.Height = 24;
            this.DGVStudentinfo.Size = new System.Drawing.Size(952, 582);
            this.DGVStudentinfo.TabIndex = 77;
            this.DGVStudentinfo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVStudentinfo_CellClick);
            this.DGVStudentinfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVStudentinfo_CellContentClick);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(132, 337);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(78, 16);
            this.lblLastName.TabIndex = 75;
            this.lblLastName.Text = "Last Name :";
            // 
            // lblAccountID
            // 
            this.lblAccountID.AutoSize = true;
            this.lblAccountID.Location = new System.Drawing.Point(132, 280);
            this.lblAccountID.Name = "lblAccountID";
            this.lblAccountID.Size = new System.Drawing.Size(69, 16);
            this.lblAccountID.TabIndex = 74;
            this.lblAccountID.Text = "Accunt ID :";
            // 
            // lblstudentinfo
            // 
            this.lblstudentinfo.AutoSize = true;
            this.lblstudentinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstudentinfo.Location = new System.Drawing.Point(336, 138);
            this.lblstudentinfo.Name = "lblstudentinfo";
            this.lblstudentinfo.Size = new System.Drawing.Size(220, 29);
            this.lblstudentinfo.TabIndex = 72;
            this.lblstudentinfo.Text = "Student Information";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(566, 652);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(93, 37);
            this.btnClear.TabIndex = 92;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtaccountid
            // 
            this.txtaccountid.Location = new System.Drawing.Point(254, 267);
            this.txtaccountid.Multiline = true;
            this.txtaccountid.Name = "txtaccountid";
            this.txtaccountid.Size = new System.Drawing.Size(416, 42);
            this.txtaccountid.TabIndex = 78;
            // 
            // btndashboard
            // 
            this.btndashboard.Location = new System.Drawing.Point(1136, 16);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(93, 37);
            this.btndashboard.TabIndex = 115;
            this.btndashboard.Text = "DashBoard";
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // StudentInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1803, 918);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtcontactnum);
            this.Controls.Add(this.lblContactnumber);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtmiddlename);
            this.Controls.Add(this.lblMiddlename);
            this.Controls.Add(this.txtfirstname);
            this.Controls.Add(this.lblFirstname);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtlastname);
            this.Controls.Add(this.txtaccountid);
            this.Controls.Add(this.DGVStudentinfo);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblAccountID);
            this.Controls.Add(this.lblstudentinfo);
            this.Controls.Add(this.panel1);
            this.Name = "StudentInformation";
            this.Text = "StudentInformation";
            this.Load += new System.EventHandler(this.StudentInformation_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVStudentinfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtcontactnum;
        private System.Windows.Forms.Label lblContactnumber;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtmiddlename;
        private System.Windows.Forms.Label lblMiddlename;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.DataGridView DGVStudentinfo;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblAccountID;
        private System.Windows.Forms.Label lblstudentinfo;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtaccountid;
        private System.Windows.Forms.Button btndashboard;
    }
}