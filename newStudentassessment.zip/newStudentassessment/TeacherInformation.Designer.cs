﻿namespace newStudentassessment
{
    partial class TeacherInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btndashboard = new System.Windows.Forms.Button();
            this.lblSAS = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtcontactnum = new System.Windows.Forms.TextBox();
            this.lblContactnumber = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtmiddlename = new System.Windows.Forms.TextBox();
            this.lblMiddlename = new System.Windows.Forms.Label();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtaccountid = new System.Windows.Forms.TextBox();
            this.DGVTeacherinfo = new System.Windows.Forms.DataGridView();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblAccountID = new System.Windows.Forms.Label();
            this.lblteacherinfo = new System.Windows.Forms.Label();
            this.lbldep = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.txtdep = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVTeacherinfo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1657, 69);
            this.panel1.TabIndex = 5;
            // 
            // btndashboard
            // 
            this.btndashboard.Location = new System.Drawing.Point(1133, 10);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(93, 37);
            this.btndashboard.TabIndex = 114;
            this.btndashboard.Text = "DashBoard";
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(480, 705);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(93, 37);
            this.btnClear.TabIndex = 111;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(168, 614);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(416, 42);
            this.txtemail.TabIndex = 110;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(46, 628);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(47, 16);
            this.lblEmail.TabIndex = 109;
            this.lblEmail.Text = "Email :";
            // 
            // txtcontactnum
            // 
            this.txtcontactnum.Location = new System.Drawing.Point(168, 553);
            this.txtcontactnum.Multiline = true;
            this.txtcontactnum.Name = "txtcontactnum";
            this.txtcontactnum.Size = new System.Drawing.Size(416, 42);
            this.txtcontactnum.TabIndex = 108;
            // 
            // lblContactnumber
            // 
            this.lblContactnumber.AutoSize = true;
            this.lblContactnumber.Location = new System.Drawing.Point(46, 567);
            this.lblContactnumber.Name = "lblContactnumber";
            this.lblContactnumber.Size = new System.Drawing.Size(109, 16);
            this.lblContactnumber.TabIndex = 107;
            this.lblContactnumber.Text = "Contact Number :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(663, 112);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 106;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtmiddlename
            // 
            this.txtmiddlename.Location = new System.Drawing.Point(168, 491);
            this.txtmiddlename.Multiline = true;
            this.txtmiddlename.Name = "txtmiddlename";
            this.txtmiddlename.Size = new System.Drawing.Size(416, 42);
            this.txtmiddlename.TabIndex = 105;
            // 
            // lblMiddlename
            // 
            this.lblMiddlename.AutoSize = true;
            this.lblMiddlename.Location = new System.Drawing.Point(46, 505);
            this.lblMiddlename.Name = "lblMiddlename";
            this.lblMiddlename.Size = new System.Drawing.Size(94, 16);
            this.lblMiddlename.TabIndex = 104;
            this.lblMiddlename.Text = "Middle Name :";
            // 
            // txtfirstname
            // 
            this.txtfirstname.Location = new System.Drawing.Point(168, 434);
            this.txtfirstname.Multiline = true;
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(416, 42);
            this.txtfirstname.TabIndex = 103;
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.Location = new System.Drawing.Point(46, 448);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(78, 16);
            this.lblFirstname.TabIndex = 102;
            this.lblFirstname.Text = "First Name :";
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(785, 107);
            this.txtsearch.Multiline = true;
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(430, 42);
            this.txtsearch.TabIndex = 101;
            this.txtsearch.TextChanged += new System.EventHandler(this.txtsearch_TextChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(335, 705);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 100;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(183, 705);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 99;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtlastname
            // 
            this.txtlastname.Location = new System.Drawing.Point(168, 376);
            this.txtlastname.Multiline = true;
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(416, 42);
            this.txtlastname.TabIndex = 98;
            // 
            // txtaccountid
            // 
            this.txtaccountid.Location = new System.Drawing.Point(168, 242);
            this.txtaccountid.Multiline = true;
            this.txtaccountid.Name = "txtaccountid";
            this.txtaccountid.Size = new System.Drawing.Size(416, 42);
            this.txtaccountid.TabIndex = 97;
            // 
            // DGVTeacherinfo
            // 
            this.DGVTeacherinfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVTeacherinfo.Location = new System.Drawing.Point(663, 194);
            this.DGVTeacherinfo.Name = "DGVTeacherinfo";
            this.DGVTeacherinfo.RowHeadersWidth = 51;
            this.DGVTeacherinfo.RowTemplate.Height = 24;
            this.DGVTeacherinfo.Size = new System.Drawing.Size(952, 582);
            this.DGVTeacherinfo.TabIndex = 96;
            this.DGVTeacherinfo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVTeacherinfo_CellClick);
            this.DGVTeacherinfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVTeacherinfo_CellContentClick);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(46, 390);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(78, 16);
            this.lblLastName.TabIndex = 95;
            this.lblLastName.Text = "Last Name :";
            // 
            // lblAccountID
            // 
            this.lblAccountID.AutoSize = true;
            this.lblAccountID.Location = new System.Drawing.Point(46, 255);
            this.lblAccountID.Name = "lblAccountID";
            this.lblAccountID.Size = new System.Drawing.Size(69, 16);
            this.lblAccountID.TabIndex = 94;
            this.lblAccountID.Text = "Accunt ID :";
            // 
            // lblteacherinfo
            // 
            this.lblteacherinfo.AutoSize = true;
            this.lblteacherinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblteacherinfo.Location = new System.Drawing.Point(250, 120);
            this.lblteacherinfo.Name = "lblteacherinfo";
            this.lblteacherinfo.Size = new System.Drawing.Size(228, 29);
            this.lblteacherinfo.TabIndex = 93;
            this.lblteacherinfo.Text = "Teacher Information";
            // 
            // lbldep
            // 
            this.lbldep.AutoSize = true;
            this.lbldep.Location = new System.Drawing.Point(46, 321);
            this.lbldep.Name = "lbldep";
            this.lbldep.Size = new System.Drawing.Size(99, 16);
            this.lbldep.TabIndex = 112;
            this.lbldep.Text = "Department ID :";
            // 
            // txtdep
            // 
            this.txtdep.Location = new System.Drawing.Point(168, 306);
            this.txtdep.Multiline = true;
            this.txtdep.Name = "txtdep";
            this.txtdep.Size = new System.Drawing.Size(416, 42);
            this.txtdep.TabIndex = 113;
            // 
            // TeacherInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1661, 883);
            this.Controls.Add(this.txtdep);
            this.Controls.Add(this.lbldep);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtcontactnum);
            this.Controls.Add(this.lblContactnumber);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtmiddlename);
            this.Controls.Add(this.lblMiddlename);
            this.Controls.Add(this.txtfirstname);
            this.Controls.Add(this.lblFirstname);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtlastname);
            this.Controls.Add(this.txtaccountid);
            this.Controls.Add(this.DGVTeacherinfo);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblAccountID);
            this.Controls.Add(this.lblteacherinfo);
            this.Controls.Add(this.panel1);
            this.Name = "TeacherInformation";
            this.Text = "TeacherInformation";
            this.Load += new System.EventHandler(this.TeacherInformation_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVTeacherinfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtcontactnum;
        private System.Windows.Forms.Label lblContactnumber;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtmiddlename;
        private System.Windows.Forms.Label lblMiddlename;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.TextBox txtaccountid;
        private System.Windows.Forms.DataGridView DGVTeacherinfo;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblAccountID;
        private System.Windows.Forms.Label lblteacherinfo;
        private System.Windows.Forms.Label lbldep;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox txtdep;
        private System.Windows.Forms.Button btndashboard;
    }
}