﻿using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Interfaces
{
    public interface Isubject
    {
        List<subject> getbycourseid(int id);

        List<subject> getbysubjectcode(string code);

        
        void UpdateSubject(subject e);


        
        void RemoveSubject(int id);

       
        List<subject> GetSubjects();
        
        void SaveSubject(subject e);

       

    }
}
