﻿using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Interfaces
{
    public interface IAcademicTerm
    {
        void saveTerm(AcademicTerm e);
        void removeTerm(int id);
        void updateTerm(AcademicTerm e);
        List<AcademicTerm> Gettermlist();

        AcademicTerm gettermbytermid(int id);
        List<AcademicTerm> gettermbysemester(string sem);
    }
}

