﻿using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Interfaces
{
    public interface ITeacher
    {
        Teacher GetByID(int id);
        void UpdateTeacher(Teacher e);
        void TeacherRemove(int id);
        List<Teacher> GetTeacherList();
        Teacher GetbyLname(string lname);

        Teacher GetbyDepartment(string dep);

        

    }
}
