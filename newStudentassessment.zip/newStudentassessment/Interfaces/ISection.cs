﻿using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Interfaces
{
    public interface ISection
    {
        void SaveSection(Section e);
        void UpdateSection(Section e);
        void RemoveSection(int id);

        List<Section> GetSectionList();

        List<Section> GetSectionName(string  name);

        List<Section> GetByCourseID(int id);
        Section GetBySectionID(int id);


    }
}
