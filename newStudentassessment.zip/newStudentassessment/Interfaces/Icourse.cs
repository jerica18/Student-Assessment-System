﻿using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Interfaces
{
    public interface Icourse
    {
        List<Course> GetCourse();
        void RemoveCourse(int id);
        void Savecourse(Course e);

        void updateCourse(Course e);

        Course GetCourseByCode(string code);

        

        
    }
}
