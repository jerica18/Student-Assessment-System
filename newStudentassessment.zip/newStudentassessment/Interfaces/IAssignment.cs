﻿using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Interfaces
{
    public interface IAssignment
    {
        void SaveAssignment(Assignment e);
        void RemoveAssignmet(int id);
        void UpdateAssignment(Assignment e);

        List<Assignment> GetByEmpID(int id);
        List<Assignment> GetAssignmentList();
        Assignment GetByAssignmentID(int id);
    }
}
