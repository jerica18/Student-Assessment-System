﻿using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Interfaces
{
    public interface IStudent
    {
        Student GetByID(int id);
        void Updatestudent(Student e);
        void StudentRemove(int id);
        List<Student> GetStudentList();
        Student GetbyLname(string lname);

    }
}
