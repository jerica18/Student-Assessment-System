﻿using newStudentassessment.DBContext;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using newStudentassessment.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newStudentassessment
{
    public partial class CourseInformation : Form
    {
        Icourse MySQLContext = new MySQLCourseContext();
        public CourseInformation()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Course_repo repo =  new Course_repo(MySQLContext);

            Course course = new Course()
            {
                CourseName = txtcoursename.Text,
                CourseCode = txtcode.Text,
                DurationYears = txtyear.Text
            };

            repo.AddCourse(course);
            showcourse();

        }

        private void DGVCoursetinfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DGVCoursetinfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGVCoursetinfo.MultiSelect = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                Course_repo repo = new Course_repo(MySQLContext);

                int id = Convert.ToInt32(DGVCoursetinfo.SelectedRows[0].Cells["CourseId"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    repo.deletecourse(id);
                    MessageBox.Show("Course record deleted successfully.");
                    showcourse();


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Course_repo repo = new Course_repo(MySQLContext);

            try
            {
                Course course = new Course()
                {
                    CourseId = Convert.ToInt32(DGVCoursetinfo.SelectedRows[0].Cells["CourseId"].Value),
                    CourseName = txtcoursename.Text,
                    CourseCode = txtcode.Text,
                    DurationYears = txtyear.Text
                };

                repo.UpdateCourse(course);
                showcourse();



            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtcoursename.Clear();
            txtcode.Clear();
            txtyear.Clear();

        }

        private void showcourse()
        {

            Course_repo repo = new Course_repo(MySQLContext);
            List<Course> list = repo.GetCourseList();
            DGVCoursetinfo.DataSource = list;
            DGVCoursetinfo.AutoResizeColumns();

        }

        private void CourseInformation_Load(object sender, EventArgs e)
        {
            showcourse();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Course_repo repo = new Course_repo(MySQLContext);
            string search = txtsearch.Text.Trim();

            Course course = repo.Getcoursebycode(search);

            if (course == null)
            {
                MessageBox.Show("Course not found");
                DGVCoursetinfo.DataSource = null;
                return;
            }

            BindingSource bs = new BindingSource();
            bs.Add(course);         

            DGVCoursetinfo.DataSource = bs;
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string student = txtsearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(student))
            {
                showcourse();
            }
        }

        private void DGVCoursetinfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVCoursetinfo.Rows[e.RowIndex];
                int courseid = Convert.ToInt32(row.Cells["CourseId"].Value);
                txtcoursename.Text = row.Cells["CourseName"].Value.ToString();
                txtcode.Text = row.Cells["CourseCode"].Value?.ToString();
                txtyear.Text = row.Cells["DurationYears"].Value?.ToString();
            }
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            Form1 mainForm = new Form1();
            mainForm.Show();
            this.Close();
        }
    }
}

