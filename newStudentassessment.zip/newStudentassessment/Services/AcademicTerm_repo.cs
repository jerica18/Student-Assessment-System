﻿using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Services
{
    public class AcademicTerm_repo
    {
        private IAcademicTerm _repo;
        public AcademicTerm_repo (IAcademicTerm repo)
        {
            this._repo = repo;
        }

        public List<AcademicTerm> getTermList()
        {
            return _repo.Gettermlist();
        }

        public List<AcademicTerm> gettermbysemester(string sem)
        {
            return _repo.gettermbysemester(sem);
        }

        public AcademicTerm getbytermId(int id)
        {
            return _repo.gettermbytermid(id);
        }

        public void DeleteTerm(int id)
        {
            _repo.removeTerm(id);
        }

        public void AddTerm(AcademicTerm e)
        {
            _repo.saveTerm(e);
        }

        public void UpdateTerm(AcademicTerm e )
        {
            _repo.updateTerm(e);
        }
    }
}
