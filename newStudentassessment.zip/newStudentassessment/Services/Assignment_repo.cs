﻿using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Services
{
    public class Assignment_repo
    {
        private IAssignment _repo;

        public Assignment_repo (IAssignment repo)
        {
            _repo = repo;
        }
        public void AddAssignment(Assignment e)
        {
            _repo.SaveAssignment(e);
        }
        public void DeleteAssignment(int id)
        {
            _repo.RemoveAssignmet(id);
        }
        public void updateAssignment(Assignment e)
        {
            _repo.UpdateAssignment(e);
        }

        public List<Assignment> AssignmentList()
        {
          return _repo.GetAssignmentList();
        }
        
        public List<Assignment> getbyempID(int id)
        {
            return _repo.GetByEmpID(id);
        }

        public Assignment getbyassignmentID(int id)
        {
            return _repo.GetByAssignmentID(id);
        }
    }
}
