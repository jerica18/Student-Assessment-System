﻿using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Services
{
    public class Student_repo
    {
        private IStudent _repo;

        public Student_repo (IStudent repo)
        {
            _repo = repo;
        }

        public Student getStudentByID(int id)
        {
            return _repo.GetByID(id);
        }

        public void updateStudentRec(Student e)
        {
            _repo.Updatestudent(e);
        }

        public void deleteStudentByID(int id)
        {
            _repo.StudentRemove(id);
        }

        public List<Student> getStudents()
        {
            return _repo.GetStudentList();
        }

        public Student getStudentsByLname(string lname)
        {
            return _repo.GetbyLname(lname);
        }

       
    }
}
