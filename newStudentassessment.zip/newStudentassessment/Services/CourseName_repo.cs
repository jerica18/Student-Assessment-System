﻿using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Services
{
    public class CourseName_repo
    {
        private ICourseName _repo;

        public CourseName_repo (ICourseName repo)
        {
            _repo = repo;
        }

        public List<Course> getcoursenames()
        {
            return _repo.GetCoursenames();
        }
    }
}
