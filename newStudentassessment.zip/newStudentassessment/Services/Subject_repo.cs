﻿using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Services
{
    public class Subject_repo
    {
        private Isubject _repo;

        public Subject_repo (Isubject repo)
        {  _repo = repo; }

        public List<subject> GetSubjectByCourseId(int id)
        {
            return _repo.getbycourseid(id);
        }

        public List<subject> GetSubjectBySubjectCode(string code)
        {
            return _repo.getbysubjectcode(code);
        }

       

        public void UpdateSubject(subject e)
        {
            _repo.UpdateSubject(e);
        }

        public List<subject> GetSubjectsList()
        {
            return _repo.GetSubjects();
        }

       

        public void AddSubject(subject e)
        {
            _repo.SaveSubject(e);
        }

       

        public void deletesub(int id)
        {
            _repo.RemoveSubject(id);
        }
    }
}
