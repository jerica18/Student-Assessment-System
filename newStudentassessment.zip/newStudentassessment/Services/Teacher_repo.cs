﻿using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Services
{
    public class Teacher_repo
    {
        public ITeacher _repo;

        public Teacher_repo(ITeacher repo)
        {
            _repo = repo;
        }

        public Teacher getTeacherByID(int id)
        {
            return _repo.GetByID(id);
        }

        public Teacher getTeacherByLname(string lname)
        {
            return _repo.GetbyLname(lname);
        }

        public List<Teacher> getteachers()
        {
            return _repo.GetTeacherList();
        }

        public void deleteTeacherByID(int id)
        {
            _repo.TeacherRemove(id);
        }

        public void updateTeacherRec(Teacher e)
        {
            _repo.UpdateTeacher(e);
        }

        
        

    }
}
