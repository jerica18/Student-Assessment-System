﻿using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Services
{
    public class Course_repo
    {
        private Icourse _repo;
        public Course_repo (Icourse repo)
        {
            _repo = repo;
        }

        public List<Course> GetCourseList()
        {
            return _repo.GetCourse();
        }

        public void AddCourse(Course e)
        {
            _repo.Savecourse(e);
        }


        public void UpdateCourse(Course e)
        {
            _repo.updateCourse(e);
        }

        public void deletecourse(int id)
        {
            _repo.RemoveCourse(id);
        }

        public Course Getcoursebycode(string courseCode)
        {
            return _repo.GetCourseByCode(courseCode);
        }

    }
}
