﻿using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Services
{
    public class Section_repo
    {
        private ISection _repo;

        public Section_repo (ISection repo)
        {
            _repo = repo;
        }

        public void AddSection(Section e)
        {
            _repo.SaveSection(e);
        }

        public void updateSection(Section e)
        {
            _repo.UpdateSection(e);
        }

        public void deleteSection(int id)
        {
            _repo.RemoveSection(id);
        }

        public List<Section> getsectionlist()
        {
            return _repo.GetSectionList();
        }

        public List<Section> getSectionName(string name)
        {
            return _repo.GetSectionName(name);
        }

        public Section getSectionId(int id)
        {
            return _repo.GetBySectionID(id);
        }

        public List<Section> getCourseID(int id)
        {
            return _repo.GetByCourseID(id);
        }


    }
}
