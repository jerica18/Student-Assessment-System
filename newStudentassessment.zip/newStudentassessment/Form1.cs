﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newStudentassessment
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btnStudentInfo_Click(object sender, EventArgs e)
        {
            StudentInformation frmStudentinfo = new StudentInformation();
    
            frmStudentinfo.Show();

            this.Hide();

        }

        private void btnteacherinfo_Click(object sender, EventArgs e)
        {
            TeacherInformation frmTeacher = new TeacherInformation();
            frmTeacher.Show();
            this.Hide();
        }

        private void btnSubjectInfo_Click(object sender, EventArgs e)
        {
            SubjectInfo frmSub = new SubjectInfo();
            frmSub.Show();
            this.Hide();
        }

        private void btncourse_Click(object sender, EventArgs e)
        {
            CourseInformation frmCourse = new CourseInformation();
            frmCourse.Show();
            this.Hide();
        }

        private void btnSection_Click(object sender, EventArgs e)
        {
            CourseSection frmCourseSection = new CourseSection();
            frmCourseSection.Show();
            this.Hide();
        }

        private void btnTerm_Click(object sender, EventArgs e)
        {
            Academic_Term frmTerm = new Academic_Term();    
            frmTerm.Show();
            this.Hide();
        }

        private void btnAssignments_Click(object sender, EventArgs e)
        {
            Teacher_Assignment frmAssignment = new Teacher_Assignment();
            frmAssignment.Show();
            this.Hide();
        }
    }
}
