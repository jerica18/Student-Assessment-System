﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Models
{
    public class Student : Account
    {
        public int studentid { get; set; }

    }
}
