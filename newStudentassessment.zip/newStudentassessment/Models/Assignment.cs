﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Models
{
    public class Assignment
    {
       public int Assignment_ID { get; set; }
       public int TeacherId {  get; set; }

        public int term_id { get; set; }

        public int SubjectID { get; set; }
        public string Assignment_Schedule { get; set; }
        public string Start_time { get; set; }  
        public string End_time { get; set; }
    }
}
