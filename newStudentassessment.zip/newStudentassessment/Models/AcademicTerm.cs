﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Models
{
    public class AcademicTerm
    {
        public int term_id {  get; set; }
        public string school_year { get; set; }
        public string semester {  get; set; }
        public string start_date { get; set; }
        public string end_date { get; set; }
    }
}
