﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Models
{
    public abstract class Account : Person
    {
        protected int AccountID;
        public string User_name { get; set; }
        public string User_password { get; set; }
        public string Account_Type { get; set; }

        public void setAccountID(int AccountID)
        {
            this.AccountID = AccountID;
        }
        public int accountID
        {
            get { return AccountID; }
        }
    }
}
