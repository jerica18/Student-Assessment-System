﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace newStudentassessment.Models
{
    public class Section
    {
        public int sectionID {  get; set; }
        public int course_id { get; set; }
        public string sectionName { get; set; } 
        public string year_level { get; set; }

       
    }
}
