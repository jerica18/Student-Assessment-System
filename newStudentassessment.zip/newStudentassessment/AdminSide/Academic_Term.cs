﻿using newStudentassessment.DBContext;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using newStudentassessment.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newStudentassessment
{
    public partial class Academic_Term : Form
    {
        IAcademicTerm MySQLContext = new MySQLTermContext();
        public Academic_Term()
        {
            InitializeComponent();
        }

        private void DGVTermtinfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DGVTermtinfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGVTermtinfo.MultiSelect = false;
        }

        private void showterm()
        {
            AcademicTerm_repo repo = new AcademicTerm_repo(MySQLContext);

            List<AcademicTerm> term = repo.getTermList();

            DGVTermtinfo.DataSource = term;

        }

        private void Academic_Term_Load(object sender, EventArgs e)
        {
            showterm();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AcademicTerm_repo repo = new AcademicTerm_repo(MySQLContext);

            AcademicTerm term = new AcademicTerm()
            {
                school_year = txtschoolyear.Text,
                semester = txtSem.Text,
                start_date = txtStartdate.Text,
                end_date = txtEndDate.Text,
            };
            MessageBox.Show("Term Added.", "New Term",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            repo.AddTerm(term);
            showterm();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            AcademicTerm_repo repo = new AcademicTerm_repo(MySQLContext);
            try 
            {

                int id = Convert.ToInt32(DGVTermtinfo.SelectedRows[0].Cells["term_id"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    repo.DeleteTerm(id);
                    MessageBox.Show("Academic Term record deleted successfully.");
                    showterm();


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            AcademicTerm_repo repo = new AcademicTerm_repo(MySQLContext);
            try 
            { 
                AcademicTerm term = new AcademicTerm()
                {
                    term_id = Convert.ToInt32(DGVTermtinfo.SelectedRows[0].Cells["term_id"].Value),
                    school_year = txtschoolyear.Text,
                    semester = txtSem.Text,
                    start_date = txtStartdate.Text,
                    end_date = txtEndDate.Text,
                };
                MessageBox.Show("Updated Term Record.", "Updated Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                repo.UpdateTerm(term);
                showterm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtschoolyear.Clear();
            txtSem.Clear();
            txtStartdate.Clear();
            txtEndDate.Clear();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            AcademicTerm_repo repo = new AcademicTerm_repo(MySQLContext);
            string search = txtsearch.Text.Trim();

            BindingSource bs = new BindingSource();

            if (int.TryParse(search, out int id))
            {
                
                var result = repo.getbytermId(id);
                bs.DataSource = result;
            }
            else
            {
                
                var result = repo.gettermbysemester(search);
                bs.DataSource = result;
            }

            DGVTermtinfo.AutoGenerateColumns = true;
            DGVTermtinfo.DataSource = bs;

        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string student = txtsearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(student))
            {
                showterm();
            }
        }

        private void DGVTermtinfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVTermtinfo.Rows[e.RowIndex];

                int termID = Convert.ToInt32(row.Cells["term_id"].Value);
                txtschoolyear.Text = row.Cells["school_year"].Value.ToString();
                txtSem.Text = row.Cells["semester"].Value.ToString();
                txtStartdate.Text = Convert.ToDateTime(row.Cells["start_date"].Value)
                           .ToString("yyyy-MM-dd");
                txtEndDate.Text = Convert.ToDateTime(row.Cells["end_date"].Value)
                                        .ToString("yyyy-MM-dd");
            }
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            AdminFrontPage AdminForm = new AdminFrontPage();
            AdminForm.Show();
            this.Close();
        }
    }
}
