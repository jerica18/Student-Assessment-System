﻿using newStudentassessment.DBContext;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using newStudentassessment.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newStudentassessment
{
    public partial class SubjectInfo : Form
    {
        Isubject MySQLContext = new MySQLSubjectContext();
        ICourseName Mysqlcontext = new MySQLGetCourseNameContext();
        public SubjectInfo()
        {
            InitializeComponent();
        }

        private void SubjectInfo_Load(object sender, EventArgs e)
        {
            CourseName_repo repo = new CourseName_repo(Mysqlcontext);

            List<Course> courses = repo.getcoursenames();

            courses.Insert(0, new Course { CourseId = 0, CourseName = "" });

            cmbcoursename.DataSource = courses;
            cmbcoursename.DisplayMember = "CourseName";
            cmbcoursename.ValueMember = "CourseId";

            cmbcoursename.SelectedIndex = 0;

            cmbstats.Items.Add("Active");
            cmbstats.Items.Add("InActive");

            showSub();
        }

        private void DGVSubtinfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DGVSubtinfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGVSubtinfo.MultiSelect = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int selectedCourseId = (int)cmbcoursename.SelectedValue;

            Subject_repo repo = new Subject_repo(MySQLContext);

            try
            {
                subject s = new subject()
                {
                    SubjectID = Convert.ToInt32(DGVSubtinfo.SelectedRows[0].Cells["SubjectID"].Value),
                    CourseId = selectedCourseId,
                    SubjectName = txtsubname.Text,
                    SubjectCode = txtsubcode.Text,
                    SubjectStatus = cmbstats.Text,
                };

                repo.UpdateSubject(s);
                MessageBox.Show("Updated Subject Record.", "Updated Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                showSub();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int selectedCourseId = (int)cmbcoursename.SelectedValue;

            Subject_repo repo = new Subject_repo(MySQLContext);


            subject s = new subject()
            {
                CourseId = selectedCourseId,
                SubjectName = txtsubname.Text,
                SubjectCode = txtsubcode.Text,
                SubjectStatus = cmbstats.Text
            };

            repo.AddSubject(s);
            MessageBox.Show("Subject Added.", "New Subject",
                   MessageBoxButtons.OK, MessageBoxIcon.Information);
            showSub();


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                Subject_repo repo = new Subject_repo(MySQLContext);

                int Subid = Convert.ToInt32(DGVSubtinfo.SelectedRows[0].Cells["SubjectID"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    repo.deletesub(Subid);
                    MessageBox.Show("Subject record deleted successfully.");
                    showSub();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtsubname.Clear();
            txtsubcode.Clear();
            cmbstats.SelectedIndex = -1;
            cmbcoursename.SelectedIndex = -1;
        }

        private void showSub()
        {
            Subject_repo repo = new Subject_repo(MySQLContext);
            List<subject> sublist = repo.GetSubjectsList();
            DGVSubtinfo.DataSource = sublist;

            
           


          
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Subject_repo repo = new Subject_repo(MySQLContext);
            string search = txtsearch.Text.Trim();

            BindingSource bs = new BindingSource();

            if (int.TryParse(search, out int id))
            {
                bs.DataSource = repo.GetSubjectByCourseId(id);
            }
            else
            {
                bs.DataSource = repo.GetSubjectBySubjectCode(search);
            }

            DGVSubtinfo.AutoGenerateColumns = true;
            DGVSubtinfo.DataSource = bs;

        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string student = txtsearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(student))
            {
                showSub();
            }
        }

        private void DGVSubtinfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVSubtinfo.Rows[e.RowIndex];
                {
                    int Subid = Convert.ToInt32(DGVSubtinfo.SelectedRows[0].Cells["SubjectID"].Value);
                    txtsubname.Text = row.Cells["SubjectName"].Value.ToString();
                    txtsubcode.Text = row.Cells["SubjectCode"].Value.ToString();
                    cmbstats.Text = row.Cells["SubjectStatus"].Value.ToString();
                    cmbcoursename.SelectedValue = Convert.ToInt32(row.Cells["CourseId"].Value);

                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbcoursename_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            AdminFrontPage AdminForm = new AdminFrontPage();
            AdminForm.Show();
            this.Close();
        }
    }
}
