﻿namespace newStudentassessment
{
    partial class CourseSection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtyearlevel = new System.Windows.Forms.TextBox();
            this.llblcoursename = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblSectionName = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtsectionname = new System.Windows.Forms.TextBox();
            this.lblear_level = new System.Windows.Forms.Label();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.DGVSectiontinfo = new System.Windows.Forms.DataGridView();
            this.lblsectioninfo = new System.Windows.Forms.Label();
            this.cmbcoursename = new System.Windows.Forms.ComboBox();
            this.btndashboard = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSectiontinfo)).BeginInit();
            this.SuspendLayout();
            // 
            // txtyearlevel
            // 
            this.txtyearlevel.Location = new System.Drawing.Point(193, 395);
            this.txtyearlevel.Multiline = true;
            this.txtyearlevel.Name = "txtyearlevel";
            this.txtyearlevel.Size = new System.Drawing.Size(438, 42);
            this.txtyearlevel.TabIndex = 169;
            // 
            // llblcoursename
            // 
            this.llblcoursename.AutoSize = true;
            this.llblcoursename.Location = new System.Drawing.Point(71, 277);
            this.llblcoursename.Name = "llblcoursename";
            this.llblcoursename.Size = new System.Drawing.Size(96, 16);
            this.llblcoursename.TabIndex = 168;
            this.llblcoursename.Text = "Course Name :";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(73, 485);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(115, 37);
            this.btnAdd.TabIndex = 167;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(-8, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1487, 69);
            this.panel1.TabIndex = 166;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(524, 485);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(115, 37);
            this.btnClear.TabIndex = 165;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblSectionName
            // 
            this.lblSectionName.AutoSize = true;
            this.lblSectionName.Location = new System.Drawing.Point(71, 340);
            this.lblSectionName.Name = "lblSectionName";
            this.lblSectionName.Size = new System.Drawing.Size(98, 16);
            this.lblSectionName.TabIndex = 164;
            this.lblSectionName.Text = "Section Name :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(732, 116);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 163;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtsectionname
            // 
            this.txtsectionname.Location = new System.Drawing.Point(193, 330);
            this.txtsectionname.Multiline = true;
            this.txtsectionname.Name = "txtsectionname";
            this.txtsectionname.Size = new System.Drawing.Size(438, 42);
            this.txtsectionname.TabIndex = 162;
            // 
            // lblear_level
            // 
            this.lblear_level.AutoSize = true;
            this.lblear_level.Location = new System.Drawing.Point(71, 407);
            this.lblear_level.Name = "lblear_level";
            this.lblear_level.Size = new System.Drawing.Size(81, 16);
            this.lblear_level.TabIndex = 161;
            this.lblear_level.Text = "Year Level : ";
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(854, 111);
            this.txtsearch.Multiline = true;
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(430, 42);
            this.txtsearch.TabIndex = 160;
            this.txtsearch.TextChanged += new System.EventHandler(this.txtsearch_TextChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(379, 485);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(115, 37);
            this.btnUpdate.TabIndex = 159;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(227, 485);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(115, 37);
            this.btnDelete.TabIndex = 158;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // DGVSectiontinfo
            // 
            this.DGVSectiontinfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVSectiontinfo.Location = new System.Drawing.Point(681, 198);
            this.DGVSectiontinfo.Name = "DGVSectiontinfo";
            this.DGVSectiontinfo.RowHeadersWidth = 51;
            this.DGVSectiontinfo.RowTemplate.Height = 24;
            this.DGVSectiontinfo.Size = new System.Drawing.Size(754, 594);
            this.DGVSectiontinfo.TabIndex = 156;
            this.DGVSectiontinfo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVSectiontinfo_CellClick);
            this.DGVSectiontinfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVSectiontinfo_CellContentClick);
            // 
            // lblsectioninfo
            // 
            this.lblsectioninfo.AutoSize = true;
            this.lblsectioninfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsectioninfo.Location = new System.Drawing.Point(258, 124);
            this.lblsectioninfo.Name = "lblsectioninfo";
            this.lblsectioninfo.Size = new System.Drawing.Size(219, 29);
            this.lblsectioninfo.TabIndex = 155;
            this.lblsectioninfo.Text = "Section Information";
            // 
            // cmbcoursename
            // 
            this.cmbcoursename.FormattingEnabled = true;
            this.cmbcoursename.Location = new System.Drawing.Point(193, 274);
            this.cmbcoursename.Name = "cmbcoursename";
            this.cmbcoursename.Size = new System.Drawing.Size(438, 24);
            this.cmbcoursename.TabIndex = 170;
            // 
            // btndashboard
            // 
            this.btndashboard.Location = new System.Drawing.Point(1153, 16);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(93, 37);
            this.btndashboard.TabIndex = 115;
            this.btndashboard.Text = "DashBoard";
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // CourseSection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1478, 873);
            this.Controls.Add(this.cmbcoursename);
            this.Controls.Add(this.txtyearlevel);
            this.Controls.Add(this.llblcoursename);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblSectionName);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtsectionname);
            this.Controls.Add(this.lblear_level);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.DGVSectiontinfo);
            this.Controls.Add(this.lblsectioninfo);
            this.Name = "CourseSection";
            this.Text = "CourseSection";
            this.Load += new System.EventHandler(this.CourseSection_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSectiontinfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtyearlevel;
        private System.Windows.Forms.Label llblcoursename;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblSectionName;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtsectionname;
        private System.Windows.Forms.Label lblear_level;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DataGridView DGVSectiontinfo;
        private System.Windows.Forms.Label lblsectioninfo;
        private System.Windows.Forms.ComboBox cmbcoursename;
        private System.Windows.Forms.Button btndashboard;
    }
}