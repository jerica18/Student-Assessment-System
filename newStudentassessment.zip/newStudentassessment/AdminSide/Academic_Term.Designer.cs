﻿namespace newStudentassessment
{
    partial class Academic_Term
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEndDate = new System.Windows.Forms.TextBox();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.txtStartdate = new System.Windows.Forms.TextBox();
            this.lblschoolyear = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblsemester = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSem = new System.Windows.Forms.TextBox();
            this.lblStartsdate = new System.Windows.Forms.Label();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtschoolyear = new System.Windows.Forms.TextBox();
            this.DGVTermtinfo = new System.Windows.Forms.DataGridView();
            this.lblTerminfo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.btndashboard = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGVTermtinfo)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtEndDate
            // 
            this.txtEndDate.Location = new System.Drawing.Point(174, 489);
            this.txtEndDate.Multiline = true;
            this.txtEndDate.Name = "txtEndDate";
            this.txtEndDate.Size = new System.Drawing.Size(438, 42);
            this.txtEndDate.TabIndex = 187;
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(52, 501);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(72, 16);
            this.lblEndDate.TabIndex = 186;
            this.lblEndDate.Text = "End Date : ";
            // 
            // txtStartdate
            // 
            this.txtStartdate.Location = new System.Drawing.Point(174, 408);
            this.txtStartdate.Multiline = true;
            this.txtStartdate.Name = "txtStartdate";
            this.txtStartdate.Size = new System.Drawing.Size(438, 42);
            this.txtStartdate.TabIndex = 185;
            // 
            // lblschoolyear
            // 
            this.lblschoolyear.AutoSize = true;
            this.lblschoolyear.Location = new System.Drawing.Point(52, 290);
            this.lblschoolyear.Name = "lblschoolyear";
            this.lblschoolyear.Size = new System.Drawing.Size(85, 16);
            this.lblschoolyear.TabIndex = 184;
            this.lblschoolyear.Text = "School year :";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(55, 575);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(115, 37);
            this.btnAdd.TabIndex = 183;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(506, 575);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(115, 37);
            this.btnClear.TabIndex = 182;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblsemester
            // 
            this.lblsemester.AutoSize = true;
            this.lblsemester.Location = new System.Drawing.Point(52, 353);
            this.lblsemester.Name = "lblsemester";
            this.lblsemester.Size = new System.Drawing.Size(71, 16);
            this.lblsemester.TabIndex = 181;
            this.lblsemester.Text = "Semester :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(713, 129);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 180;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSem
            // 
            this.txtSem.Location = new System.Drawing.Point(174, 343);
            this.txtSem.Multiline = true;
            this.txtSem.Name = "txtSem";
            this.txtSem.Size = new System.Drawing.Size(438, 42);
            this.txtSem.TabIndex = 179;
            // 
            // lblStartsdate
            // 
            this.lblStartsdate.AutoSize = true;
            this.lblStartsdate.Location = new System.Drawing.Point(52, 420);
            this.lblStartsdate.Name = "lblStartsdate";
            this.lblStartsdate.Size = new System.Drawing.Size(75, 16);
            this.lblStartsdate.TabIndex = 178;
            this.lblStartsdate.Text = "Start Date : ";
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(835, 124);
            this.txtsearch.Multiline = true;
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(430, 42);
            this.txtsearch.TabIndex = 177;
            this.txtsearch.TextChanged += new System.EventHandler(this.txtsearch_TextChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(361, 575);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(115, 37);
            this.btnUpdate.TabIndex = 176;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(209, 575);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(115, 37);
            this.btnDelete.TabIndex = 175;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtschoolyear
            // 
            this.txtschoolyear.Location = new System.Drawing.Point(174, 275);
            this.txtschoolyear.Multiline = true;
            this.txtschoolyear.Name = "txtschoolyear";
            this.txtschoolyear.Size = new System.Drawing.Size(438, 42);
            this.txtschoolyear.TabIndex = 174;
            // 
            // DGVTermtinfo
            // 
            this.DGVTermtinfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVTermtinfo.Location = new System.Drawing.Point(696, 211);
            this.DGVTermtinfo.Name = "DGVTermtinfo";
            this.DGVTermtinfo.RowHeadersWidth = 51;
            this.DGVTermtinfo.RowTemplate.Height = 24;
            this.DGVTermtinfo.Size = new System.Drawing.Size(721, 594);
            this.DGVTermtinfo.TabIndex = 173;
            this.DGVTermtinfo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVTermtinfo_CellClick);
            this.DGVTermtinfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVTermtinfo_CellContentClick);
            // 
            // lblTerminfo
            // 
            this.lblTerminfo.AutoSize = true;
            this.lblTerminfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTerminfo.Location = new System.Drawing.Point(239, 137);
            this.lblTerminfo.Name = "lblTerminfo";
            this.lblTerminfo.Size = new System.Drawing.Size(196, 29);
            this.lblTerminfo.TabIndex = 172;
            this.lblTerminfo.Text = "Term Information";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(-2, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1816, 69);
            this.panel1.TabIndex = 171;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // btndashboard
            // 
            this.btndashboard.Location = new System.Drawing.Point(1130, 16);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(93, 37);
            this.btndashboard.TabIndex = 115;
            this.btndashboard.Text = "DashBoard";
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // Academic_Term
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1397, 846);
            this.Controls.Add(this.txtEndDate);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.txtStartdate);
            this.Controls.Add(this.lblschoolyear);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblsemester);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSem);
            this.Controls.Add(this.lblStartsdate);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtschoolyear);
            this.Controls.Add(this.DGVTermtinfo);
            this.Controls.Add(this.lblTerminfo);
            this.Controls.Add(this.panel1);
            this.Name = "Academic_Term";
            this.Text = "Academic_Term";
            this.Load += new System.EventHandler(this.Academic_Term_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGVTermtinfo)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtEndDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.TextBox txtStartdate;
        private System.Windows.Forms.Label lblschoolyear;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblsemester;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSem;
        private System.Windows.Forms.Label lblStartsdate;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtschoolyear;
        private System.Windows.Forms.DataGridView DGVTermtinfo;
        private System.Windows.Forms.Label lblTerminfo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btndashboard;
    }
}