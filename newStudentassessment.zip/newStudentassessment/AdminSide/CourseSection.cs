﻿using newStudentassessment.DBContext;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using newStudentassessment.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newStudentassessment
{
    public partial class CourseSection : Form
    {
        ISection MySQLContext = new MySQLSection();
        ICourseName Mysqlcontext = new MySQLGetCourseNameContext();
        public CourseSection()
        {
            InitializeComponent();
        }

        private void CourseSection_Load(object sender, EventArgs e)
        {
            CourseName_repo repo = new CourseName_repo(Mysqlcontext);

            List<Course> courses = repo.getcoursenames();

            courses.Insert(0, new Course { CourseId = 0, CourseName = "" });

            cmbcoursename.DataSource = courses;
            cmbcoursename.DisplayMember = "CourseName";
            cmbcoursename.ValueMember = "CourseId";

            cmbcoursename.SelectedIndex = 0;
            showSection();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedCourseId = (int)cmbcoursename.SelectedValue;
                Section_repo repo = new Section_repo(MySQLContext);
                Section section = new Section()
                {
                    course_id = selectedCourseId,
                    sectionName = txtsectionname.Text,
                    year_level = txtyearlevel.Text
                };
                repo.AddSection(section);
                    MessageBox.Show("Section Added.", "New Section",
                          MessageBoxButtons.OK, MessageBoxIcon.Information);
                showSection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding Section: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                Section_repo repo = new Section_repo(MySQLContext);

                int sectionId = Convert.ToInt32(DGVSectiontinfo.SelectedRows[0].Cells["sectionID"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    repo.deleteSection(sectionId);
                    MessageBox.Show("Section record deleted successfully.");
                    showSection();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void DGVSectiontinfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DGVSectiontinfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGVSectiontinfo.MultiSelect = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int selectedCourseId = (int)cmbcoursename.SelectedValue;
            Section_repo repo = new Section_repo(MySQLContext);

            try
            {
                Section s = new Section()
                {
                    sectionID = Convert.ToInt32(DGVSectiontinfo.SelectedRows[0].Cells["sectionID"].Value),
                    course_id = selectedCourseId,
                    sectionName = txtsectionname.Text,
                    year_level = txtyearlevel.Text

                };

                repo.updateSection(s);
                MessageBox.Show("Updated Section Record.", "Updated Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                showSection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cmbcoursename.SelectedIndex = -1;
            txtsectionname.Clear();
            txtyearlevel.Clear();
        }

        private void showSection()
        {
            Section_repo repo = new Section_repo(MySQLContext);
            List<Section> section = repo.getsectionlist();
            DGVSectiontinfo.DataSource = section;


            

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Section_repo repo = new Section_repo(MySQLContext);
            string search = txtsearch.Text.Trim();

            BindingSource bs = new BindingSource();

            if (int.TryParse(search, out int id))
            {
                List<Section> list = new List<Section>();

               
                var bySectionId = repo.getSectionId(id);
                if (bySectionId != null)
                    list.Add(bySectionId);

               
                var byCourseId = repo.getCourseID(id);
                if (byCourseId != null)
                    list.AddRange(byCourseId);


                bs.DataSource = list;
            }
            else
            {
                
                bs.DataSource = repo.getSectionName(search);
            }

            DGVSectiontinfo.AutoGenerateColumns = true;
            DGVSectiontinfo.DataSource = bs;


        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string student = txtsearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(student))
            {
                showSection();
            }
        }

        private void DGVSectiontinfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVSectiontinfo.Rows[e.RowIndex];
                {
                    int sectionId = Convert.ToInt32(DGVSectiontinfo.SelectedRows[0].Cells["sectionID"].Value);
                    cmbcoursename.SelectedValue = Convert.ToInt32(row.Cells["course_id"].Value);
                    txtsectionname.Text = row.Cells["sectionName"].Value.ToString();
                    txtyearlevel.Text = row.Cells["year_level"].Value.ToString();
                }
            }
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            AdminFrontPage AdminForm = new AdminFrontPage();
            AdminForm.Show();
            this.Close();
        }
    }
}
