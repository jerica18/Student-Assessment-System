﻿namespace newStudentassessment
{
    partial class AdminFrontPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.lblSAS = new System.Windows.Forms.Label();
            this.btncourse = new System.Windows.Forms.Button();
            this.btnStudentInfo = new System.Windows.Forms.Button();
            this.btnAssignments = new System.Windows.Forms.Button();
            this.btnteacherinfo = new System.Windows.Forms.Button();
            this.btnSection = new System.Windows.Forms.Button();
            this.btnTerm = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btndashboard = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btnLogOut);
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(-4, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1416, 69);
            this.panel1.TabIndex = 2;
            // 
            // btnLogOut
            // 
            this.btnLogOut.Location = new System.Drawing.Point(1443, 15);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(100, 32);
            this.btnLogOut.TabIndex = 14;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(177, 16);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // btncourse
            // 
            this.btncourse.Location = new System.Drawing.Point(58, 429);
            this.btncourse.Name = "btncourse";
            this.btncourse.Size = new System.Drawing.Size(174, 40);
            this.btncourse.TabIndex = 16;
            this.btncourse.Text = "Course";
            this.btncourse.UseVisualStyleBackColor = true;
            this.btncourse.Click += new System.EventHandler(this.btncourse_Click);
            // 
            // btnStudentInfo
            // 
            this.btnStudentInfo.Location = new System.Drawing.Point(58, 235);
            this.btnStudentInfo.Name = "btnStudentInfo";
            this.btnStudentInfo.Size = new System.Drawing.Size(174, 40);
            this.btnStudentInfo.TabIndex = 12;
            this.btnStudentInfo.Text = "Student Info";
            this.btnStudentInfo.UseVisualStyleBackColor = true;
            this.btnStudentInfo.Click += new System.EventHandler(this.btnStudentInfo_Click);
            // 
            // btnAssignments
            // 
            this.btnAssignments.Location = new System.Drawing.Point(58, 624);
            this.btnAssignments.Name = "btnAssignments";
            this.btnAssignments.Size = new System.Drawing.Size(174, 40);
            this.btnAssignments.TabIndex = 13;
            this.btnAssignments.Text = "Assignments";
            this.btnAssignments.UseVisualStyleBackColor = true;
            this.btnAssignments.Click += new System.EventHandler(this.btnAssignments_Click);
            // 
            // btnteacherinfo
            // 
            this.btnteacherinfo.Location = new System.Drawing.Point(58, 142);
            this.btnteacherinfo.Name = "btnteacherinfo";
            this.btnteacherinfo.Size = new System.Drawing.Size(174, 40);
            this.btnteacherinfo.TabIndex = 15;
            this.btnteacherinfo.Text = "Teacher Info";
            this.btnteacherinfo.UseVisualStyleBackColor = true;
            this.btnteacherinfo.Click += new System.EventHandler(this.btnteacherinfo_Click);
            // 
            // btnSection
            // 
            this.btnSection.Location = new System.Drawing.Point(58, 527);
            this.btnSection.Name = "btnSection";
            this.btnSection.Size = new System.Drawing.Size(174, 40);
            this.btnSection.TabIndex = 11;
            this.btnSection.Text = "Sections";
            this.btnSection.UseVisualStyleBackColor = true;
            this.btnSection.Click += new System.EventHandler(this.btnSection_Click);
            // 
            // btnTerm
            // 
            this.btnTerm.Location = new System.Drawing.Point(58, 719);
            this.btnTerm.Name = "btnTerm";
            this.btnTerm.Size = new System.Drawing.Size(174, 40);
            this.btnTerm.TabIndex = 14;
            this.btnTerm.Text = "Term Management";
            this.btnTerm.UseVisualStyleBackColor = true;
            this.btnTerm.Click += new System.EventHandler(this.btnTerm_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(58, 331);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(174, 40);
            this.button5.TabIndex = 7;
            this.button5.Text = "Subject ";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btndashboard
            // 
            this.btndashboard.Location = new System.Drawing.Point(58, 57);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(174, 40);
            this.btndashboard.TabIndex = 3;
            this.btndashboard.Text = "Dashboard";
            this.btndashboard.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Controls.Add(this.btndashboard);
            this.panel2.Controls.Add(this.btnTerm);
            this.panel2.Controls.Add(this.btnteacherinfo);
            this.panel2.Controls.Add(this.btnStudentInfo);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.btncourse);
            this.panel2.Controls.Add(this.btnSection);
            this.panel2.Controls.Add(this.btnAssignments);
            this.panel2.Location = new System.Drawing.Point(0, 71);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(305, 857);
            this.panel2.TabIndex = 3;
            // 
            // AdminFrontPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1411, 882);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "AdminFrontPage";
            this.Text = "AdminFrontPage";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btnSection;
        private System.Windows.Forms.Button btncourse;
        private System.Windows.Forms.Button btnStudentInfo;
        private System.Windows.Forms.Button btnAssignments;
        private System.Windows.Forms.Button btnteacherinfo;
        private System.Windows.Forms.Button btnTerm;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btndashboard;
        private System.Windows.Forms.Panel panel2;
    }
}