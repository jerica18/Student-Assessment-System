﻿using newStudentassessment.DBContext;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using newStudentassessment.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newStudentassessment
{
    public partial class StudentInformation : Form
    {
        IStudent MySQLContext = new MySQLStudentContext();
        public StudentInformation()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                Student_repo repo = new Student_repo(MySQLContext);
                int studentid = Convert.ToInt32(DGVStudentinfo.SelectedRows[0].Cells["studentid"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    repo.deleteStudentByID(studentid);
                    MessageBox.Show("Student record deleted successfully.");
                    showstudents();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void DGVStudentinfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DGVStudentinfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGVStudentinfo.MultiSelect = false;
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Student_repo repo = new Student_repo(MySQLContext);

            try
            {
               Student student = new Student();

                student.studentid = Convert.ToInt32(DGVStudentinfo.SelectedRows[0].Cells["studentid"].Value);
                student.setAccountID(Convert.ToInt32(txtaccountid.Text));
                student.LastName = txtlastname.Text;
                student.FirstName = txtfirstname.Text;
                student.MiddleName = txtmiddlename.Text;
                student.Contact_number = txtcontactnum.Text;
                student.Email = txtemail.Text;

                

                repo.updateStudentRec(student);
                MessageBox.Show("Updated Student Record.", "Updated Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                showstudents();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtaccountid.Clear();
            txtlastname.Clear();
            txtfirstname.Clear();
            txtmiddlename.Clear();
            txtcontactnum.Clear();
            txtemail.Clear();
        }

        private void DGVStudentinfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVStudentinfo.Rows[e.RowIndex];

                int StudentID = Convert.ToInt32(row.Cells["studentid"].Value);
                txtaccountid.Text = row.Cells["accountID"].Value.ToString();
                txtfirstname.Text = row.Cells["FirstName"].Value.ToString();
                txtmiddlename.Text = row.Cells["MiddleName"].Value.ToString();
                txtlastname.Text = row.Cells["LastName"].Value.ToString();
                txtcontactnum.Text = row.Cells["contact_number"].Value.ToString();
                txtemail.Text = row.Cells["email"].Value.ToString();
            }
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            Student_repo repo = new Student_repo(MySQLContext);

            string search = txtsearch.Text.Trim();
            BindingSource bs = new BindingSource();

            if (int.TryParse(search, out int studentId))
            {
                Student student = repo.getStudentByID(studentId);
                if (student != null)
                    bs.Add(student);
            }
            else
            {
                Student student = repo.getStudentsByLname(search);
                if (student != null)
                    bs.Add(student);
            }

            DGVStudentinfo.DataSource = bs;




        }

        private void showstudents()
        {
            try
            {
                Student_repo repo = new Student_repo(MySQLContext);
                List<Student> student = repo.getStudents();
                DGVStudentinfo.DataSource = student;
                DGVStudentinfo.Columns["Id"].Visible = false;
                DGVStudentinfo.Columns["Account_Type"].Visible = false;
                DGVStudentinfo.Columns["accountID"].Visible = false;



            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Students: " + ex.Message);
            }
        }


        private void StudentInformation_Load(object sender, EventArgs e)
        {
            showstudents();
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string student = txtsearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(student))
            {
                showstudents(); 
            }
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            Form1 mainForm = new Form1();
            mainForm.Show();
            this.Close();
        }
    }
}
