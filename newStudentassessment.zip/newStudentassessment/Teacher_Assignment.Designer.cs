﻿namespace newStudentassessment
{
    partial class Teacher_Assignment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblterm = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblschedule = new System.Windows.Forms.Label();
            this.txtsub = new System.Windows.Forms.TextBox();
            this.lblsub = new System.Windows.Forms.Label();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtteacher = new System.Windows.Forms.TextBox();
            this.DGVAssignmet = new System.Windows.Forms.DataGridView();
            this.lblteacher = new System.Windows.Forms.Label();
            this.lblAssignmetinfo = new System.Windows.Forms.Label();
            this.lblstarttime = new System.Windows.Forms.Label();
            this.lblendtime = new System.Windows.Forms.Label();
            this.txtschedule = new System.Windows.Forms.TextBox();
            this.txtterm = new System.Windows.Forms.TextBox();
            this.txtstarttime = new System.Windows.Forms.TextBox();
            this.txtendtime = new System.Windows.Forms.TextBox();
            this.btndashboard = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVAssignmet)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(76, 676);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(115, 37);
            this.btnAdd.TabIndex = 150;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(-19, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1502, 69);
            this.panel1.TabIndex = 149;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(527, 676);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(115, 37);
            this.btnClear.TabIndex = 148;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblterm
            // 
            this.lblterm.AutoSize = true;
            this.lblterm.Location = new System.Drawing.Point(53, 341);
            this.lblterm.Name = "lblterm";
            this.lblterm.Size = new System.Drawing.Size(61, 16);
            this.lblterm.TabIndex = 147;
            this.lblterm.Text = "Term ID :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(721, 117);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 146;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblschedule
            // 
            this.lblschedule.AutoSize = true;
            this.lblschedule.Location = new System.Drawing.Point(50, 476);
            this.lblschedule.Name = "lblschedule";
            this.lblschedule.Size = new System.Drawing.Size(146, 16);
            this.lblschedule.TabIndex = 145;
            this.lblschedule.Text = "Assignment Schedule  :";
            // 
            // txtsub
            // 
            this.txtsub.Location = new System.Drawing.Point(209, 394);
            this.txtsub.Multiline = true;
            this.txtsub.Name = "txtsub";
            this.txtsub.Size = new System.Drawing.Size(438, 42);
            this.txtsub.TabIndex = 144;
            // 
            // lblsub
            // 
            this.lblsub.AutoSize = true;
            this.lblsub.Location = new System.Drawing.Point(53, 408);
            this.lblsub.Name = "lblsub";
            this.lblsub.Size = new System.Drawing.Size(74, 16);
            this.lblsub.TabIndex = 143;
            this.lblsub.Text = "Subject ID :";
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(843, 112);
            this.txtsearch.Multiline = true;
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(430, 42);
            this.txtsearch.TabIndex = 142;
            this.txtsearch.TextChanged += new System.EventHandler(this.txtsearch_TextChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(382, 676);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(115, 37);
            this.btnUpdate.TabIndex = 141;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(230, 676);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(115, 37);
            this.btnDelete.TabIndex = 140;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtteacher
            // 
            this.txtteacher.Location = new System.Drawing.Point(209, 263);
            this.txtteacher.Multiline = true;
            this.txtteacher.Name = "txtteacher";
            this.txtteacher.Size = new System.Drawing.Size(438, 42);
            this.txtteacher.TabIndex = 139;
            // 
            // DGVAssignmet
            // 
            this.DGVAssignmet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVAssignmet.Location = new System.Drawing.Point(695, 199);
            this.DGVAssignmet.Name = "DGVAssignmet";
            this.DGVAssignmet.RowHeadersWidth = 51;
            this.DGVAssignmet.RowTemplate.Height = 24;
            this.DGVAssignmet.Size = new System.Drawing.Size(727, 594);
            this.DGVAssignmet.TabIndex = 138;
            this.DGVAssignmet.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVAssignmet_CellClick);
            this.DGVAssignmet.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVAssignmet_CellContentClick);
            // 
            // lblteacher
            // 
            this.lblteacher.AutoSize = true;
            this.lblteacher.Location = new System.Drawing.Point(53, 277);
            this.lblteacher.Name = "lblteacher";
            this.lblteacher.Size = new System.Drawing.Size(80, 16);
            this.lblteacher.TabIndex = 137;
            this.lblteacher.Text = "Teacher ID :";
            // 
            // lblAssignmetinfo
            // 
            this.lblAssignmetinfo.AutoSize = true;
            this.lblAssignmetinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignmetinfo.Location = new System.Drawing.Point(247, 125);
            this.lblAssignmetinfo.Name = "lblAssignmetinfo";
            this.lblAssignmetinfo.Size = new System.Drawing.Size(250, 29);
            this.lblAssignmetinfo.TabIndex = 136;
            this.lblAssignmetinfo.Text = "Assignmet Information";
            // 
            // lblstarttime
            // 
            this.lblstarttime.AutoSize = true;
            this.lblstarttime.Location = new System.Drawing.Point(53, 531);
            this.lblstarttime.Name = "lblstarttime";
            this.lblstarttime.Size = new System.Drawing.Size(74, 16);
            this.lblstarttime.TabIndex = 153;
            this.lblstarttime.Text = "Start Time :";
            // 
            // lblendtime
            // 
            this.lblendtime.AutoSize = true;
            this.lblendtime.Location = new System.Drawing.Point(56, 598);
            this.lblendtime.Name = "lblendtime";
            this.lblendtime.Size = new System.Drawing.Size(71, 16);
            this.lblendtime.TabIndex = 155;
            this.lblendtime.Text = "End Time :";
            // 
            // txtschedule
            // 
            this.txtschedule.Location = new System.Drawing.Point(209, 465);
            this.txtschedule.Multiline = true;
            this.txtschedule.Name = "txtschedule";
            this.txtschedule.Size = new System.Drawing.Size(438, 42);
            this.txtschedule.TabIndex = 156;
            // 
            // txtterm
            // 
            this.txtterm.Location = new System.Drawing.Point(209, 327);
            this.txtterm.Multiline = true;
            this.txtterm.Name = "txtterm";
            this.txtterm.Size = new System.Drawing.Size(438, 42);
            this.txtterm.TabIndex = 157;
            // 
            // txtstarttime
            // 
            this.txtstarttime.Location = new System.Drawing.Point(209, 531);
            this.txtstarttime.Multiline = true;
            this.txtstarttime.Name = "txtstarttime";
            this.txtstarttime.Size = new System.Drawing.Size(438, 42);
            this.txtstarttime.TabIndex = 158;
            // 
            // txtendtime
            // 
            this.txtendtime.Location = new System.Drawing.Point(209, 595);
            this.txtendtime.Multiline = true;
            this.txtendtime.Name = "txtendtime";
            this.txtendtime.Size = new System.Drawing.Size(438, 42);
            this.txtendtime.TabIndex = 159;
            // 
            // btndashboard
            // 
            this.btndashboard.Location = new System.Drawing.Point(1148, 16);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(93, 37);
            this.btndashboard.TabIndex = 115;
            this.btndashboard.Text = "DashBoard";
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // Teacher_Assignment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1465, 882);
            this.Controls.Add(this.txtendtime);
            this.Controls.Add(this.txtstarttime);
            this.Controls.Add(this.txtterm);
            this.Controls.Add(this.txtschedule);
            this.Controls.Add(this.lblendtime);
            this.Controls.Add(this.lblstarttime);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblterm);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblschedule);
            this.Controls.Add(this.txtsub);
            this.Controls.Add(this.lblsub);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtteacher);
            this.Controls.Add(this.DGVAssignmet);
            this.Controls.Add(this.lblteacher);
            this.Controls.Add(this.lblAssignmetinfo);
            this.Name = "Teacher_Assignment";
            this.Text = "Teacher_Assignment";
            this.Load += new System.EventHandler(this.Teacher_Assignment_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVAssignmet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblterm;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblschedule;
        private System.Windows.Forms.TextBox txtsub;
        private System.Windows.Forms.Label lblsub;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtteacher;
        private System.Windows.Forms.DataGridView DGVAssignmet;
        private System.Windows.Forms.Label lblteacher;
        private System.Windows.Forms.Label lblAssignmetinfo;
        private System.Windows.Forms.Label lblstarttime;
        private System.Windows.Forms.Label lblendtime;
        private System.Windows.Forms.TextBox txtschedule;
        private System.Windows.Forms.TextBox txtterm;
        private System.Windows.Forms.TextBox txtstarttime;
        private System.Windows.Forms.TextBox txtendtime;
        private System.Windows.Forms.Button btndashboard;
    }
}