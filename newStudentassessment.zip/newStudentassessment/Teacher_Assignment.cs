﻿using newStudentassessment.DBContext;
using newStudentassessment.Interfaces;
using newStudentassessment.Models;
using newStudentassessment.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newStudentassessment
{
    public partial class Teacher_Assignment : Form
    {
        IAssignment MySQLContext = new MySQLAssignmentContext();

        public Teacher_Assignment()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Assignment_repo repo = new Assignment_repo(MySQLContext);

            Assignment assignment = new Assignment()
            {
                TeacherId = Convert.ToInt32(txtteacher),
                term_id = Convert.ToInt32(txtterm),
                SubjectID = Convert.ToInt32(txtsub),
                Assignment_Schedule = txtschedule.Text,
                Start_time = txtstarttime.Text,
                End_time = txtendtime.Text
            };
            repo.AddAssignment(assignment);
            MessageBox.Show("Assignment Added.", "New Assignment",
                         MessageBoxButtons.OK, MessageBoxIcon.Information);
            showtAssignment();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            try
            {
                Assignment_repo repo = new Assignment_repo(MySQLContext);

                int assignmentId = Convert.ToInt32(DGVAssignmet.SelectedRows[0].Cells["Assignment_ID"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    repo.DeleteAssignment(assignmentId);
                    MessageBox.Show("Assignment record deleted successfully.");
                    showtAssignment();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }

        }

        private void DGVAssignmet_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DGVAssignmet.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGVAssignmet.MultiSelect = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Assignment_repo repo = new Assignment_repo(MySQLContext);

                Assignment assignment = new Assignment()
                {
                    Assignment_ID = Convert.ToInt32(DGVAssignmet.SelectedRows[0].Cells["Assignment_ID"].Value),
                    TeacherId = Convert.ToInt32(txtteacher.Text),
                    term_id = Convert.ToInt32(txtterm.Text),
                    SubjectID = Convert.ToInt32(txtsub.Text),
                    Assignment_Schedule = txtschedule.Text,
                    Start_time = txtstarttime.Text,
                    End_time = txtendtime.Text

                };
                repo.updateAssignment(assignment);
                showtAssignment();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtteacher.Clear();
            txtterm.Clear();
            txtsub.Clear();
            txtschedule.Clear();
            txtstarttime.Clear();
            txtendtime.Clear();
        }

        private void showtAssignment()
        {
                Assignment_repo repo = new Assignment_repo(MySQLContext);
                List<Assignment> assignment = repo.AssignmentList();
                DGVAssignmet.DataSource = assignment;
            
        }

        private void Teacher_Assignment_Load(object sender, EventArgs e)
        {
            showtAssignment();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Assignment_repo repo = new Assignment_repo(MySQLContext);
            string search = txtsearch.Text.Trim();
            BindingSource bs = new BindingSource();

            if (int.TryParse(search, out int id))
            {
                List<Assignment> list = new List<Assignment>();

                var byempID = repo.getbyempID(id);
                if (byempID != null)
                    list.AddRange(byempID);

                var byAssignmentID = repo.getbyassignmentID(id);
                if (byAssignmentID != null)
                    list.Add(byAssignmentID);

                bs.DataSource = list;

            }
            

                DGVAssignmet.AutoGenerateColumns = true;
            DGVAssignmet.DataSource = bs;


        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string student = txtsearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(student))
            {
                showtAssignment();
            }
        }

        private void DGVAssignmet_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVAssignmet.Rows[e.RowIndex];
                {
                    int assignmentId = Convert.ToInt32(DGVAssignmet.SelectedRows[0].Cells["Assignment_ID"].Value);
                    txtteacher.Text = row.Cells["TeacherId"].Value.ToString();
                    txtterm.Text = row.Cells["term_id"].Value.ToString();
                    txtsub.Text = row.Cells["SubjectID"].Value.ToString();
                    txtschedule.Text = row.Cells["Assignment_Schedule"].Value.ToString();
                    txtstarttime.Text = row.Cells["Start_time"].Value.ToString();
                    txtendtime.Text = row.Cells["End_time"].Value.ToString();
                }
            }
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            Form1 mainForm = new Form1();
            mainForm.Show();
            this.Close();
        }
    }
}
