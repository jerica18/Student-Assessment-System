﻿namespace newStudentassessment
{
    partial class CourseInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblcoursecode = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtcode = new System.Windows.Forms.TextBox();
            this.lbldurationyear = new System.Windows.Forms.Label();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtcoursename = new System.Windows.Forms.TextBox();
            this.DGVCoursetinfo = new System.Windows.Forms.DataGridView();
            this.lblCourseinfo = new System.Windows.Forms.Label();
            this.llblcoursename = new System.Windows.Forms.Label();
            this.txtyear = new System.Windows.Forms.TextBox();
            this.btndashboard = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCoursetinfo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(72, 485);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(115, 37);
            this.btnAdd.TabIndex = 150;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(-9, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1816, 69);
            this.panel1.TabIndex = 149;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(523, 485);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(115, 37);
            this.btnClear.TabIndex = 148;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblcoursecode
            // 
            this.lblcoursecode.AutoSize = true;
            this.lblcoursecode.Location = new System.Drawing.Point(70, 340);
            this.lblcoursecode.Name = "lblcoursecode";
            this.lblcoursecode.Size = new System.Drawing.Size(92, 16);
            this.lblcoursecode.TabIndex = 147;
            this.lblcoursecode.Text = "Course Code :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(731, 116);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 146;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtcode
            // 
            this.txtcode.Location = new System.Drawing.Point(192, 330);
            this.txtcode.Multiline = true;
            this.txtcode.Name = "txtcode";
            this.txtcode.Size = new System.Drawing.Size(438, 42);
            this.txtcode.TabIndex = 144;
            // 
            // lbldurationyear
            // 
            this.lbldurationyear.AutoSize = true;
            this.lbldurationyear.Location = new System.Drawing.Point(70, 407);
            this.lbldurationyear.Name = "lbldurationyear";
            this.lbldurationyear.Size = new System.Drawing.Size(103, 16);
            this.lbldurationyear.TabIndex = 143;
            this.lbldurationyear.Text = "Duration years : ";
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(853, 111);
            this.txtsearch.Multiline = true;
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(430, 42);
            this.txtsearch.TabIndex = 142;
            this.txtsearch.TextChanged += new System.EventHandler(this.txtsearch_TextChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(378, 485);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(115, 37);
            this.btnUpdate.TabIndex = 141;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(226, 485);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(115, 37);
            this.btnDelete.TabIndex = 140;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtcoursename
            // 
            this.txtcoursename.Location = new System.Drawing.Point(192, 262);
            this.txtcoursename.Multiline = true;
            this.txtcoursename.Name = "txtcoursename";
            this.txtcoursename.Size = new System.Drawing.Size(438, 42);
            this.txtcoursename.TabIndex = 139;
            // 
            // DGVCoursetinfo
            // 
            this.DGVCoursetinfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVCoursetinfo.Location = new System.Drawing.Point(714, 198);
            this.DGVCoursetinfo.Name = "DGVCoursetinfo";
            this.DGVCoursetinfo.RowHeadersWidth = 51;
            this.DGVCoursetinfo.RowTemplate.Height = 24;
            this.DGVCoursetinfo.Size = new System.Drawing.Size(721, 594);
            this.DGVCoursetinfo.TabIndex = 138;
            this.DGVCoursetinfo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVCoursetinfo_CellClick);
            this.DGVCoursetinfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVCoursetinfo_CellContentClick);
            // 
            // lblCourseinfo
            // 
            this.lblCourseinfo.AutoSize = true;
            this.lblCourseinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourseinfo.Location = new System.Drawing.Point(257, 124);
            this.lblCourseinfo.Name = "lblCourseinfo";
            this.lblCourseinfo.Size = new System.Drawing.Size(216, 29);
            this.lblCourseinfo.TabIndex = 136;
            this.lblCourseinfo.Text = "Course Information";
            // 
            // llblcoursename
            // 
            this.llblcoursename.AutoSize = true;
            this.llblcoursename.Location = new System.Drawing.Point(70, 277);
            this.llblcoursename.Name = "llblcoursename";
            this.llblcoursename.Size = new System.Drawing.Size(96, 16);
            this.llblcoursename.TabIndex = 153;
            this.llblcoursename.Text = "Course Name :";
            // 
            // txtyear
            // 
            this.txtyear.Location = new System.Drawing.Point(192, 395);
            this.txtyear.Multiline = true;
            this.txtyear.Name = "txtyear";
            this.txtyear.Size = new System.Drawing.Size(438, 42);
            this.txtyear.TabIndex = 154;
            // 
            // btndashboard
            // 
            this.btndashboard.Location = new System.Drawing.Point(1144, 16);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(93, 37);
            this.btndashboard.TabIndex = 115;
            this.btndashboard.Text = "DashBoard";
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // CourseInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1802, 916);
            this.Controls.Add(this.txtyear);
            this.Controls.Add(this.llblcoursename);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblcoursecode);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtcode);
            this.Controls.Add(this.lbldurationyear);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtcoursename);
            this.Controls.Add(this.DGVCoursetinfo);
            this.Controls.Add(this.lblCourseinfo);
            this.Name = "CourseInformation";
            this.Text = "CourseInformation";
            this.Load += new System.EventHandler(this.CourseInformation_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCoursetinfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblcoursecode;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtcode;
        private System.Windows.Forms.Label lbldurationyear;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtcoursename;
        private System.Windows.Forms.DataGridView DGVCoursetinfo;
        private System.Windows.Forms.Label lblCourseinfo;
        private System.Windows.Forms.Label llblcoursename;
        private System.Windows.Forms.TextBox txtyear;
        private System.Windows.Forms.Button btndashboard;
    }
}