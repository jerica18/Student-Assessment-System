﻿using Student_Assessment_System.Course___Subject;
using Student_Assessment_System.DBContext.CourseRepo;
using Student_Assessment_System.Interface;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System
{
    public partial class CourseInfo : Form
    {    CourseRepo repo = new CourseRepo();

        ICourse MySQLContext = new CourseRepo();
        public CourseInfo()
        {
            InitializeComponent();
        }

        private void txtCourse_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblCoursenam_Click(object sender, EventArgs e)
        {

        }

        private void CourseInfo_Load(object sender, EventArgs e)
        {
            showcourse();

            //status 
            cmbstatus.Items.Add("Active");
            cmbstatus.Items.Add("Inactive");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
             Course course = new Course();

            course.Course_name = txtCourse.Text;
            course.Course_code = txtcoursecode.Text;
            course.Duration_years = txtdurationyears.Text;
            course.status = cmbstatus.Text;

            repo.SaveCourse(course);

            showcourse();


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
              DialogResult result = MessageBox.Show("Are you sure you want to delete this row ?","Confirm Deletion",
                   MessageBoxButtons.YesNo,MessageBoxIcon.Warning
                   );
            if (result == DialogResult.Yes)
            {
                int course_id = Convert.ToInt32(DGVSubjectCourse.SelectedRows[0].Cells["Course_Id"].Value);

                repo.RemoveCourse(course_id);

            }

            showcourse();
        }

        private void DGVSubjectCourse_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DGVSubjectCourse.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGVSubjectCourse.MultiSelect = false;
        }

        private void showcourse()
        {
            List<Course> listcourse = repo.Getallcourse();
            DGVSubjectCourse.DataSource = listcourse;

        }

        private void DGVSubjectCourse_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVSubjectCourse.Rows[e.RowIndex];

                int courseId = Convert.ToInt32(row.Cells["Course_id"].Value);
                txtCourse.Text = row.Cells["Course_name"].Value?.ToString();
                txtcoursecode.Text = row.Cells["Course_code"].Value?.ToString();
                txtdurationyears.Text = row.Cells["Duration_years"].Value?.ToString();
                cmbstatus.Text = row.Cells["status"].Value?.ToString();

            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Course course = new Course();

                course.Course_id = Convert.ToInt32(DGVSubjectCourse.SelectedRows[0].Cells["Course_Id"].Value);
                course.Course_name = txtCourse.Text;
                course.Course_code = txtcoursecode.Text;
                course.Duration_years = txtdurationyears.Text;
                course.status = cmbstatus.Text;

                repo.Updatecourse(course);

                showcourse();
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Please select a row to update, Thank you!",ex.Message);

            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtCourse.Clear();
            txtcoursecode.Clear();
            txtdurationyears.Clear();
            cmbstatus.SelectedIndex = -1;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
           string searh = txtCourseSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(searh)) 
            {
                showcourse();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtCourseSearch.Text.Trim();
            var results = new List<Course>();

            if (int.TryParse(search, out int CourseId))
            {
                var course = repo.GetCoursebyid(CourseId);
                if (course != null) results.Add(course);
            }
            else
            {
                var courseN = repo.GetCourseByCourseName(search);
                if (courseN != null) 
                    results.Add(courseN);
            }


                DGVSubjectCourse.DataSource = results;


        }
    }
}
