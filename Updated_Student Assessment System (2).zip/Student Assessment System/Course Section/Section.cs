﻿using Student_Assessment_System.Course___Subject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Course_Section
{
    public class Section 
    {
        public int Section_Id {  get; set; }
        public int Course_Id { get; set; }
        public int Subject_Id { get; set; }
        public string Section_name {  get; set; }
        public string Year_level { get; set; }

        
        
    }
}
