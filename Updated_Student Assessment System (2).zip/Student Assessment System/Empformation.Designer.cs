﻿namespace Student_Assessment_System
{
    partial class Empformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtcontactnum = new System.Windows.Forms.TextBox();
            this.lblContactnumber = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblBirthdate = new System.Windows.Forms.Label();
            this.txtMname = new System.Windows.Forms.TextBox();
            this.lblMiddlename = new System.Windows.Forms.Label();
            this.txtFname = new System.Windows.Forms.TextBox();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.txtseacrh = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtLname = new System.Windows.Forms.TextBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblSectionID = new System.Windows.Forms.Label();
            this.lblTeacherinfo = new System.Windows.Forms.Label();
            this.dtpbirthdate = new System.Windows.Forms.DateTimePicker();
            this.cmbdepartment = new System.Windows.Forms.ComboBox();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.mySqlDataAdapter1 = new MySql.Data.MySqlClient.MySqlDataAdapter();
            this.lblemptype = new System.Windows.Forms.Label();
            this.cmbemptype = new System.Windows.Forms.ComboBox();
            this.DGVteacherinfo = new System.Windows.Forms.DataGridView();
            this.btnclear = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVteacherinfo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1795, 69);
            this.panel1.TabIndex = 4;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(205, 696);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(416, 42);
            this.txtemail.TabIndex = 71;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(83, 710);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(47, 16);
            this.lblEmail.TabIndex = 70;
            this.lblEmail.Text = "Email :";
            // 
            // txtcontactnum
            // 
            this.txtcontactnum.Location = new System.Drawing.Point(205, 635);
            this.txtcontactnum.Multiline = true;
            this.txtcontactnum.Name = "txtcontactnum";
            this.txtcontactnum.Size = new System.Drawing.Size(416, 42);
            this.txtcontactnum.TabIndex = 69;
            // 
            // lblContactnumber
            // 
            this.lblContactnumber.AutoSize = true;
            this.lblContactnumber.Location = new System.Drawing.Point(83, 649);
            this.lblContactnumber.Name = "lblContactnumber";
            this.lblContactnumber.Size = new System.Drawing.Size(109, 16);
            this.lblContactnumber.TabIndex = 68;
            this.lblContactnumber.Text = "Contact Number :";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(83, 599);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(58, 16);
            this.lblgender.TabIndex = 66;
            this.lblgender.Text = "Gender :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(681, 116);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 65;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(205, 525);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(416, 42);
            this.txtAddress.TabIndex = 64;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(83, 539);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(64, 16);
            this.lblAddress.TabIndex = 63;
            this.lblAddress.Text = "Address :";
            // 
            // lblBirthdate
            // 
            this.lblBirthdate.AutoSize = true;
            this.lblBirthdate.Location = new System.Drawing.Point(83, 479);
            this.lblBirthdate.Name = "lblBirthdate";
            this.lblBirthdate.Size = new System.Drawing.Size(66, 16);
            this.lblBirthdate.TabIndex = 61;
            this.lblBirthdate.Text = "Birthdate :";
            // 
            // txtMname
            // 
            this.txtMname.Location = new System.Drawing.Point(205, 416);
            this.txtMname.Multiline = true;
            this.txtMname.Name = "txtMname";
            this.txtMname.Size = new System.Drawing.Size(416, 42);
            this.txtMname.TabIndex = 60;
            // 
            // lblMiddlename
            // 
            this.lblMiddlename.AutoSize = true;
            this.lblMiddlename.Location = new System.Drawing.Point(83, 414);
            this.lblMiddlename.Name = "lblMiddlename";
            this.lblMiddlename.Size = new System.Drawing.Size(94, 16);
            this.lblMiddlename.TabIndex = 59;
            this.lblMiddlename.Text = "Middle Name :";
            // 
            // txtFname
            // 
            this.txtFname.Location = new System.Drawing.Point(205, 355);
            this.txtFname.Multiline = true;
            this.txtFname.Name = "txtFname";
            this.txtFname.Size = new System.Drawing.Size(416, 42);
            this.txtFname.TabIndex = 58;
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.Location = new System.Drawing.Point(83, 369);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(78, 16);
            this.lblFirstname.TabIndex = 57;
            this.lblFirstname.Text = "First Name :";
            // 
            // txtseacrh
            // 
            this.txtseacrh.Location = new System.Drawing.Point(803, 111);
            this.txtseacrh.Multiline = true;
            this.txtseacrh.Name = "txtseacrh";
            this.txtseacrh.Size = new System.Drawing.Size(760, 42);
            this.txtseacrh.TabIndex = 56;
            this.txtseacrh.TextChanged += new System.EventHandler(this.txtseacrh_TextChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(424, 795);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 55;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(288, 795);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 54;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtLname
            // 
            this.txtLname.Location = new System.Drawing.Point(205, 293);
            this.txtLname.Multiline = true;
            this.txtLname.Name = "txtLname";
            this.txtLname.Size = new System.Drawing.Size(416, 42);
            this.txtLname.TabIndex = 53;
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(152, 795);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(93, 37);
            this.btnadd.TabIndex = 51;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(83, 307);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(78, 16);
            this.lblLastName.TabIndex = 48;
            this.lblLastName.Text = "Last Name :";
            // 
            // lblSectionID
            // 
            this.lblSectionID.AutoSize = true;
            this.lblSectionID.Location = new System.Drawing.Point(83, 207);
            this.lblSectionID.Name = "lblSectionID";
            this.lblSectionID.Size = new System.Drawing.Size(86, 16);
            this.lblSectionID.TabIndex = 47;
            this.lblSectionID.Text = "Department  :";
            this.lblSectionID.Click += new System.EventHandler(this.lblSectionID_Click);
            // 
            // lblTeacherinfo
            // 
            this.lblTeacherinfo.AutoSize = true;
            this.lblTeacherinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeacherinfo.Location = new System.Drawing.Point(268, 124);
            this.lblTeacherinfo.Name = "lblTeacherinfo";
            this.lblTeacherinfo.Size = new System.Drawing.Size(239, 29);
            this.lblTeacherinfo.TabIndex = 45;
            this.lblTeacherinfo.Text = "Employee Infomation";
            // 
            // dtpbirthdate
            // 
            this.dtpbirthdate.Location = new System.Drawing.Point(205, 479);
            this.dtpbirthdate.Name = "dtpbirthdate";
            this.dtpbirthdate.Size = new System.Drawing.Size(416, 22);
            this.dtpbirthdate.TabIndex = 73;
            // 
            // cmbdepartment
            // 
            this.cmbdepartment.FormattingEnabled = true;
            this.cmbdepartment.Location = new System.Drawing.Point(205, 199);
            this.cmbdepartment.Name = "cmbdepartment";
            this.cmbdepartment.Size = new System.Drawing.Size(416, 24);
            this.cmbdepartment.TabIndex = 74;
            // 
            // cmbGender
            // 
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Location = new System.Drawing.Point(205, 591);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(416, 24);
            this.cmbGender.TabIndex = 75;
            // 
            // mySqlDataAdapter1
            // 
            this.mySqlDataAdapter1.DeleteCommand = null;
            this.mySqlDataAdapter1.InsertCommand = null;
            this.mySqlDataAdapter1.SelectCommand = null;
            this.mySqlDataAdapter1.UpdateCommand = null;
            // 
            // lblemptype
            // 
            this.lblemptype.AutoSize = true;
            this.lblemptype.Location = new System.Drawing.Point(83, 250);
            this.lblemptype.Name = "lblemptype";
            this.lblemptype.Size = new System.Drawing.Size(110, 16);
            this.lblemptype.TabIndex = 76;
            this.lblemptype.Text = "Employee Type :";
            // 
            // cmbemptype
            // 
            this.cmbemptype.FormattingEnabled = true;
            this.cmbemptype.Location = new System.Drawing.Point(205, 246);
            this.cmbemptype.Name = "cmbemptype";
            this.cmbemptype.Size = new System.Drawing.Size(416, 24);
            this.cmbemptype.TabIndex = 77;
            // 
            // DGVteacherinfo
            // 
            this.DGVteacherinfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVteacherinfo.Location = new System.Drawing.Point(681, 198);
            this.DGVteacherinfo.Name = "DGVteacherinfo";
            this.DGVteacherinfo.RowHeadersWidth = 51;
            this.DGVteacherinfo.RowTemplate.Height = 24;
            this.DGVteacherinfo.Size = new System.Drawing.Size(1068, 582);
            this.DGVteacherinfo.TabIndex = 50;
            this.DGVteacherinfo.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVteacherinfo_CellClick);
            this.DGVteacherinfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVteacherinfo_CellContentClick);
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(561, 795);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(93, 37);
            this.btnclear.TabIndex = 78;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // Empformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1792, 913);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.cmbemptype);
            this.Controls.Add(this.lblemptype);
            this.Controls.Add(this.cmbGender);
            this.Controls.Add(this.cmbdepartment);
            this.Controls.Add(this.dtpbirthdate);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtcontactnum);
            this.Controls.Add(this.lblContactnumber);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblBirthdate);
            this.Controls.Add(this.txtMname);
            this.Controls.Add(this.lblMiddlename);
            this.Controls.Add(this.txtFname);
            this.Controls.Add(this.lblFirstname);
            this.Controls.Add(this.txtseacrh);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtLname);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.DGVteacherinfo);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblSectionID);
            this.Controls.Add(this.lblTeacherinfo);
            this.Controls.Add(this.panel1);
            this.Name = "Empformation";
            this.Text = "TeacherAssignments";
            this.Load += new System.EventHandler(this.TeacherAssignments_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVteacherinfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtcontactnum;
        private System.Windows.Forms.Label lblContactnumber;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblBirthdate;
        private System.Windows.Forms.TextBox txtMname;
        private System.Windows.Forms.Label lblMiddlename;
        private System.Windows.Forms.TextBox txtFname;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.TextBox txtseacrh;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtLname;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblSectionID;
        private System.Windows.Forms.Label lblTeacherinfo;
        private System.Windows.Forms.DateTimePicker dtpbirthdate;
        private System.Windows.Forms.ComboBox cmbdepartment;
        private System.Windows.Forms.ComboBox cmbGender;
        private MySql.Data.MySqlClient.MySqlDataAdapter mySqlDataAdapter1;
        private System.Windows.Forms.Label lblemptype;
        private System.Windows.Forms.ComboBox cmbemptype;
        private System.Windows.Forms.DataGridView DGVteacherinfo;
        private System.Windows.Forms.Button btnclear;
    }
}