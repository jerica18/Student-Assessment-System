﻿namespace Student_Assessment_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.lblSAS = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnTerm = new System.Windows.Forms.Button();
            this.lblAcademicTerm = new System.Windows.Forms.Label();
            this.lblTeacherAssign = new System.Windows.Forms.Label();
            this.btnEmpinfo = new System.Windows.Forms.Button();
            this.btnAssignments = new System.Windows.Forms.Button();
            this.lblstudentAndTeacher = new System.Windows.Forms.Label();
            this.lblsection = new System.Windows.Forms.Label();
            this.btncourse = new System.Windows.Forms.Button();
            this.btnStudentInfo = new System.Windows.Forms.Button();
            this.lblsubAndcourseInfo = new System.Windows.Forms.Label();
            this.lblReports = new System.Windows.Forms.Label();
            this.lblPerformance = new System.Windows.Forms.Label();
            this.lblItemAnalysis = new System.Windows.Forms.Label();
            this.btnSection = new System.Windows.Forms.Button();
            this.lblScoreGrading = new System.Windows.Forms.Label();
            this.lbltestadmin = new System.Windows.Forms.Label();
            this.lbltestassessment = new System.Windows.Forms.Label();
            this.btnSubjectInfo = new System.Windows.Forms.Button();
            this.lbldashboard = new System.Windows.Forms.Label();
            this.lblSubInfo = new System.Windows.Forms.Label();
            this.lblUserAcc = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btnLogOut);
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1651, 69);
            this.panel1.TabIndex = 0;
            // 
            // btnLogOut
            // 
            this.btnLogOut.Location = new System.Drawing.Point(1443, 15);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(100, 32);
            this.btnLogOut.TabIndex = 14;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(177, 16);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Controls.Add(this.btnTerm);
            this.panel2.Controls.Add(this.lblAcademicTerm);
            this.panel2.Controls.Add(this.lblTeacherAssign);
            this.panel2.Controls.Add(this.btnEmpinfo);
            this.panel2.Controls.Add(this.btnAssignments);
            this.panel2.Controls.Add(this.lblstudentAndTeacher);
            this.panel2.Controls.Add(this.lblsection);
            this.panel2.Controls.Add(this.btncourse);
            this.panel2.Controls.Add(this.btnStudentInfo);
            this.panel2.Controls.Add(this.lblsubAndcourseInfo);
            this.panel2.Controls.Add(this.lblReports);
            this.panel2.Controls.Add(this.lblPerformance);
            this.panel2.Controls.Add(this.lblItemAnalysis);
            this.panel2.Controls.Add(this.btnSection);
            this.panel2.Controls.Add(this.lblScoreGrading);
            this.panel2.Controls.Add(this.lbltestadmin);
            this.panel2.Controls.Add(this.lbltestassessment);
            this.panel2.Controls.Add(this.btnSubjectInfo);
            this.panel2.Controls.Add(this.lbldashboard);
            this.panel2.Controls.Add(this.lblSubInfo);
            this.panel2.Controls.Add(this.lblUserAcc);
            this.panel2.Location = new System.Drawing.Point(1, 69);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(305, 1116);
            this.panel2.TabIndex = 1;
            // 
            // btnTerm
            // 
            this.btnTerm.Location = new System.Drawing.Point(82, 656);
            this.btnTerm.Name = "btnTerm";
            this.btnTerm.Size = new System.Drawing.Size(174, 40);
            this.btnTerm.TabIndex = 14;
            this.btnTerm.Text = "Term Management";
            this.btnTerm.UseVisualStyleBackColor = true;
            // 
            // lblAcademicTerm
            // 
            this.lblAcademicTerm.AutoSize = true;
            this.lblAcademicTerm.Location = new System.Drawing.Point(58, 621);
            this.lblAcademicTerm.Name = "lblAcademicTerm";
            this.lblAcademicTerm.Size = new System.Drawing.Size(185, 16);
            this.lblAcademicTerm.TabIndex = 20;
            this.lblAcademicTerm.Text = "Academic Term Management";
            // 
            // lblTeacherAssign
            // 
            this.lblTeacherAssign.AutoSize = true;
            this.lblTeacherAssign.Location = new System.Drawing.Point(58, 532);
            this.lblTeacherAssign.Name = "lblTeacherAssign";
            this.lblTeacherAssign.Size = new System.Drawing.Size(138, 16);
            this.lblTeacherAssign.TabIndex = 19;
            this.lblTeacherAssign.Text = "Teacher Assignments";
            // 
            // btnEmpinfo
            // 
            this.btnEmpinfo.Location = new System.Drawing.Point(82, 428);
            this.btnEmpinfo.Name = "btnEmpinfo";
            this.btnEmpinfo.Size = new System.Drawing.Size(174, 40);
            this.btnEmpinfo.TabIndex = 15;
            this.btnEmpinfo.Text = "Employee Info";
            this.btnEmpinfo.UseVisualStyleBackColor = true;
            this.btnEmpinfo.Click += new System.EventHandler(this.btnTeacherinfo_Click);
            // 
            // btnAssignments
            // 
            this.btnAssignments.Location = new System.Drawing.Point(82, 561);
            this.btnAssignments.Name = "btnAssignments";
            this.btnAssignments.Size = new System.Drawing.Size(174, 40);
            this.btnAssignments.TabIndex = 13;
            this.btnAssignments.Text = "Assignments";
            this.btnAssignments.UseVisualStyleBackColor = true;
            // 
            // lblstudentAndTeacher
            // 
            this.lblstudentAndTeacher.AutoSize = true;
            this.lblstudentAndTeacher.Location = new System.Drawing.Point(58, 398);
            this.lblstudentAndTeacher.Name = "lblstudentAndTeacher";
            this.lblstudentAndTeacher.Size = new System.Drawing.Size(104, 16);
            this.lblstudentAndTeacher.TabIndex = 18;
            this.lblstudentAndTeacher.Text = "User Information";
            // 
            // lblsection
            // 
            this.lblsection.AutoSize = true;
            this.lblsection.Location = new System.Drawing.Point(58, 311);
            this.lblsection.Name = "lblsection";
            this.lblsection.Size = new System.Drawing.Size(105, 16);
            this.lblsection.TabIndex = 17;
            this.lblsection.Text = "Course Sections";
            // 
            // btncourse
            // 
            this.btncourse.Location = new System.Drawing.Point(82, 251);
            this.btncourse.Name = "btncourse";
            this.btncourse.Size = new System.Drawing.Size(174, 40);
            this.btncourse.TabIndex = 16;
            this.btncourse.Text = "Course";
            this.btncourse.UseVisualStyleBackColor = true;
            this.btncourse.Click += new System.EventHandler(this.btncourse_Click);
            // 
            // btnStudentInfo
            // 
            this.btnStudentInfo.Location = new System.Drawing.Point(82, 474);
            this.btnStudentInfo.Name = "btnStudentInfo";
            this.btnStudentInfo.Size = new System.Drawing.Size(174, 40);
            this.btnStudentInfo.TabIndex = 12;
            this.btnStudentInfo.Text = "Student Info";
            this.btnStudentInfo.UseVisualStyleBackColor = true;
            this.btnStudentInfo.Click += new System.EventHandler(this.button3_Click);
            // 
            // lblsubAndcourseInfo
            // 
            this.lblsubAndcourseInfo.AutoSize = true;
            this.lblsubAndcourseInfo.Location = new System.Drawing.Point(58, 170);
            this.lblsubAndcourseInfo.Name = "lblsubAndcourseInfo";
            this.lblsubAndcourseInfo.Size = new System.Drawing.Size(173, 16);
            this.lblsubAndcourseInfo.TabIndex = 11;
            this.lblsubAndcourseInfo.Text = "Subject / Course Information";
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.Location = new System.Drawing.Point(25, 998);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(114, 16);
            this.lblReports.TabIndex = 10;
            this.lblReports.Text = "Reporting Module";
            // 
            // lblPerformance
            // 
            this.lblPerformance.AutoSize = true;
            this.lblPerformance.Location = new System.Drawing.Point(25, 950);
            this.lblPerformance.Name = "lblPerformance";
            this.lblPerformance.Size = new System.Drawing.Size(141, 16);
            this.lblPerformance.TabIndex = 9;
            this.lblPerformance.Text = "Performance Analytics";
            // 
            // lblItemAnalysis
            // 
            this.lblItemAnalysis.AutoSize = true;
            this.lblItemAnalysis.Location = new System.Drawing.Point(25, 894);
            this.lblItemAnalysis.Name = "lblItemAnalysis";
            this.lblItemAnalysis.Size = new System.Drawing.Size(134, 16);
            this.lblItemAnalysis.TabIndex = 8;
            this.lblItemAnalysis.Text = "Item Analysis Module";
            // 
            // btnSection
            // 
            this.btnSection.Location = new System.Drawing.Point(82, 342);
            this.btnSection.Name = "btnSection";
            this.btnSection.Size = new System.Drawing.Size(174, 40);
            this.btnSection.TabIndex = 11;
            this.btnSection.Text = "Sections";
            this.btnSection.UseVisualStyleBackColor = true;
            this.btnSection.Click += new System.EventHandler(this.btnCourseSection_Click);
            // 
            // lblScoreGrading
            // 
            this.lblScoreGrading.AutoSize = true;
            this.lblScoreGrading.Location = new System.Drawing.Point(25, 834);
            this.lblScoreGrading.Name = "lblScoreGrading";
            this.lblScoreGrading.Size = new System.Drawing.Size(107, 16);
            this.lblScoreGrading.TabIndex = 7;
            this.lblScoreGrading.Text = "Scoring & Grading";
            // 
            // lbltestadmin
            // 
            this.lbltestadmin.AutoSize = true;
            this.lbltestadmin.Location = new System.Drawing.Point(25, 770);
            this.lbltestadmin.Name = "lbltestadmin";
            this.lbltestadmin.Size = new System.Drawing.Size(121, 16);
            this.lbltestadmin.TabIndex = 6;
            this.lbltestadmin.Text = "Test Administration";
            // 
            // lbltestassessment
            // 
            this.lbltestassessment.AutoSize = true;
            this.lbltestassessment.Location = new System.Drawing.Point(25, 718);
            this.lbltestassessment.Name = "lbltestassessment";
            this.lbltestassessment.Size = new System.Drawing.Size(219, 16);
            this.lbltestassessment.TabIndex = 5;
            this.lbltestassessment.Text = "Test / Assessment Creation Module";
            // 
            // btnSubjectInfo
            // 
            this.btnSubjectInfo.Location = new System.Drawing.Point(82, 205);
            this.btnSubjectInfo.Name = "btnSubjectInfo";
            this.btnSubjectInfo.Size = new System.Drawing.Size(174, 40);
            this.btnSubjectInfo.TabIndex = 2;
            this.btnSubjectInfo.Text = "Subject ";
            this.btnSubjectInfo.UseVisualStyleBackColor = true;
            this.btnSubjectInfo.Click += new System.EventHandler(this.btnSubjectCourse_Click);
            // 
            // lbldashboard
            // 
            this.lbldashboard.AutoSize = true;
            this.lbldashboard.Location = new System.Drawing.Point(25, 71);
            this.lbldashboard.Name = "lbldashboard";
            this.lbldashboard.Size = new System.Drawing.Size(75, 16);
            this.lbldashboard.TabIndex = 4;
            this.lbldashboard.Text = "Dashboard";
            this.lbldashboard.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblSubInfo
            // 
            this.lblSubInfo.AutoSize = true;
            this.lblSubInfo.Location = new System.Drawing.Point(25, 126);
            this.lblSubInfo.Name = "lblSubInfo";
            this.lblSubInfo.Size = new System.Drawing.Size(187, 16);
            this.lblSubInfo.TabIndex = 3;
            this.lblSubInfo.Text = "Subject / Course Management";
            // 
            // lblUserAcc
            // 
            this.lblUserAcc.AutoSize = true;
            this.lblUserAcc.Location = new System.Drawing.Point(25, 25);
            this.lblUserAcc.Name = "lblUserAcc";
            this.lblUserAcc.Size = new System.Drawing.Size(118, 16);
            this.lblUserAcc.TabIndex = 2;
            this.lblUserAcc.Text = "User Management";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1636, 1119);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblUserAcc;
        private System.Windows.Forms.Label lblSubInfo;
        private System.Windows.Forms.Label lbldashboard;
        private System.Windows.Forms.Label lbltestassessment;
        private System.Windows.Forms.Label lbltestadmin;
        private System.Windows.Forms.Label lblScoreGrading;
        private System.Windows.Forms.Label lblItemAnalysis;
        private System.Windows.Forms.Label lblPerformance;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Button btnSection;
        private System.Windows.Forms.Button btnSubjectInfo;
        private System.Windows.Forms.Button btnAssignments;
        private System.Windows.Forms.Button btnStudentInfo;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnTerm;
        private System.Windows.Forms.Button btnEmpinfo;
        private System.Windows.Forms.Label lblsubAndcourseInfo;
        private System.Windows.Forms.Button btncourse;
        private System.Windows.Forms.Label lblsection;
        private System.Windows.Forms.Label lblstudentAndTeacher;
        private System.Windows.Forms.Label lblTeacherAssign;
        private System.Windows.Forms.Label lblAcademicTerm;
    }
}

