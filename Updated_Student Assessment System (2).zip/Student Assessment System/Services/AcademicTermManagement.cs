﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Services
{
    public  class AcademicTermManagement
    {
        public int TermID { get; set; }
        public string SchoolYear {  get; set; }
        public string Semester {  get; set; }
        public string Status { get; set; }

    }
}
