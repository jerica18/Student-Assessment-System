﻿using Student_Assessment_System.Course_Section;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Interface
{
    public interface ISection
    {
        void SaveSection(Section e);
        Section GetSectionbyid(int SectionId);

        void RemoveSection(int SectionId);
        void UpdateSection(Section e);
    }
}
