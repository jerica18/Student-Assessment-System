﻿using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Interface
{
    public interface Istudent
    {
       void SaveStudent(Student e);
        Student GetStudentbyid(int StudentId);

        void RemoveStudent(int StudentId);
        void UpdateStudent(Student e);


    }
}
