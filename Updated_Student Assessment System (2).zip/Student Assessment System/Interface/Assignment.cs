﻿namespace Student_Assessment_System.Interface
{
    public class Assignment
    {
        internal int termID;

        public int AssignmentID { get; internal set; }
        public int TeacherID { get; internal set; }
        public int CourseID { get; internal set; }
        public int SubjectID { get; internal set; }
        public int SectionID { get; internal set; }
        public string Assignment_Schedule { get; internal set; }
    }
}