﻿using Student_Assessment_System.Course___Subject;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Interface
{
    public interface ICourse
    {
        void SaveCourse(Course e);
        Course GetCoursebyid(int CourseId);

        void RemoveCourse(int CourseId);
        void Updatecourse(Course e);
        List<Course> Getallcourse();

        Course GetCourseByCourseName(string courseName);
    }
}
