﻿using Student_Assessment_System.Module;
using Student_Assessment_System.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Interface
{
    public interface IEmployee 
    {
        void SaveTeacher(Teacher e);
        Teacher GetTeacherbyid(int TeacherId);

        void RemoveTeacher(int TeacherId);  
        void UpdateTeacher(Teacher e);

       List <Teacher> GetAllempbytype(string employeetype);


        List<Teacher> GetAllemployee();


    }
}
