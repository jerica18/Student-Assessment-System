﻿using Student_Assessment_System.Module;
using Student_Assessment_System.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Interface
{
    public interface IAssignment
    {
        void SaveAssignment(Assignment e);
        Assignment GetAssignmentbyid(int AssignemnetId);

        void RemoveAssignment(int AssignmentId);
        void UpdateAssignment(Assignment e);
    }
}
