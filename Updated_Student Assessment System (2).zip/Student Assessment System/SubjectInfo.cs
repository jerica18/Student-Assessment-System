﻿using Student_Assessment_System.Course___Subject;
using Student_Assessment_System.Course___Subject_infromation;
using Student_Assessment_System.DBContext.CourseRepo;
using Student_Assessment_System.DBContext.SubjectRepo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System
{
    public partial class Subject___Course_Information : Form
    {
        CourseRepo repo1 = new CourseRepo();
        SubjectRepo repo2 = new SubjectRepo();
        public Subject___Course_Information()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Subject sub = new Subject();
            Course course = new Course();

            sub.Subject_name = txtSubjName.Text;
            sub.Subject_code = txtSubCode.Text;
            course.Course_name = txtCourse.Text;

            repo2.SaveSubject(sub);
            repo1.SaveCourse(course);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblCoursename_Click(object sender, EventArgs e)
        {

        }

        private void lblSubName_Click(object sender, EventArgs e)
        {

        }

        private void lblSubCode_Click(object sender, EventArgs e)
        {

        }

        private void Subject___Course_Information_Load(object sender, EventArgs e)
        {

        }
    }
}
