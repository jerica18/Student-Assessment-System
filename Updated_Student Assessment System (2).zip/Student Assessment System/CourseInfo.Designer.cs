﻿namespace Student_Assessment_System
{
    partial class CourseInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtCourseSearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtCourse = new System.Windows.Forms.TextBox();
            this.txtcoursecode = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.DGVSubjectCourse = new System.Windows.Forms.DataGridView();
            this.txtdurationyears = new System.Windows.Forms.TextBox();
            this.lblCoursenam = new System.Windows.Forms.Label();
            this.lblcoursecode = new System.Windows.Forms.Label();
            this.lblCourse = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.lbldurationyear = new System.Windows.Forms.Label();
            this.lblstatus = new System.Windows.Forms.Label();
            this.btnclear = new System.Windows.Forms.Button();
            this.cmbstatus = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSubjectCourse)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(684, 116);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 31;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtCourseSearch
            // 
            this.txtCourseSearch.Location = new System.Drawing.Point(805, 113);
            this.txtCourseSearch.Multiline = true;
            this.txtCourseSearch.Name = "txtCourseSearch";
            this.txtCourseSearch.Size = new System.Drawing.Size(430, 42);
            this.txtCourseSearch.TabIndex = 30;
            this.txtCourseSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(356, 477);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 29;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(220, 477);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 28;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtCourse
            // 
            this.txtCourse.Location = new System.Drawing.Point(159, 193);
            this.txtCourse.Multiline = true;
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(416, 42);
            this.txtCourse.TabIndex = 27;
            this.txtCourse.TextChanged += new System.EventHandler(this.txtCourse_TextChanged);
            // 
            // txtcoursecode
            // 
            this.txtcoursecode.Location = new System.Drawing.Point(159, 248);
            this.txtcoursecode.Multiline = true;
            this.txtcoursecode.Name = "txtcoursecode";
            this.txtcoursecode.Size = new System.Drawing.Size(416, 42);
            this.txtcoursecode.TabIndex = 26;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(79, 477);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(93, 37);
            this.btnAdd.TabIndex = 25;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // DGVSubjectCourse
            // 
            this.DGVSubjectCourse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVSubjectCourse.Location = new System.Drawing.Point(643, 193);
            this.DGVSubjectCourse.Name = "DGVSubjectCourse";
            this.DGVSubjectCourse.RowHeadersWidth = 51;
            this.DGVSubjectCourse.RowTemplate.Height = 24;
            this.DGVSubjectCourse.Size = new System.Drawing.Size(679, 428);
            this.DGVSubjectCourse.TabIndex = 24;
            this.DGVSubjectCourse.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVSubjectCourse_CellClick);
            this.DGVSubjectCourse.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVSubjectCourse_CellContentClick);
            // 
            // txtdurationyears
            // 
            this.txtdurationyears.Location = new System.Drawing.Point(159, 309);
            this.txtdurationyears.Multiline = true;
            this.txtdurationyears.Name = "txtdurationyears";
            this.txtdurationyears.Size = new System.Drawing.Size(416, 42);
            this.txtdurationyears.TabIndex = 23;
            // 
            // lblCoursenam
            // 
            this.lblCoursenam.AutoSize = true;
            this.lblCoursenam.Location = new System.Drawing.Point(37, 207);
            this.lblCoursenam.Name = "lblCoursenam";
            this.lblCoursenam.Size = new System.Drawing.Size(96, 16);
            this.lblCoursenam.TabIndex = 22;
            this.lblCoursenam.Text = "Course Name :";
            this.lblCoursenam.Click += new System.EventHandler(this.lblCoursenam_Click);
            // 
            // lblcoursecode
            // 
            this.lblcoursecode.AutoSize = true;
            this.lblcoursecode.Location = new System.Drawing.Point(37, 261);
            this.lblcoursecode.Name = "lblcoursecode";
            this.lblcoursecode.Size = new System.Drawing.Size(92, 16);
            this.lblcoursecode.TabIndex = 21;
            this.lblcoursecode.Text = "Course Code :";
            // 
            // lblCourse
            // 
            this.lblCourse.AutoSize = true;
            this.lblCourse.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourse.Location = new System.Drawing.Point(219, 124);
            this.lblCourse.Name = "lblCourse";
            this.lblCourse.Size = new System.Drawing.Size(216, 29);
            this.lblCourse.TabIndex = 19;
            this.lblCourse.Text = "Course Information";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(-9, -11);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1376, 69);
            this.panel1.TabIndex = 18;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 25);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // lbldurationyear
            // 
            this.lbldurationyear.AutoSize = true;
            this.lbldurationyear.Location = new System.Drawing.Point(37, 321);
            this.lbldurationyear.Name = "lbldurationyear";
            this.lbldurationyear.Size = new System.Drawing.Size(102, 16);
            this.lbldurationyear.TabIndex = 32;
            this.lbldurationyear.Text = "Duration Years :";
            // 
            // lblstatus
            // 
            this.lblstatus.AutoSize = true;
            this.lblstatus.Location = new System.Drawing.Point(37, 385);
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(50, 16);
            this.lblstatus.TabIndex = 34;
            this.lblstatus.Text = "Status :";
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(503, 477);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(93, 37);
            this.btnclear.TabIndex = 35;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // cmbstatus
            // 
            this.cmbstatus.FormattingEnabled = true;
            this.cmbstatus.Location = new System.Drawing.Point(159, 396);
            this.cmbstatus.Name = "cmbstatus";
            this.cmbstatus.Size = new System.Drawing.Size(416, 24);
            this.cmbstatus.TabIndex = 36;
            // 
            // CourseInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1359, 699);
            this.Controls.Add(this.cmbstatus);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.lblstatus);
            this.Controls.Add(this.lbldurationyear);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtCourseSearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtCourse);
            this.Controls.Add(this.txtcoursecode);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.DGVSubjectCourse);
            this.Controls.Add(this.txtdurationyears);
            this.Controls.Add(this.lblCoursenam);
            this.Controls.Add(this.lblcoursecode);
            this.Controls.Add(this.lblCourse);
            this.Controls.Add(this.panel1);
            this.Name = "CourseInfo";
            this.Text = "CourseInfo";
            this.Load += new System.EventHandler(this.CourseInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGVSubjectCourse)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtCourseSearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtCourse;
        private System.Windows.Forms.TextBox txtcoursecode;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView DGVSubjectCourse;
        private System.Windows.Forms.TextBox txtdurationyears;
        private System.Windows.Forms.Label lblCoursenam;
        private System.Windows.Forms.Label lblcoursecode;
        private System.Windows.Forms.Label lblCourse;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Label lbldurationyear;
        private System.Windows.Forms.Label lblstatus;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.ComboBox cmbstatus;
    }
}