﻿using Student_Assessment_System.DBContext.EmployeeRepo;
using Student_Assessment_System.Module;
using Student_Assessment_System.User;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Student_Assessment_System
{
    public partial class Empformation : Form
    {
        EmployeeRepo repo = new EmployeeRepo();

        private int EmpId ;
        public Empformation()
        {
            InitializeComponent();
        }

        private void LoadDepartments(string departmentRepo)
        {
           

        }
        private void lblSectionID_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TeacherAssignments_Load(object sender, EventArgs e)
        {
            //department combobox dri
            cmbdepartment.Items.Add("CIT");
            cmbdepartment.Items.Add("CCS");
            cmbdepartment.Items.Add("CoE");
            cmbdepartment.Items.Add("CRIM");
            cmbdepartment.Items.Add("CED");
            cmbdepartment.Items.Add("CBM");
            cmbdepartment.Items.Add("CAS");
            cmbdepartment.Items.Add("CCRIM");

            //Gender combobox dri
            cmbGender.Items.Add("Female");
            cmbGender.Items.Add("Male");

            //Employee type dri
            cmbemptype.Items.Add("Teacher");
            cmbemptype.Items.Add("Admin");


            showemp();
            

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            Teacher employee = new Teacher();
            employee.DepartmentName = cmbdepartment.Text;
            employee.Employeetype = cmbemptype.Text;
            employee.LastName = txtLname.Text;
            employee.FirstName = txtFname.Text;
            employee.MiddleName = txtMname.Text;
            employee.Address = txtAddress.Text;
            employee.Birthdate = DateTime.Parse(dtpbirthdate.Text);
            employee.Gender = cmbGender.Text;
            employee.Contact_number = txtcontactnum.Text;
            employee.Email = txtemail.Text;

            repo.SaveTeacher(employee);
            showemp();
            
            
        }

        private void txtdepartment_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            int empId = Convert.ToInt32(DGVteacherinfo.SelectedRows[0].Cells["Employee_ID"].Value);

            repo.RemoveTeacher(empId);

            showemp();
        }

        private void DGVteacherinfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            // para ma basa ang selected na rows sa datagrid
            DGVteacherinfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGVteacherinfo.MultiSelect = false;
            

        }

       
        private void showemp()
        {
            try
            {
                List<Teacher> teachers = repo.GetAllemployee();
                DGVteacherinfo.DataSource = teachers;


                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading employees: " + ex.Message);
            }
        }

        



        private void btnSearch_Click(object sender, EventArgs e)
        {

            string search = txtseacrh.Text.Trim();
            var results = new List<Teacher>();

            if (int.TryParse(search, out int empId))
            {
                var emp = repo.GetTeacherbyid(empId);
                if (emp != null) results.Add(emp);
            }
            else 
            {
                var teachers = repo.GetAllempbytype(search);
                results.AddRange(teachers);



            }

            DGVteacherinfo.DataSource = null;
            DGVteacherinfo.DataSource = results;



        }

        private void txtseacrh_TextChanged(object sender, EventArgs e)
        {
            string empType = txtseacrh.Text.Trim();

            if (string.IsNullOrWhiteSpace(empType))
            {
                showemp();
            }

            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try {
                Teacher employee = new Teacher();

                employee.setEmp_ID(Convert.ToInt32(DGVteacherinfo.SelectedRows[0].Cells["Employee_ID"].Value));
                employee.DepartmentName = cmbdepartment.Text;
                employee.Employeetype = cmbemptype.Text;
                employee.LastName = txtLname.Text;
                employee.FirstName = txtFname.Text;
                employee.MiddleName = txtMname.Text;
                employee.Address = txtAddress.Text;
                employee.Birthdate = DateTime.Parse(dtpbirthdate.Text);
                employee.Gender = cmbGender.Text;
                employee.Contact_number = txtcontactnum.Text;
                employee.Email = txtemail.Text;

                repo.UpdateTeacher(employee);

                showemp();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Please select a row: " + ex.Message);
            }
        }

        private void DGVteacherinfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = DGVteacherinfo.Rows[e.RowIndex];

                EmpId = Convert.ToInt32(row.Cells["Employee_ID"].Value);

                txtFname.Text = row.Cells["FirstName"].Value?.ToString();
                txtMname.Text = row.Cells["MiddleName"].Value?.ToString();
                txtLname.Text = row.Cells["LastName"].Value?.ToString();
                cmbdepartment.Text = row.Cells["DepartmentName"].Value?.ToString();
                cmbGender.Text = row.Cells["Gender"].Value?.ToString();
                cmbemptype.Text = row.Cells["Employeetype"].Value?.ToString();
                txtAddress.Text = row.Cells["Address"].Value?.ToString();
                txtcontactnum.Text = row.Cells["Contact_number"].Value?.ToString();
                txtemail.Text = row.Cells["Email"].Value?.ToString();
                dtpbirthdate.Value = Convert.ToDateTime(row.Cells["Birthdate"].Value);
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtFname.Clear();
            txtMname.Clear();
            txtLname.Clear();
            txtAddress.Clear();
            txtcontactnum.Clear();
            txtemail.Clear();
            dtpbirthdate.Value = DateTime.Today;
            cmbdepartment.SelectedIndex = -1;
            cmbGender.SelectedIndex = -1;
            cmbemptype.SelectedIndex = -1;
        }
    }
}
