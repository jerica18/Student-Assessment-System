﻿using Student_Assessment_System.DBContext.StudentRepo;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System
{
    public partial class Student_Information : Form
    {
        Studentrepo repo = new Studentrepo();
        public Student_Information()
        {
            InitializeComponent();
        }

        private void Student_Information_Load(object sender, EventArgs e)
        {
            cmbgender.Items.Add("Female");
            cmbgender.Items.Add("Male");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void DGVStudentinfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtstudentid_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            

            student.StudentID = int.Parse(txtstudentid.Text); 
            student.Section_ID = int.Parse(txtsectionid.Text);
            student.LastName = txtlastname.Text;
            student.FirstName = txtfirstname.Text;
            student.MiddleName = txtmiddlename.Text;
            student.Address = txtaddress.Text;
            student.Birthdate = DateTime.Parse(DTPbirthdate.Text);
            student.Gender = cmbgender.Text;
            student.Contact_number = txtcontactnum.Text;
            student.Email = txtemail.Text;

            repo.SaveStudent(student);
            MessageBox.Show("New employee record added!");

        }

        private void DTPbirthdate_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
