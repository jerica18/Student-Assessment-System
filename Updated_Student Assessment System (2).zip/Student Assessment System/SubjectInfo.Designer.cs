﻿namespace Student_Assessment_System
{
    partial class Subject___Course_Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.lblSubandCourse = new System.Windows.Forms.Label();
            this.lblSubCode = new System.Windows.Forms.Label();
            this.lblSubName = new System.Windows.Forms.Label();
            this.lblCoursename = new System.Windows.Forms.Label();
            this.txtSubCode = new System.Windows.Forms.TextBox();
            this.DGVSubjectCourse = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtSubjName = new System.Windows.Forms.TextBox();
            this.txtCourse = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSubjectCourse)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(5, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1376, 69);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // lblSubandCourse
            // 
            this.lblSubandCourse.AutoSize = true;
            this.lblSubandCourse.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubandCourse.Location = new System.Drawing.Point(205, 135);
            this.lblSubandCourse.Name = "lblSubandCourse";
            this.lblSubandCourse.Size = new System.Drawing.Size(351, 29);
            this.lblSubandCourse.TabIndex = 2;
            this.lblSubandCourse.Text = "Subject And Course Information";
            // 
            // lblSubCode
            // 
            this.lblSubCode.AutoSize = true;
            this.lblSubCode.Location = new System.Drawing.Point(51, 218);
            this.lblSubCode.Name = "lblSubCode";
            this.lblSubCode.Size = new System.Drawing.Size(94, 16);
            this.lblSubCode.TabIndex = 3;
            this.lblSubCode.Text = "Subject Code :";
            this.lblSubCode.Click += new System.EventHandler(this.lblSubCode_Click);
            // 
            // lblSubName
            // 
            this.lblSubName.AutoSize = true;
            this.lblSubName.Location = new System.Drawing.Point(51, 272);
            this.lblSubName.Name = "lblSubName";
            this.lblSubName.Size = new System.Drawing.Size(98, 16);
            this.lblSubName.TabIndex = 4;
            this.lblSubName.Text = "Subject Name :";
            this.lblSubName.Click += new System.EventHandler(this.lblSubName_Click);
            // 
            // lblCoursename
            // 
            this.lblCoursename.AutoSize = true;
            this.lblCoursename.Location = new System.Drawing.Point(51, 329);
            this.lblCoursename.Name = "lblCoursename";
            this.lblCoursename.Size = new System.Drawing.Size(96, 16);
            this.lblCoursename.TabIndex = 5;
            this.lblCoursename.Text = "Course Name :";
            this.lblCoursename.Click += new System.EventHandler(this.lblCoursename_Click);
            // 
            // txtSubCode
            // 
            this.txtSubCode.Location = new System.Drawing.Point(173, 204);
            this.txtSubCode.Multiline = true;
            this.txtSubCode.Name = "txtSubCode";
            this.txtSubCode.Size = new System.Drawing.Size(416, 42);
            this.txtSubCode.TabIndex = 6;
            this.txtSubCode.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // DGVSubjectCourse
            // 
            this.DGVSubjectCourse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVSubjectCourse.Location = new System.Drawing.Point(657, 204);
            this.DGVSubjectCourse.Name = "DGVSubjectCourse";
            this.DGVSubjectCourse.RowHeadersWidth = 51;
            this.DGVSubjectCourse.RowTemplate.Height = 24;
            this.DGVSubjectCourse.Size = new System.Drawing.Size(679, 428);
            this.DGVSubjectCourse.TabIndex = 9;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(197, 399);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(93, 37);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtSubjName
            // 
            this.txtSubjName.Location = new System.Drawing.Point(173, 259);
            this.txtSubjName.Multiline = true;
            this.txtSubjName.Name = "txtSubjName";
            this.txtSubjName.Size = new System.Drawing.Size(416, 42);
            this.txtSubjName.TabIndex = 11;
            this.txtSubjName.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtCourse
            // 
            this.txtCourse.Location = new System.Drawing.Point(173, 315);
            this.txtCourse.Multiline = true;
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(416, 42);
            this.txtCourse.TabIndex = 12;
            this.txtCourse.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(342, 399);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 13;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(478, 399);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 14;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(819, 124);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(430, 42);
            this.txtSearch.TabIndex = 16;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(698, 127);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 17;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // Subject___Course_Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1371, 768);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtCourse);
            this.Controls.Add(this.txtSubjName);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.DGVSubjectCourse);
            this.Controls.Add(this.txtSubCode);
            this.Controls.Add(this.lblCoursename);
            this.Controls.Add(this.lblSubName);
            this.Controls.Add(this.lblSubCode);
            this.Controls.Add(this.lblSubandCourse);
            this.Controls.Add(this.panel1);
            this.Name = "Subject___Course_Information";
            this.Text = "Subject___Course_Information";
            this.Load += new System.EventHandler(this.Subject___Course_Information_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSubjectCourse)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Label lblSubandCourse;
        private System.Windows.Forms.Label lblSubCode;
        private System.Windows.Forms.Label lblSubName;
        private System.Windows.Forms.Label lblCoursename;
        private System.Windows.Forms.TextBox txtSubCode;
        private System.Windows.Forms.DataGridView DGVSubjectCourse;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtSubjName;
        private System.Windows.Forms.TextBox txtCourse;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
    }
}