﻿namespace Student_Assessment_System
{
    partial class Academictermmanagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtstatus = new System.Windows.Forms.TextBox();
            this.txtschoolyear = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.DGVTerm = new System.Windows.Forms.DataGridView();
            this.txtTermId = new System.Windows.Forms.TextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblschoolyear = new System.Windows.Forms.Label();
            this.lbltermId = new System.Windows.Forms.Label();
            this.lblterm = new System.Windows.Forms.Label();
            this.txtsemester = new System.Windows.Forms.TextBox();
            this.lblsemester = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVTerm)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1401, 69);
            this.panel1.TabIndex = 3;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(699, 108);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 30;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(820, 105);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(430, 42);
            this.txtSearch.TabIndex = 29;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(472, 447);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 28;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(336, 447);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 27;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // txtstatus
            // 
            this.txtstatus.Location = new System.Drawing.Point(174, 362);
            this.txtstatus.Multiline = true;
            this.txtstatus.Name = "txtstatus";
            this.txtstatus.Size = new System.Drawing.Size(416, 42);
            this.txtstatus.TabIndex = 26;
            // 
            // txtschoolyear
            // 
            this.txtschoolyear.Location = new System.Drawing.Point(174, 240);
            this.txtschoolyear.Multiline = true;
            this.txtschoolyear.Name = "txtschoolyear";
            this.txtschoolyear.Size = new System.Drawing.Size(416, 42);
            this.txtschoolyear.TabIndex = 25;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(191, 447);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(93, 37);
            this.btnAdd.TabIndex = 24;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // DGVTerm
            // 
            this.DGVTerm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVTerm.Location = new System.Drawing.Point(658, 189);
            this.DGVTerm.Name = "DGVTerm";
            this.DGVTerm.RowHeadersWidth = 51;
            this.DGVTerm.RowTemplate.Height = 24;
            this.DGVTerm.Size = new System.Drawing.Size(679, 428);
            this.DGVTerm.TabIndex = 23;
            // 
            // txtTermId
            // 
            this.txtTermId.Location = new System.Drawing.Point(174, 185);
            this.txtTermId.Multiline = true;
            this.txtTermId.Name = "txtTermId";
            this.txtTermId.Size = new System.Drawing.Size(416, 42);
            this.txtTermId.TabIndex = 22;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(52, 376);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(50, 16);
            this.lblStatus.TabIndex = 21;
            this.lblStatus.Text = "Status :";
            // 
            // lblschoolyear
            // 
            this.lblschoolyear.AutoSize = true;
            this.lblschoolyear.Location = new System.Drawing.Point(52, 253);
            this.lblschoolyear.Name = "lblschoolyear";
            this.lblschoolyear.Size = new System.Drawing.Size(87, 16);
            this.lblschoolyear.TabIndex = 20;
            this.lblschoolyear.Text = "School Year :";
            // 
            // lbltermId
            // 
            this.lbltermId.AutoSize = true;
            this.lbltermId.Location = new System.Drawing.Point(52, 199);
            this.lbltermId.Name = "lbltermId";
            this.lbltermId.Size = new System.Drawing.Size(61, 16);
            this.lbltermId.TabIndex = 19;
            this.lbltermId.Text = "Term ID :";
            // 
            // lblterm
            // 
            this.lblterm.AutoSize = true;
            this.lblterm.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblterm.Location = new System.Drawing.Point(206, 116);
            this.lblterm.Name = "lblterm";
            this.lblterm.Size = new System.Drawing.Size(329, 29);
            this.lblterm.TabIndex = 18;
            this.lblterm.Text = "Academic Term Management";
            // 
            // txtsemester
            // 
            this.txtsemester.Location = new System.Drawing.Point(174, 300);
            this.txtsemester.Multiline = true;
            this.txtsemester.Name = "txtsemester";
            this.txtsemester.Size = new System.Drawing.Size(416, 42);
            this.txtsemester.TabIndex = 32;
            // 
            // lblsemester
            // 
            this.lblsemester.AutoSize = true;
            this.lblsemester.Location = new System.Drawing.Point(52, 314);
            this.lblsemester.Name = "lblsemester";
            this.lblsemester.Size = new System.Drawing.Size(71, 16);
            this.lblsemester.TabIndex = 31;
            this.lblsemester.Text = "Semester :";
            // 
            // AcademicTermManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1375, 657);
            this.Controls.Add(this.txtsemester);
            this.Controls.Add(this.lblsemester);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtstatus);
            this.Controls.Add(this.txtschoolyear);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.DGVTerm);
            this.Controls.Add(this.txtTermId);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblschoolyear);
            this.Controls.Add(this.lbltermId);
            this.Controls.Add(this.lblterm);
            this.Controls.Add(this.panel1);
            this.Name = "AcademicTermManagement";
            this.Text = "AcademicTermManagement";
            this.Load += new System.EventHandler(this.AcademicTermManagement_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVTerm)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtstatus;
        private System.Windows.Forms.TextBox txtschoolyear;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView DGVTerm;
        private System.Windows.Forms.TextBox txtTermId;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblschoolyear;
        private System.Windows.Forms.Label lbltermId;
        private System.Windows.Forms.Label lblterm;
        private System.Windows.Forms.TextBox txtsemester;
        private System.Windows.Forms.Label lblsemester;
    }
}