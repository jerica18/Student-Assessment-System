﻿using MySql.Data.MySqlClient;
using Student_Assessment_System.Course___Subject;
using Student_Assessment_System.Interface;
using Student_Assessment_System.Module;
using Student_Assessment_System.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Student_Assessment_System.DBContext.AcademicTermManagementRepo
{
    public class TermRepo : ITerm
    {
        private string _conStr = Helpers.MySqlHelper.GetConnectionString();
        public AcademicTermManagement GetAcademicTermbyid(int TermID)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("GetAcademicTermmanagementById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Term_ID", TermID);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new AcademicTermManagement
                            {
                                TermID = Convert.ToInt32(reader["Term_ID"]),
                                SchoolYear = reader["School_Year"].ToString(),
                                Semester = reader["Semester"].ToString(),
                                Status = reader["Status"].ToString()

                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving Academic Term: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return null;
        }

        public void RemoveTerm(int TermID)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("DeleteAcademicTermmanagement", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Term_ID", TermID);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Academic Term Removed", "Remove Record",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing Academic Term: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void SaveTerm(AcademicTermManagement e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("AddAcademicTermmanagement", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_SchoolYear", e.SchoolYear);
                    cmd.Parameters.AddWithValue("sp_Semester", e.Semester);
                    cmd.Parameters.AddWithValue("sp_Status", e.Status);
                   


                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Academic Term Added.", "New Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding academic term: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateTerm(AcademicTermManagement e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("updateAcademicTermmanagement", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Term_ID", e.TermID);
                    cmd.Parameters.AddWithValue("sp_SchoolYear", e.SchoolYear);
                    cmd.Parameters.AddWithValue("sp_Semester", e.Semester);
                    cmd.Parameters.AddWithValue("sp_Status", e.Status);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Academic Term Updated", "Update Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating academic term: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
