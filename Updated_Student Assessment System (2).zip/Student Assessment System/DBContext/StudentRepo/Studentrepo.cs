﻿using MySql.Data.MySqlClient;
using Student_Assessment_System.Interface;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Student_Assessment_System.DBContext.StudentRepo
{
    public class Studentrepo : Istudent
    {
        private string _conStr = Helpers.MySqlHelper.GetConnectionString();

        public object StudentID { get; private set; }

        public void SaveStudent(Student e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("AddStudent", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Student_ID", e.StudentID);
                    cmd.Parameters.AddWithValue("sp_Section_ID", e.Section_ID);
                    cmd.Parameters.AddWithValue("sp_Lname", e.LastName);
                    cmd.Parameters.AddWithValue("sp_Fname", e.FirstName);
                    cmd.Parameters.AddWithValue("sp_Mname", e.MiddleName);
                    cmd.Parameters.AddWithValue("sp_Student_Address", e.Address);
                    cmd.Parameters.AddWithValue("sp_Student_Birthdate", e.Birthdate);
                    cmd.Parameters.AddWithValue("sp_Student_gender", e.Gender);
                    cmd.Parameters.AddWithValue("sp_Student_ContactNumber", e.Contact_number);
                    cmd.Parameters.AddWithValue("sp_Student_Email", e.Email);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Student Added.", "New Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding student: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        public Student GetStudentbyid(int StudentId)
        {
            using (MySqlConnection conn = new MySqlConnection(_conStr))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetStudentByID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Student_ID", StudentId);

                    conn.Open();  

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())

                        {

                            return new Student
                            {
                                StudentID = Convert.ToInt32(reader["Student_ID"]),
                                Section_ID = Convert.ToInt32(reader["Section_ID"]),
                                LastName = reader["Lname"].ToString(),
                                FirstName = reader["Fname"].ToString(),
                                MiddleName = reader["Mname"].ToString(),
                                Address = reader["Student_Address"].ToString(),
                                Birthdate = Convert.ToDateTime(reader["Student_Birthdate"]),
                                Gender = reader["Student_gender"].ToString(),
                                Contact_number = reader["Student_ContactNumber"].ToString(),
                                Email = reader["student_Email"].ToString()

                            }
                             ;
                            
                        }

                    }
                }
               
            }
            return null;
        }
        public void RemoveStudent(int StudentId)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("DeleteStudent", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Student_ID", StudentId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Student Removed", "Remove Record",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing student: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateStudent(Student e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("UpdateStudent", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Student_ID", e.StudentID);
                    cmd.Parameters.AddWithValue("sp_Section_ID", e.Section_ID);
                    cmd.Parameters.AddWithValue("sp_Lname", e.LastName);
                    cmd.Parameters.AddWithValue("sp_Fname", e.FirstName);
                    cmd.Parameters.AddWithValue("sp_Mname", e.MiddleName);
                    cmd.Parameters.AddWithValue("sp_Address", e.Address);
                    cmd.Parameters.AddWithValue("sp_Student_Birthdate", e.Birthdate);
                    cmd.Parameters.AddWithValue("sp_Student_gender", e.Gender);
                    cmd.Parameters.AddWithValue("sp_Student_ContactNumber", e.Contact_number);
                    cmd.Parameters.AddWithValue("sp_Student_Email", e.Email);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Student Updated", "Update Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating student: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



    }
}
