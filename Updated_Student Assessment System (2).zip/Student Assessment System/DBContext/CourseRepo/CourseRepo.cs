﻿using MySql.Data.MySqlClient;
using Student_Assessment_System.Course___Subject;
using Student_Assessment_System.Interface;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System.DBContext.CourseRepo
{
    public class CourseRepo : ICourse
    {
        private string _conStr = Helpers.MySqlHelper.GetConnectionString();

        public List<Course> Getallcourse()
        {
            List<Course> courslist = new List<Course>();
            using (MySqlConnection conn = new MySqlConnection(_conStr))
            using (MySqlCommand cmd = new MySqlCommand("GetAllCourse", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                conn.Open();

                using(MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read()) 
                    {
                        Course course = new Course();
                        course.Course_id = reader.GetInt32("Course_ID");
                        course.Course_name = reader.GetString("Course_Name");
                        course.Course_code = reader.GetString("Course_Code");
                        course.Duration_years = reader.GetString("Duration_Years");
                        course.status = reader.GetString("Course_Status");

                        courslist.Add(course);
                        
                    }
                }
            }
            return courslist;
        }

        public Course GetCourseByCourseName(string courseName)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("GetcoursebyCourseName", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_course_name", courseName);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Course
                            {
                                Course_id = Convert.ToInt32(reader["Course_ID"].ToString()),
                                Course_name = reader["Course_Name"].ToString(),
                                Course_code = reader["Course_Code"].ToString(),
                                Duration_years = reader["Duration_Years"].ToString(),
                                status = reader["Course_Status"].ToString()

                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving course: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return null;
        }

        public Course GetCoursebyid(int CourseId)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("GetCourseByID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Course_ID", CourseId);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Course
                            {
                                Course_id = Convert.ToInt32(reader["Course_ID"].ToString()),
                                Course_name = reader["Course_Name"].ToString(),
                                Course_code = reader["Course_Code"].ToString(),
                                Duration_years = reader["Duration_Years"].ToString(),
                                status = reader["Course_Status"].ToString()

                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving course: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return null;
        }


        public void RemoveCourse(int CourseId)
        {

            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("DeleteCourse", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Course_ID", CourseId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Course Removed", "Remove Record",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing course: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        public void SaveCourse(Course e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("AddCourse", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Course_Name", e.Course_name);
                    cmd.Parameters.AddWithValue("sp_Course_Code", e.Course_code);
                    cmd.Parameters.AddWithValue("sp_Duration_Years", e.Duration_years);
                    cmd.Parameters.AddWithValue("sp_Status", e.status);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Course Added.", "New Course",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding course: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Updatecourse(Course e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("UpdateCourse", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Course_ID", e.Course_id);
                    cmd.Parameters.AddWithValue("sp_Course_Name", e.Course_name);
                    cmd.Parameters.AddWithValue("sp_Course_Code", e.Course_code);
                    cmd.Parameters.AddWithValue("sp_Duration_Years", e.Duration_years);
                    cmd.Parameters.AddWithValue("sp_Status", e.status);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Course Updated", "Update Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating course: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
 }
