﻿using MySql.Data.MySqlClient;
using Student_Assessment_System.Interface;
using Student_Assessment_System.Module;
using Student_Assessment_System.User;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System.DBContext.EmployeeRepo
{
    public class EmployeeRepo : IEmployee
    {
        private string _conStr = Helpers.MySqlHelper.GetConnectionString();

        public List<Teacher> GetAllempbytype(string employeetype)
        {
            List<Teacher> teachers = new List<Teacher>();

            using (MySqlConnection conn = new MySqlConnection(_conStr))
            using (MySqlCommand cmd = new MySqlCommand("GetAllEmployeebyType", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("sp_employeetype", employeetype);

                conn.Open();
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Teacher t = new Teacher
                        {
                            FirstName = reader.GetString("Employee_Fname"),
                            MiddleName = reader.GetString("Employee_Mname"),
                            LastName = reader.GetString("Employee_Lname"),
                            DepartmentName = reader.GetString("Department_Name"),
                            Address = reader.GetString("Employee_Address"),
                            Contact_number = reader.GetString("Employee_ContactNumber"),
                            Email = reader.GetString("Employee_Email"),
                            Employeetype = reader.GetString("employee_type")
                        };
                        t.setEmp_ID(reader.GetInt32("Employee_ID"));
                        teachers.Add(t);
                    }
                }
            }

            return teachers;
        }

        public List<Teacher> GetAllemployee()
        {
            List<Teacher> teachers = new List<Teacher>();

            using (MySqlConnection conn = new MySqlConnection(_conStr))
            using (MySqlCommand cmd = new MySqlCommand("GetAllEmployee", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                conn.Open();

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Teacher t = new Teacher
                        {
                            Employeetype = reader.GetString("employee_type"),
                            FirstName = reader.GetString("Employee_Fname"),
                            LastName = reader.GetString("Employee_Lname"),
                            MiddleName = reader.GetString("Employee_Mname"),
                            DepartmentName = reader.GetString("Department_Name"),
                            Address = reader.GetString("Employee_Address"),
                            Birthdate = reader.GetDateTime("Employee_Birthdate"),
                            Gender = reader.GetString("Employee_Gender"),
                            Contact_number = reader.GetString("Employee_ContactNumber"),
                            Email = reader.GetString("Employee_Email")
                        };

                        t.setEmp_ID(reader.GetInt32("Employee_ID"));

                        teachers.Add(t);
                    }
                }
            }

            return teachers;
        }



        public Teacher GetTeacherbyid(int TeacherId)
        {
            using (MySqlConnection conn = new MySqlConnection(_conStr))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetEmployeeById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_EmployeeID", TeacherId);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Teacher t = new Teacher
                            {
                                Employeetype = reader.GetString("employee_type"),
                                FirstName = reader.GetString("Employee_Fname"),
                                LastName = reader.GetString("Employee_Lname"),
                                MiddleName = reader.GetString("Employee_Mname"),
                                DepartmentName = reader.GetString("Department_Name"),
                                Address = reader.GetString("Employee_Address"),
                                Birthdate = reader.GetDateTime("Employee_Birthdate"),
                                Gender = reader.GetString("Employee_Gender"),
                                Contact_number = reader.GetString("Employee_ContactNumber"),
                                Email = reader.GetString("Employee_Email")
                            };

                            t.setEmp_ID(reader.GetInt32("Employee_ID"));

                            return t;
                        }
                    }
                }
                return null;
            }
        }

        public void RemoveTeacher(int TeacherId)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are you sure you want to remove this teacher?",
                                                      "Confirm Delete",
                                                      MessageBoxButtons.YesNo,
                                                      MessageBoxIcon.Warning);
                if (result == DialogResult.No) return;

                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("DeleteEmployee", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_EmployeeID", TeacherId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Employee Removed", "Remove Record",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing Employee: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    


        public void SaveTeacher(Teacher e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("AddEmployee", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_DepartmentName", e.DepartmentName);
                    cmd.Parameters.AddWithValue("sp_Employee_Type", e.Employeetype);
                    cmd.Parameters.AddWithValue("sp_Employee_Lname", e.LastName);
                    cmd.Parameters.AddWithValue("sp_Employee_Fname", e.FirstName);
                    cmd.Parameters.AddWithValue("sp_Employee_Mname", e.MiddleName);
                    cmd.Parameters.AddWithValue("sp_Employee_Address", e.Address);
                    cmd.Parameters.AddWithValue("sp_Employee_Birthdate", e.Birthdate);
                    cmd.Parameters.AddWithValue("sp_Employee_Gender", e.Gender);
                    cmd.Parameters.AddWithValue("sp_Employee_ContactNumber", e.Contact_number);
                    cmd.Parameters.AddWithValue("sp_Employee_Email", e.Email);


                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Employee Added.", "New Employee",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding student: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        public void UpdateTeacher(Teacher e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("UpdateEmployee", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;  

                    cmd.Parameters.AddWithValue("sp_Employee_ID", e.Employee_ID);
                    cmd.Parameters.AddWithValue("sp_DepartmentName", e.DepartmentName);
                    cmd.Parameters.AddWithValue("sp_Employee_Type", e.Employeetype);
                    cmd.Parameters.AddWithValue("sp_Employee_Lname", e.LastName);
                    cmd.Parameters.AddWithValue("sp_Employee_Fname", e.FirstName);
                    cmd.Parameters.AddWithValue("sp_Employee_Mname", e.MiddleName);
                    cmd.Parameters.AddWithValue("sp_Employee_Address", e.Address);
                    cmd.Parameters.AddWithValue("sp_Employee_Birthdate", e.Birthdate);
                    cmd.Parameters.AddWithValue("sp_Employee_Gender", e.Gender);
                    cmd.Parameters.AddWithValue("sp_Employee_ContactNumber", e.Contact_number);
                    cmd.Parameters.AddWithValue("sp_Employee_Email", e.Email);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Employee Updated", "Update Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating Employee: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    
    }
}
