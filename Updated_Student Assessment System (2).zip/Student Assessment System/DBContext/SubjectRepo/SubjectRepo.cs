﻿using MySql.Data.MySqlClient;
using Student_Assessment_System.Course___Subject;
using Student_Assessment_System.Course___Subject_infromation;
using Student_Assessment_System.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System.DBContext.SubjectRepo
{
    public class SubjectRepo : Isubject
    {
        private string _conStr = Helpers.MySqlHelper.GetConnectionString();
        public Subject GetSubjectbyid(int SubjectId)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("GetSubjectByID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Subject_ID", SubjectId);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Subject
                            {
                                Subject_code = reader["sp_Subject_Code"].ToString(),
                                Subject_name = reader["sp_Subject_Name"].ToString()

                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving subject: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return null;
        }

        public void RemoveSubject(int SubjectId)
        {

            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("DeleteSubject", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Subject_ID", SubjectId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Subject Removed", "Remove Record",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing subject: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void SaveSubject(Subject e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("AddSubject", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Subject_Name", e.Subject_name);
                    cmd.Parameters.AddWithValue("sp_Subject_Code", e.Subject_code);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Subject Added.", "New Course",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding subject: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateSubject(Subject e)
        {

            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("UpdateSubject", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Subject_ID", e.Subject_id);
                    cmd.Parameters.AddWithValue("sp_Subject_Name", e.Subject_name);
                    cmd.Parameters.AddWithValue("sp_Subject_Code", e.Subject_code);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Subject Updated", "Update Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating subject: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
