﻿using MySql.Data.MySqlClient;
using Student_Assessment_System.Course___Subject;
using Student_Assessment_System.Course_Section;
using Student_Assessment_System.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System.DBContext.SectionRepo
{
    public class SectionRepo : ISection
    {
        private string _conStr = Helpers.MySqlHelper.GetConnectionString();
        public Section GetSectionbyid(int SectionId)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("GetSectionID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_SectionID", SectionId);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Section
                            {
                                Course_Id = Convert.ToInt32(reader["Course_ID"]),
                                Subject_Id = Convert.ToInt32(reader["Subject_ID"]),
                                Section_name = reader["Section_Name"].ToString(),
                                Year_level = reader["Year_Level"].ToString()

                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving section: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return null;
        }

        public void RemoveSection(int SectionId)
        {

            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("deleteSection", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_SectionID", SectionId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Section Removed", "Remove Record",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing section: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void SaveSection(Section e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("AddSection", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_CourseID", e.Course_Id);
                    cmd.Parameters.AddWithValue("sp_SubjectID", e.Subject_Id);
                    cmd.Parameters.AddWithValue("sp_SectionName", e.Section_name);
                    cmd.Parameters.AddWithValue("sp_YearLevel", e.Year_level);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Section Added.", "New Course",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding section: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateSection(Section e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("UpdateSection", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_SectionID", e.Section_Id);
                    cmd.Parameters.AddWithValue("sp_CourseID", e.Course_Id);
                    cmd.Parameters.AddWithValue("sp_SubjectID", e.Subject_Id);
                    cmd.Parameters.AddWithValue("sp_SectionName", e.Section_name);
                    cmd.Parameters.AddWithValue("sp_YearLevel", e.Year_level);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Section Updated", "Update Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating section: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
