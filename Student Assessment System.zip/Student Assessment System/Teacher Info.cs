﻿using Student_Assessment_System.DBContext.DepartmentRepo;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System
{
    public partial class TeacherAssignments : Form
    {
        
        public TeacherAssignments()
        {
            InitializeComponent();

           
        }

        private void LoadDepartments(string departmentRepo)
        {
           

        }
        private void lblSectionID_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TeacherAssignments_Load(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            
        }
    }
}
