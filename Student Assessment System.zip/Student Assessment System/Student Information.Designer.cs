﻿namespace Student_Assessment_System
{
    partial class Student_Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.txtseacrh = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtsectionid = new System.Windows.Forms.TextBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.DGVStudentinfo = new System.Windows.Forms.DataGridView();
            this.txtstudentid = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblSectionID = new System.Windows.Forms.Label();
            this.lblStudentID = new System.Windows.Forms.Label();
            this.lblstudentinfo = new System.Windows.Forms.Label();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.txtmiddlename = new System.Windows.Forms.TextBox();
            this.lblMiddlename = new System.Windows.Forms.Label();
            this.txtbirthdate = new System.Windows.Forms.TextBox();
            this.lblBirthdate = new System.Windows.Forms.Label();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtgender = new System.Windows.Forms.TextBox();
            this.lblgender = new System.Windows.Forms.Label();
            this.txtcontactnum = new System.Windows.Forms.TextBox();
            this.lblContactnumber = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVStudentinfo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1401, 69);
            this.panel1.TabIndex = 2;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // txtseacrh
            // 
            this.txtseacrh.Location = new System.Drawing.Point(843, 111);
            this.txtseacrh.Multiline = true;
            this.txtseacrh.Name = "txtseacrh";
            this.txtseacrh.Size = new System.Drawing.Size(430, 42);
            this.txtseacrh.TabIndex = 29;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(527, 820);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 27;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(391, 820);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 26;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // txtlastname
            // 
            this.txtlastname.Location = new System.Drawing.Point(226, 309);
            this.txtlastname.Multiline = true;
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(416, 42);
            this.txtlastname.TabIndex = 25;
            // 
            // txtsectionid
            // 
            this.txtsectionid.Location = new System.Drawing.Point(226, 253);
            this.txtsectionid.Multiline = true;
            this.txtsectionid.Name = "txtsectionid";
            this.txtsectionid.Size = new System.Drawing.Size(416, 42);
            this.txtsectionid.TabIndex = 24;
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(246, 820);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(93, 37);
            this.btnadd.TabIndex = 23;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            // 
            // DGVStudentinfo
            // 
            this.DGVStudentinfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVStudentinfo.Location = new System.Drawing.Point(721, 198);
            this.DGVStudentinfo.Name = "DGVStudentinfo";
            this.DGVStudentinfo.RowHeadersWidth = 51;
            this.DGVStudentinfo.RowTemplate.Height = 24;
            this.DGVStudentinfo.Size = new System.Drawing.Size(613, 582);
            this.DGVStudentinfo.TabIndex = 22;
            this.DGVStudentinfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVStudentinfo_CellContentClick);
            // 
            // txtstudentid
            // 
            this.txtstudentid.Location = new System.Drawing.Point(226, 198);
            this.txtstudentid.Multiline = true;
            this.txtstudentid.Name = "txtstudentid";
            this.txtstudentid.Size = new System.Drawing.Size(416, 42);
            this.txtstudentid.TabIndex = 21;
            this.txtstudentid.TextChanged += new System.EventHandler(this.txtstudentid_TextChanged);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(104, 323);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(78, 16);
            this.lblLastName.TabIndex = 20;
            this.lblLastName.Text = "Last Name :";
            // 
            // lblSectionID
            // 
            this.lblSectionID.AutoSize = true;
            this.lblSectionID.Location = new System.Drawing.Point(104, 266);
            this.lblSectionID.Name = "lblSectionID";
            this.lblSectionID.Size = new System.Drawing.Size(74, 16);
            this.lblSectionID.TabIndex = 19;
            this.lblSectionID.Text = "Section ID :";
            // 
            // lblStudentID
            // 
            this.lblStudentID.AutoSize = true;
            this.lblStudentID.Location = new System.Drawing.Point(104, 212);
            this.lblStudentID.Name = "lblStudentID";
            this.lblStudentID.Size = new System.Drawing.Size(74, 16);
            this.lblStudentID.TabIndex = 18;
            this.lblStudentID.Text = "Student ID :";
            // 
            // lblstudentinfo
            // 
            this.lblstudentinfo.AutoSize = true;
            this.lblstudentinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstudentinfo.Location = new System.Drawing.Point(308, 124);
            this.lblstudentinfo.Name = "lblstudentinfo";
            this.lblstudentinfo.Size = new System.Drawing.Size(220, 29);
            this.lblstudentinfo.TabIndex = 17;
            this.lblstudentinfo.Text = "Student Information";
            // 
            // txtfirstname
            // 
            this.txtfirstname.Location = new System.Drawing.Point(226, 367);
            this.txtfirstname.Multiline = true;
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(416, 42);
            this.txtfirstname.TabIndex = 31;
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.Location = new System.Drawing.Point(104, 381);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(78, 16);
            this.lblFirstname.TabIndex = 30;
            this.lblFirstname.Text = "First Name :";
            this.lblFirstname.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtmiddlename
            // 
            this.txtmiddlename.Location = new System.Drawing.Point(226, 424);
            this.txtmiddlename.Multiline = true;
            this.txtmiddlename.Name = "txtmiddlename";
            this.txtmiddlename.Size = new System.Drawing.Size(416, 42);
            this.txtmiddlename.TabIndex = 33;
            // 
            // lblMiddlename
            // 
            this.lblMiddlename.AutoSize = true;
            this.lblMiddlename.Location = new System.Drawing.Point(104, 438);
            this.lblMiddlename.Name = "lblMiddlename";
            this.lblMiddlename.Size = new System.Drawing.Size(94, 16);
            this.lblMiddlename.TabIndex = 32;
            this.lblMiddlename.Text = "Middle Name :";
            // 
            // txtbirthdate
            // 
            this.txtbirthdate.Location = new System.Drawing.Point(226, 485);
            this.txtbirthdate.Multiline = true;
            this.txtbirthdate.Name = "txtbirthdate";
            this.txtbirthdate.Size = new System.Drawing.Size(416, 42);
            this.txtbirthdate.TabIndex = 35;
            // 
            // lblBirthdate
            // 
            this.lblBirthdate.AutoSize = true;
            this.lblBirthdate.Location = new System.Drawing.Point(104, 499);
            this.lblBirthdate.Name = "lblBirthdate";
            this.lblBirthdate.Size = new System.Drawing.Size(66, 16);
            this.lblBirthdate.TabIndex = 34;
            this.lblBirthdate.Text = "Birthdate :";
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(226, 545);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(416, 42);
            this.txtaddress.TabIndex = 37;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(104, 559);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(64, 16);
            this.lblAddress.TabIndex = 36;
            this.lblAddress.Text = "Address :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(721, 116);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 38;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // txtgender
            // 
            this.txtgender.Location = new System.Drawing.Point(226, 615);
            this.txtgender.Multiline = true;
            this.txtgender.Name = "txtgender";
            this.txtgender.Size = new System.Drawing.Size(416, 42);
            this.txtgender.TabIndex = 40;
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(104, 629);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(58, 16);
            this.lblgender.TabIndex = 39;
            this.lblgender.Text = "Gender :";
            // 
            // txtcontactnum
            // 
            this.txtcontactnum.Location = new System.Drawing.Point(226, 677);
            this.txtcontactnum.Multiline = true;
            this.txtcontactnum.Name = "txtcontactnum";
            this.txtcontactnum.Size = new System.Drawing.Size(416, 42);
            this.txtcontactnum.TabIndex = 42;
            // 
            // lblContactnumber
            // 
            this.lblContactnumber.AutoSize = true;
            this.lblContactnumber.Location = new System.Drawing.Point(104, 691);
            this.lblContactnumber.Name = "lblContactnumber";
            this.lblContactnumber.Size = new System.Drawing.Size(109, 16);
            this.lblContactnumber.TabIndex = 41;
            this.lblContactnumber.Text = "Contact Number :";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(226, 738);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(416, 42);
            this.txtemail.TabIndex = 44;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(104, 752);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(47, 16);
            this.lblEmail.TabIndex = 43;
            this.lblEmail.Text = "Email :";
            // 
            // Student_Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1365, 941);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtcontactnum);
            this.Controls.Add(this.lblContactnumber);
            this.Controls.Add(this.txtgender);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtbirthdate);
            this.Controls.Add(this.lblBirthdate);
            this.Controls.Add(this.txtmiddlename);
            this.Controls.Add(this.lblMiddlename);
            this.Controls.Add(this.txtfirstname);
            this.Controls.Add(this.lblFirstname);
            this.Controls.Add(this.txtseacrh);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtlastname);
            this.Controls.Add(this.txtsectionid);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.DGVStudentinfo);
            this.Controls.Add(this.txtstudentid);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblSectionID);
            this.Controls.Add(this.lblStudentID);
            this.Controls.Add(this.lblstudentinfo);
            this.Controls.Add(this.panel1);
            this.Name = "Student_Information";
            this.Text = "Student_Information";
            this.Load += new System.EventHandler(this.Student_Information_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVStudentinfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.TextBox txtseacrh;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.TextBox txtsectionid;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.DataGridView DGVStudentinfo;
        private System.Windows.Forms.TextBox txtstudentid;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblSectionID;
        private System.Windows.Forms.Label lblStudentID;
        private System.Windows.Forms.Label lblstudentinfo;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.TextBox txtmiddlename;
        private System.Windows.Forms.Label lblMiddlename;
        private System.Windows.Forms.TextBox txtbirthdate;
        private System.Windows.Forms.Label lblBirthdate;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtgender;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.TextBox txtcontactnum;
        private System.Windows.Forms.Label lblContactnumber;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label lblEmail;
    }
}