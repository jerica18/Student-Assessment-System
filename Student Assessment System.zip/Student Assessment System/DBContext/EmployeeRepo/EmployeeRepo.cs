﻿using MySql.Data.MySqlClient;
using Student_Assessment_System.Interface;
using Student_Assessment_System.Module;
using Student_Assessment_System.User;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System.DBContext.EmployeeRepo
{
    public class EmployeeRepo : IEmployee
    {
        private string _conStr = Helpers.MySqlHelper.GetConnectionString();

        public Employee GetTeacherbyid(int TeacherId)
        {
            using (MySqlConnection conn = new MySqlConnection(_conStr))
            {
                using (MySqlCommand cmd = new MySqlCommand("GetEmployeeById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_EmployeeID", TeacherId);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())

                        {
                            return new Teacher
                            {
                                DepartmentaName = reader["sp_DepartmentName"].ToString(),
                                LastName = reader["sp_Employee_Lname"].ToString(),
                                FirstName = reader["sp_Employee_Fname"].ToString(),
                                MiddleName = reader["sp_Employee_Mname"].ToString(),
                                Address = reader["sp_Employee_Address"].ToString(),
                                Birthdate = Convert.ToDateTime(reader["sp_Employee_Birthdate"]),
                                Gender = reader["sp_Employee_Gender"].ToString(),
                                Contact_number = reader["sp_Employee_ContactNumber"].ToString(),
                                Email = reader["sp_Employee_Email"].ToString()
                            };

                        }

                    }
                }

            }
            return null;
        }

        public void RemoveTeacher(int TeacherId)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are you sure you want to remove this teacher?",
                                                      "Confirm Delete",
                                                      MessageBoxButtons.YesNo,
                                                      MessageBoxIcon.Warning);
                if (result == DialogResult.No) return;

                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("DeleteEmployee", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_EmployeeID", TeacherId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Teacher Removed", "Remove Record",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing teacher: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    


        public void SaveTeacher(Teacher e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("AddEmployee", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue(" sp_DepartmentName", e.DepartmentaName);
                    cmd.Parameters.AddWithValue("sp_Employee_Lname ", e.LastName);
                    cmd.Parameters.AddWithValue(" sp_Employee_Fname", e.FirstName);
                    cmd.Parameters.AddWithValue("sp_Employee_Mname ", e.MiddleName);
                    cmd.Parameters.AddWithValue("sp_Employee_Address ", e.Address);
                    cmd.Parameters.AddWithValue("sp_Employee_Birthdate", e.Birthdate);
                    cmd.Parameters.AddWithValue("sp_Employee_Gender", e.Gender);
                    cmd.Parameters.AddWithValue("sp_Employee_ContactNumber", e.Contact_number);
                    cmd.Parameters.AddWithValue("sp_Employee_Email ", e.Email);


                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Student Added.", "New Student",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding student: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        public void UpdateTeacher(Teacher e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("UpdateEmployee", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Employee_ID", e.emp_ID);
                    cmd.Parameters.AddWithValue("sp_DepartmentName", e.DepartmentaName);
                    cmd.Parameters.AddWithValue("sp_Employee_Lname", e.LastName);
                    cmd.Parameters.AddWithValue("sp_Employee_Fname", e.FirstName);
                    cmd.Parameters.AddWithValue("sp_Employee_Mname", e.MiddleName);
                    cmd.Parameters.AddWithValue("sp_Employee_Address", e.Address);
                    cmd.Parameters.AddWithValue(" sp_Employee_Birthdate", e.Birthdate);
                    cmd.Parameters.AddWithValue("sp_Employee_Gender", e.Gender);
                    cmd.Parameters.AddWithValue("sp_Employee_ContactNumber", e.Contact_number);
                    cmd.Parameters.AddWithValue("sp_Employee_Email", e.Email);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Employee Updated", "Update Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating Employee: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    
    }
}
