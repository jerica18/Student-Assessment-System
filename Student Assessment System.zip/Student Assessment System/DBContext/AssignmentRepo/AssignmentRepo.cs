﻿using MySql.Data.MySqlClient;
using Student_Assessment_System.Course___Subject;
using Student_Assessment_System.Interface;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System.DBContext.AssignmentRepo
{
    public class AssignmentRepo : IAssignment
    {
        private string _conStr = Helpers.MySqlHelper.GetConnectionString();
        public Assignment GetAssignmentbyid(int AssignemnetId)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("GetAssignmentsById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Assignment_ID", AssignemnetId);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Assignment
                            {
                                
                                AssignmentID = Convert.ToInt32(reader["Assignment_ID"]),
                                TeacherID = Convert.ToInt32(reader["Employee_ID"]),
                                CourseID = Convert.ToInt32(reader["Course_ID"]),
                                SubjectID = Convert.ToInt32(reader["Subject_ID"]),
                                termID = Convert.ToInt32(reader["Term_ID"]),
                                SectionID = Convert.ToInt32(reader["Section_ID"]),
                                Assignment_Schedule = reader["Assignment_Schedule"].ToString(),

                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving course: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return null;
        }

        public void RemoveAssignment(int AssignmentId)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("DeleteAssignments", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Assignment_ID", AssignmentId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Assignment Removed", "Remove Record",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing assignment: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void SaveAssignment(Assignment e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("AddAssignments", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Employee_ID", e.TeacherID);
                    cmd.Parameters.AddWithValue("sp_Course_ID", e.CourseID);
                    cmd.Parameters.AddWithValue("sp_Subject_ID", e.SubjectID);
                    cmd.Parameters.AddWithValue("sp_Term_ID", e.termID);
                    cmd.Parameters.AddWithValue("sp_Section_ID", e.SectionID);
                    cmd.Parameters.AddWithValue("sp_Assignment_Schedule", e.Assignment_Schedule);
                  

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Assignment Added.", "New Student",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding assignment: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateAssignment(Assignment e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("updateAssignments", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Assignment_ID", e.AssignmentID);
                    cmd.Parameters.AddWithValue("sp_Employee_ID", e.TeacherID);
                    cmd.Parameters.AddWithValue("sp_Course_ID", e.CourseID);
                    cmd.Parameters.AddWithValue("sp_Subject_ID", e.SubjectID);
                    cmd.Parameters.AddWithValue("sp_Term_ID", e.termID);
                    cmd.Parameters.AddWithValue("sp_Section_ID", e.SectionID);
                    cmd.Parameters.AddWithValue("sp_Assignment_Schedule", e.Assignment_Schedule);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Assignment Updated", "Update Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating assignment: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
     
    }
}
