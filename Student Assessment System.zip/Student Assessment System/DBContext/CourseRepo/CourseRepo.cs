﻿using MySql.Data.MySqlClient;
using Student_Assessment_System.Course___Subject;
using Student_Assessment_System.Interface;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Assessment_System.DBContext.CourseRepo
{
    public class CourseRepo : ICourse
    {
        private string _conStr = Helpers.MySqlHelper.GetConnectionString();


        public Course GetCoursebyid(int CourseId)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("GetCourseByID", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Course_ID", CourseId);

                    conn.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Course
                            {
                                Course_name = reader["Course_Name"].ToString()
                                              
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving course: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return null;
        }


        public void RemoveCourse(int CourseId)
        {

            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("DeleteCourse", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("sp_Course_ID", CourseId);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Course Removed", "Remove Record",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing course: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        public void SaveCourse(Course e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("AddCourse", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Course_Name", e.Course_name);
                    
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Course Added.", "New Course",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding course: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Updatecourse(Course e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_conStr))
                using (MySqlCommand cmd = new MySqlCommand("UpdateCourse", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("sp_Course_ID", e.Course_id);
                    cmd.Parameters.AddWithValue("sp_Course_Name", e.Course_name);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Course Updated", "Update Record",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating course: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
 }
