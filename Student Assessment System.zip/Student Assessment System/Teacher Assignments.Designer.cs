﻿namespace Student_Assessment_System
{
    partial class Teacher_Assignments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.txtSubjectId = new System.Windows.Forms.TextBox();
            this.lblSubjectId = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtTermId = new System.Windows.Forms.TextBox();
            this.txtCourseId = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.DGVTeacherAssignments = new System.Windows.Forms.DataGridView();
            this.txtTeacherID = new System.Windows.Forms.TextBox();
            this.lbltermID = new System.Windows.Forms.Label();
            this.lblcourseid = new System.Windows.Forms.Label();
            this.lblTeacherID = new System.Windows.Forms.Label();
            this.lblAssignment = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblAssignmentSchedule = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVTeacherAssignments)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1401, 69);
            this.panel1.TabIndex = 4;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // txtSubjectId
            // 
            this.txtSubjectId.Location = new System.Drawing.Point(191, 320);
            this.txtSubjectId.Multiline = true;
            this.txtSubjectId.Name = "txtSubjectId";
            this.txtSubjectId.Size = new System.Drawing.Size(416, 42);
            this.txtSubjectId.TabIndex = 47;
            // 
            // lblSubjectId
            // 
            this.lblSubjectId.AutoSize = true;
            this.lblSubjectId.Location = new System.Drawing.Point(31, 336);
            this.lblSubjectId.Name = "lblSubjectId";
            this.lblSubjectId.Size = new System.Drawing.Size(74, 16);
            this.lblSubjectId.TabIndex = 46;
            this.lblSubjectId.Text = "Subject ID :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(698, 130);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 45;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(819, 127);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(430, 42);
            this.txtSearch.TabIndex = 44;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(487, 516);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 43;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(351, 516);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 42;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // txtTermId
            // 
            this.txtTermId.Location = new System.Drawing.Point(191, 382);
            this.txtTermId.Multiline = true;
            this.txtTermId.Name = "txtTermId";
            this.txtTermId.Size = new System.Drawing.Size(416, 42);
            this.txtTermId.TabIndex = 41;
            // 
            // txtCourseId
            // 
            this.txtCourseId.Location = new System.Drawing.Point(191, 260);
            this.txtCourseId.Multiline = true;
            this.txtCourseId.Name = "txtCourseId";
            this.txtCourseId.Size = new System.Drawing.Size(416, 42);
            this.txtCourseId.TabIndex = 40;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(206, 516);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(93, 37);
            this.btnAdd.TabIndex = 39;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // DGVTeacherAssignments
            // 
            this.DGVTeacherAssignments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVTeacherAssignments.Location = new System.Drawing.Point(657, 211);
            this.DGVTeacherAssignments.Name = "DGVTeacherAssignments";
            this.DGVTeacherAssignments.RowHeadersWidth = 51;
            this.DGVTeacherAssignments.RowTemplate.Height = 24;
            this.DGVTeacherAssignments.Size = new System.Drawing.Size(679, 428);
            this.DGVTeacherAssignments.TabIndex = 38;
            // 
            // txtTeacherID
            // 
            this.txtTeacherID.Location = new System.Drawing.Point(191, 205);
            this.txtTeacherID.Multiline = true;
            this.txtTeacherID.Name = "txtTeacherID";
            this.txtTeacherID.Size = new System.Drawing.Size(416, 42);
            this.txtTeacherID.TabIndex = 37;
            // 
            // lbltermID
            // 
            this.lbltermID.AutoSize = true;
            this.lbltermID.Location = new System.Drawing.Point(31, 398);
            this.lbltermID.Name = "lbltermID";
            this.lbltermID.Size = new System.Drawing.Size(61, 16);
            this.lbltermID.TabIndex = 36;
            this.lbltermID.Text = "Term ID :";
            // 
            // lblcourseid
            // 
            this.lblcourseid.AutoSize = true;
            this.lblcourseid.Location = new System.Drawing.Point(31, 275);
            this.lblcourseid.Name = "lblcourseid";
            this.lblcourseid.Size = new System.Drawing.Size(72, 16);
            this.lblcourseid.TabIndex = 35;
            this.lblcourseid.Text = "Course ID :";
            // 
            // lblTeacherID
            // 
            this.lblTeacherID.AutoSize = true;
            this.lblTeacherID.Location = new System.Drawing.Point(31, 221);
            this.lblTeacherID.Name = "lblTeacherID";
            this.lblTeacherID.Size = new System.Drawing.Size(80, 16);
            this.lblTeacherID.TabIndex = 34;
            this.lblTeacherID.Text = "Teacher ID :";
            // 
            // lblAssignment
            // 
            this.lblAssignment.AutoSize = true;
            this.lblAssignment.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignment.Location = new System.Drawing.Point(270, 140);
            this.lblAssignment.Name = "lblAssignment";
            this.lblAssignment.Size = new System.Drawing.Size(246, 29);
            this.lblAssignment.TabIndex = 33;
            this.lblAssignment.Text = "Teacher Assignments";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(191, 441);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(416, 42);
            this.textBox1.TabIndex = 49;
            // 
            // lblAssignmentSchedule
            // 
            this.lblAssignmentSchedule.AutoSize = true;
            this.lblAssignmentSchedule.Location = new System.Drawing.Point(31, 457);
            this.lblAssignmentSchedule.Name = "lblAssignmentSchedule";
            this.lblAssignmentSchedule.Size = new System.Drawing.Size(143, 16);
            this.lblAssignmentSchedule.TabIndex = 48;
            this.lblAssignmentSchedule.Text = "Assignment Schedule :";
            // 
            // Teacher_Assignments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1366, 740);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblAssignmentSchedule);
            this.Controls.Add(this.txtSubjectId);
            this.Controls.Add(this.lblSubjectId);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtTermId);
            this.Controls.Add(this.txtCourseId);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.DGVTeacherAssignments);
            this.Controls.Add(this.txtTeacherID);
            this.Controls.Add(this.lbltermID);
            this.Controls.Add(this.lblcourseid);
            this.Controls.Add(this.lblTeacherID);
            this.Controls.Add(this.lblAssignment);
            this.Controls.Add(this.panel1);
            this.Name = "Teacher_Assignments";
            this.Text = "Teacher_Assignments";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVTeacherAssignments)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.TextBox txtSubjectId;
        private System.Windows.Forms.Label lblSubjectId;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtTermId;
        private System.Windows.Forms.TextBox txtCourseId;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView DGVTeacherAssignments;
        private System.Windows.Forms.TextBox txtTeacherID;
        private System.Windows.Forms.Label lbltermID;
        private System.Windows.Forms.Label lblcourseid;
        private System.Windows.Forms.Label lblTeacherID;
        private System.Windows.Forms.Label lblAssignment;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblAssignmentSchedule;
    }
}