﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Course___Subject_infromation
{
    public class Subject
    {
        public int Subject_id {  get; set; }
        public string Subject_name { get; set; }
        public string Subject_code { get; set; }
    }
}
