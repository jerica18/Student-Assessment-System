﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Services
{
    public  class Assignments
    {
        public int AssignmentID { get; set; }
        public int TeacherID { get; set; }
        public int CourseID { get; set; }
        public int SubjectID { get; set; }
        public int SectionID { get; set; }
        public int termID { get; set; }
        public string Assignment_Schedule { get; set; }
        
    }
}
