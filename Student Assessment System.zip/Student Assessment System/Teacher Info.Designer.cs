﻿namespace Student_Assessment_System
{
    partial class TeacherAssignments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtcontactnum = new System.Windows.Forms.TextBox();
            this.lblContactnumber = new System.Windows.Forms.Label();
            this.txtgender = new System.Windows.Forms.TextBox();
            this.lblgender = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtBirthdate = new System.Windows.Forms.TextBox();
            this.lblBirthdate = new System.Windows.Forms.Label();
            this.txtMname = new System.Windows.Forms.TextBox();
            this.lblMiddlename = new System.Windows.Forms.Label();
            this.txtFname = new System.Windows.Forms.TextBox();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.txtseacrh = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtLname = new System.Windows.Forms.TextBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.DGVteacherinfo = new System.Windows.Forms.DataGridView();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblSectionID = new System.Windows.Forms.Label();
            this.lblTeacherinfo = new System.Windows.Forms.Label();
            this.txtdepartment = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVteacherinfo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1401, 69);
            this.panel1.TabIndex = 4;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(193, 683);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(416, 42);
            this.txtemail.TabIndex = 71;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(71, 697);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(47, 16);
            this.lblEmail.TabIndex = 70;
            this.lblEmail.Text = "Email :";
            // 
            // txtcontactnum
            // 
            this.txtcontactnum.Location = new System.Drawing.Point(193, 622);
            this.txtcontactnum.Multiline = true;
            this.txtcontactnum.Name = "txtcontactnum";
            this.txtcontactnum.Size = new System.Drawing.Size(416, 42);
            this.txtcontactnum.TabIndex = 69;
            // 
            // lblContactnumber
            // 
            this.lblContactnumber.AutoSize = true;
            this.lblContactnumber.Location = new System.Drawing.Point(71, 636);
            this.lblContactnumber.Name = "lblContactnumber";
            this.lblContactnumber.Size = new System.Drawing.Size(109, 16);
            this.lblContactnumber.TabIndex = 68;
            this.lblContactnumber.Text = "Contact Number :";
            // 
            // txtgender
            // 
            this.txtgender.Location = new System.Drawing.Point(193, 560);
            this.txtgender.Multiline = true;
            this.txtgender.Name = "txtgender";
            this.txtgender.Size = new System.Drawing.Size(416, 42);
            this.txtgender.TabIndex = 67;
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(71, 574);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(58, 16);
            this.lblgender.TabIndex = 66;
            this.lblgender.Text = "Gender :";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(681, 116);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 65;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(193, 490);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(416, 42);
            this.txtAddress.TabIndex = 64;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(71, 504);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(64, 16);
            this.lblAddress.TabIndex = 63;
            this.lblAddress.Text = "Address :";
            // 
            // txtBirthdate
            // 
            this.txtBirthdate.Location = new System.Drawing.Point(193, 430);
            this.txtBirthdate.Multiline = true;
            this.txtBirthdate.Name = "txtBirthdate";
            this.txtBirthdate.Size = new System.Drawing.Size(416, 42);
            this.txtBirthdate.TabIndex = 62;
            // 
            // lblBirthdate
            // 
            this.lblBirthdate.AutoSize = true;
            this.lblBirthdate.Location = new System.Drawing.Point(71, 444);
            this.lblBirthdate.Name = "lblBirthdate";
            this.lblBirthdate.Size = new System.Drawing.Size(66, 16);
            this.lblBirthdate.TabIndex = 61;
            this.lblBirthdate.Text = "Birthdate :";
            // 
            // txtMname
            // 
            this.txtMname.Location = new System.Drawing.Point(193, 369);
            this.txtMname.Multiline = true;
            this.txtMname.Name = "txtMname";
            this.txtMname.Size = new System.Drawing.Size(416, 42);
            this.txtMname.TabIndex = 60;
            // 
            // lblMiddlename
            // 
            this.lblMiddlename.AutoSize = true;
            this.lblMiddlename.Location = new System.Drawing.Point(71, 383);
            this.lblMiddlename.Name = "lblMiddlename";
            this.lblMiddlename.Size = new System.Drawing.Size(94, 16);
            this.lblMiddlename.TabIndex = 59;
            this.lblMiddlename.Text = "Middle Name :";
            // 
            // txtFname
            // 
            this.txtFname.Location = new System.Drawing.Point(193, 312);
            this.txtFname.Multiline = true;
            this.txtFname.Name = "txtFname";
            this.txtFname.Size = new System.Drawing.Size(416, 42);
            this.txtFname.TabIndex = 58;
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.Location = new System.Drawing.Point(71, 326);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(78, 16);
            this.lblFirstname.TabIndex = 57;
            this.lblFirstname.Text = "First Name :";
            // 
            // txtseacrh
            // 
            this.txtseacrh.Location = new System.Drawing.Point(803, 111);
            this.txtseacrh.Multiline = true;
            this.txtseacrh.Name = "txtseacrh";
            this.txtseacrh.Size = new System.Drawing.Size(430, 42);
            this.txtseacrh.TabIndex = 56;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(491, 765);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 55;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(355, 765);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 54;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // txtLname
            // 
            this.txtLname.Location = new System.Drawing.Point(193, 254);
            this.txtLname.Multiline = true;
            this.txtLname.Name = "txtLname";
            this.txtLname.Size = new System.Drawing.Size(416, 42);
            this.txtLname.TabIndex = 53;
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(210, 765);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(93, 37);
            this.btnadd.TabIndex = 51;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // DGVteacherinfo
            // 
            this.DGVteacherinfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVteacherinfo.Location = new System.Drawing.Point(681, 198);
            this.DGVteacherinfo.Name = "DGVteacherinfo";
            this.DGVteacherinfo.RowHeadersWidth = 51;
            this.DGVteacherinfo.RowTemplate.Height = 24;
            this.DGVteacherinfo.Size = new System.Drawing.Size(613, 582);
            this.DGVteacherinfo.TabIndex = 50;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(71, 268);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(78, 16);
            this.lblLastName.TabIndex = 48;
            this.lblLastName.Text = "Last Name :";
            // 
            // lblSectionID
            // 
            this.lblSectionID.AutoSize = true;
            this.lblSectionID.Location = new System.Drawing.Point(71, 211);
            this.lblSectionID.Name = "lblSectionID";
            this.lblSectionID.Size = new System.Drawing.Size(86, 16);
            this.lblSectionID.TabIndex = 47;
            this.lblSectionID.Text = "Department  :";
            this.lblSectionID.Click += new System.EventHandler(this.lblSectionID_Click);
            // 
            // lblTeacherinfo
            // 
            this.lblTeacherinfo.AutoSize = true;
            this.lblTeacherinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeacherinfo.Location = new System.Drawing.Point(268, 124);
            this.lblTeacherinfo.Name = "lblTeacherinfo";
            this.lblTeacherinfo.Size = new System.Drawing.Size(220, 29);
            this.lblTeacherinfo.TabIndex = 45;
            this.lblTeacherinfo.Text = "Teacher Infomation";
            // 
            // txtdepartment
            // 
            this.txtdepartment.Location = new System.Drawing.Point(193, 185);
            this.txtdepartment.Multiline = true;
            this.txtdepartment.Name = "txtdepartment";
            this.txtdepartment.Size = new System.Drawing.Size(416, 42);
            this.txtdepartment.TabIndex = 72;
            // 
            // TeacherAssignments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1340, 913);
            this.Controls.Add(this.txtdepartment);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtcontactnum);
            this.Controls.Add(this.lblContactnumber);
            this.Controls.Add(this.txtgender);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtBirthdate);
            this.Controls.Add(this.lblBirthdate);
            this.Controls.Add(this.txtMname);
            this.Controls.Add(this.lblMiddlename);
            this.Controls.Add(this.txtFname);
            this.Controls.Add(this.lblFirstname);
            this.Controls.Add(this.txtseacrh);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtLname);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.DGVteacherinfo);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblSectionID);
            this.Controls.Add(this.lblTeacherinfo);
            this.Controls.Add(this.panel1);
            this.Name = "TeacherAssignments";
            this.Text = "TeacherAssignments";
            this.Load += new System.EventHandler(this.TeacherAssignments_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVteacherinfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtcontactnum;
        private System.Windows.Forms.Label lblContactnumber;
        private System.Windows.Forms.TextBox txtgender;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtBirthdate;
        private System.Windows.Forms.Label lblBirthdate;
        private System.Windows.Forms.TextBox txtMname;
        private System.Windows.Forms.Label lblMiddlename;
        private System.Windows.Forms.TextBox txtFname;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.TextBox txtseacrh;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtLname;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.DataGridView DGVteacherinfo;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblSectionID;
        private System.Windows.Forms.Label lblTeacherinfo;
        private System.Windows.Forms.TextBox txtdepartment;
    }
}