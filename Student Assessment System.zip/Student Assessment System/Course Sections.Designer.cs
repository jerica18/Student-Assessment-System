﻿namespace Student_Assessment_System
{
    partial class Course_Sections
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSAS = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtSectionId = new System.Windows.Forms.TextBox();
            this.txtsubjectid = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.DGVCourseSection = new System.Windows.Forms.DataGridView();
            this.txtcourseId = new System.Windows.Forms.TextBox();
            this.lblsectionName = new System.Windows.Forms.Label();
            this.lblSubjectId = new System.Windows.Forms.Label();
            this.lblCourseId = new System.Windows.Forms.Label();
            this.lblSection = new System.Windows.Forms.Label();
            this.txtyearllevel = new System.Windows.Forms.TextBox();
            this.lblyearlevel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCourseSection)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1376, 69);
            this.panel1.TabIndex = 2;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(225, 20);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(662, 126);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(93, 37);
            this.btnSearch.TabIndex = 30;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(783, 123);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(430, 42);
            this.txtSearch.TabIndex = 29;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(435, 453);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 37);
            this.btnUpdate.TabIndex = 28;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(299, 453);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 37);
            this.btnDelete.TabIndex = 27;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // txtSectionId
            // 
            this.txtSectionId.Location = new System.Drawing.Point(137, 314);
            this.txtSectionId.Multiline = true;
            this.txtSectionId.Name = "txtSectionId";
            this.txtSectionId.Size = new System.Drawing.Size(416, 42);
            this.txtSectionId.TabIndex = 26;
            // 
            // txtsubjectid
            // 
            this.txtsubjectid.Location = new System.Drawing.Point(137, 258);
            this.txtsubjectid.Multiline = true;
            this.txtsubjectid.Name = "txtsubjectid";
            this.txtsubjectid.Size = new System.Drawing.Size(416, 42);
            this.txtsubjectid.TabIndex = 25;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(154, 453);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(93, 37);
            this.btnAdd.TabIndex = 24;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // DGVCourseSection
            // 
            this.DGVCourseSection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVCourseSection.Location = new System.Drawing.Point(621, 207);
            this.DGVCourseSection.Name = "DGVCourseSection";
            this.DGVCourseSection.RowHeadersWidth = 51;
            this.DGVCourseSection.RowTemplate.Height = 24;
            this.DGVCourseSection.Size = new System.Drawing.Size(679, 428);
            this.DGVCourseSection.TabIndex = 23;
            // 
            // txtcourseId
            // 
            this.txtcourseId.Location = new System.Drawing.Point(137, 203);
            this.txtcourseId.Multiline = true;
            this.txtcourseId.Name = "txtcourseId";
            this.txtcourseId.Size = new System.Drawing.Size(416, 42);
            this.txtcourseId.TabIndex = 22;
            // 
            // lblsectionName
            // 
            this.lblsectionName.AutoSize = true;
            this.lblsectionName.Location = new System.Drawing.Point(15, 328);
            this.lblsectionName.Name = "lblsectionName";
            this.lblsectionName.Size = new System.Drawing.Size(98, 16);
            this.lblsectionName.TabIndex = 21;
            this.lblsectionName.Text = "Section Name :";
            // 
            // lblSubjectId
            // 
            this.lblSubjectId.AutoSize = true;
            this.lblSubjectId.Location = new System.Drawing.Point(15, 271);
            this.lblSubjectId.Name = "lblSubjectId";
            this.lblSubjectId.Size = new System.Drawing.Size(74, 16);
            this.lblSubjectId.TabIndex = 20;
            this.lblSubjectId.Text = "Subject ID :";
            // 
            // lblCourseId
            // 
            this.lblCourseId.AutoSize = true;
            this.lblCourseId.Location = new System.Drawing.Point(15, 217);
            this.lblCourseId.Name = "lblCourseId";
            this.lblCourseId.Size = new System.Drawing.Size(72, 16);
            this.lblCourseId.TabIndex = 19;
            this.lblCourseId.Text = "Course ID :";
            this.lblCourseId.Click += new System.EventHandler(this.lbl_Click);
            // 
            // lblSection
            // 
            this.lblSection.AutoSize = true;
            this.lblSection.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSection.Location = new System.Drawing.Point(169, 134);
            this.lblSection.Name = "lblSection";
            this.lblSection.Size = new System.Drawing.Size(184, 29);
            this.lblSection.TabIndex = 18;
            this.lblSection.Text = "Course Section ";
            // 
            // txtyearllevel
            // 
            this.txtyearllevel.Location = new System.Drawing.Point(137, 372);
            this.txtyearllevel.Multiline = true;
            this.txtyearllevel.Name = "txtyearllevel";
            this.txtyearllevel.Size = new System.Drawing.Size(416, 42);
            this.txtyearllevel.TabIndex = 32;
            // 
            // lblyearlevel
            // 
            this.lblyearlevel.AutoSize = true;
            this.lblyearlevel.Location = new System.Drawing.Point(15, 386);
            this.lblyearlevel.Name = "lblyearlevel";
            this.lblyearlevel.Size = new System.Drawing.Size(78, 16);
            this.lblyearlevel.TabIndex = 31;
            this.lblyearlevel.Text = "Year Level :";
            // 
            // Course_Sections
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1325, 711);
            this.Controls.Add(this.txtyearllevel);
            this.Controls.Add(this.lblyearlevel);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtSectionId);
            this.Controls.Add(this.txtsubjectid);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.DGVCourseSection);
            this.Controls.Add(this.txtcourseId);
            this.Controls.Add(this.lblsectionName);
            this.Controls.Add(this.lblSubjectId);
            this.Controls.Add(this.lblCourseId);
            this.Controls.Add(this.lblSection);
            this.Controls.Add(this.panel1);
            this.Name = "Course_Sections";
            this.Text = "Course_Sections";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCourseSection)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtSectionId;
        private System.Windows.Forms.TextBox txtsubjectid;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView DGVCourseSection;
        private System.Windows.Forms.TextBox txtcourseId;
        private System.Windows.Forms.Label lblsectionName;
        private System.Windows.Forms.Label lblSubjectId;
        private System.Windows.Forms.Label lblCourseId;
        private System.Windows.Forms.Label lblSection;
        private System.Windows.Forms.TextBox txtyearllevel;
        private System.Windows.Forms.Label lblyearlevel;
    }
}