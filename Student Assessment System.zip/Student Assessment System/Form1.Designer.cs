﻿namespace Student_Assessment_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblUserAcc = new System.Windows.Forms.Label();
            this.lblSubInfo = new System.Windows.Forms.Label();
            this.lbldashboard = new System.Windows.Forms.Label();
            this.lbltestassessment = new System.Windows.Forms.Label();
            this.lbltestadmin = new System.Windows.Forms.Label();
            this.lblScoreGrading = new System.Windows.Forms.Label();
            this.lblItemAnalysis = new System.Windows.Forms.Label();
            this.lblPerformance = new System.Windows.Forms.Label();
            this.lblReports = new System.Windows.Forms.Label();
            this.btnSubjectCourse = new System.Windows.Forms.Button();
            this.btnCourseSection = new System.Windows.Forms.Button();
            this.btnStudentInfo = new System.Windows.Forms.Button();
            this.btnTeacherAssignments = new System.Windows.Forms.Button();
            this.lblSAS = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnAcademicTerm = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btnLogOut);
            this.panel1.Controls.Add(this.lblSAS);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(985, 69);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Controls.Add(this.btnAcademicTerm);
            this.panel2.Controls.Add(this.btnTeacherAssignments);
            this.panel2.Controls.Add(this.btnStudentInfo);
            this.panel2.Controls.Add(this.btnCourseSection);
            this.panel2.Controls.Add(this.btnSubjectCourse);
            this.panel2.Controls.Add(this.lblReports);
            this.panel2.Controls.Add(this.lblPerformance);
            this.panel2.Controls.Add(this.lblItemAnalysis);
            this.panel2.Controls.Add(this.lblScoreGrading);
            this.panel2.Controls.Add(this.lbltestadmin);
            this.panel2.Controls.Add(this.lbltestassessment);
            this.panel2.Controls.Add(this.lbldashboard);
            this.panel2.Controls.Add(this.lblSubInfo);
            this.panel2.Controls.Add(this.lblUserAcc);
            this.panel2.Location = new System.Drawing.Point(1, 69);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(305, 1116);
            this.panel2.TabIndex = 1;
            // 
            // lblUserAcc
            // 
            this.lblUserAcc.AutoSize = true;
            this.lblUserAcc.Location = new System.Drawing.Point(25, 25);
            this.lblUserAcc.Name = "lblUserAcc";
            this.lblUserAcc.Size = new System.Drawing.Size(118, 16);
            this.lblUserAcc.TabIndex = 2;
            this.lblUserAcc.Text = "User Management";
            // 
            // lblSubInfo
            // 
            this.lblSubInfo.AutoSize = true;
            this.lblSubInfo.Location = new System.Drawing.Point(25, 158);
            this.lblSubInfo.Name = "lblSubInfo";
            this.lblSubInfo.Size = new System.Drawing.Size(187, 16);
            this.lblSubInfo.TabIndex = 3;
            this.lblSubInfo.Text = "Subject / Course Management";
            // 
            // lbldashboard
            // 
            this.lbldashboard.AutoSize = true;
            this.lbldashboard.Location = new System.Drawing.Point(25, 89);
            this.lbldashboard.Name = "lbldashboard";
            this.lbldashboard.Size = new System.Drawing.Size(75, 16);
            this.lbldashboard.TabIndex = 4;
            this.lbldashboard.Text = "Dashboard";
            this.lbldashboard.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbltestassessment
            // 
            this.lbltestassessment.AutoSize = true;
            this.lbltestassessment.Location = new System.Drawing.Point(25, 538);
            this.lbltestassessment.Name = "lbltestassessment";
            this.lbltestassessment.Size = new System.Drawing.Size(219, 16);
            this.lbltestassessment.TabIndex = 5;
            this.lbltestassessment.Text = "Test / Assessment Creation Module";
            // 
            // lbltestadmin
            // 
            this.lbltestadmin.AutoSize = true;
            this.lbltestadmin.Location = new System.Drawing.Point(25, 590);
            this.lbltestadmin.Name = "lbltestadmin";
            this.lbltestadmin.Size = new System.Drawing.Size(121, 16);
            this.lbltestadmin.TabIndex = 6;
            this.lbltestadmin.Text = "Test Administration";
            // 
            // lblScoreGrading
            // 
            this.lblScoreGrading.AutoSize = true;
            this.lblScoreGrading.Location = new System.Drawing.Point(25, 654);
            this.lblScoreGrading.Name = "lblScoreGrading";
            this.lblScoreGrading.Size = new System.Drawing.Size(107, 16);
            this.lblScoreGrading.TabIndex = 7;
            this.lblScoreGrading.Text = "Scoring & Grading";
            // 
            // lblItemAnalysis
            // 
            this.lblItemAnalysis.AutoSize = true;
            this.lblItemAnalysis.Location = new System.Drawing.Point(25, 714);
            this.lblItemAnalysis.Name = "lblItemAnalysis";
            this.lblItemAnalysis.Size = new System.Drawing.Size(134, 16);
            this.lblItemAnalysis.TabIndex = 8;
            this.lblItemAnalysis.Text = "Item Analysis Module";
            // 
            // lblPerformance
            // 
            this.lblPerformance.AutoSize = true;
            this.lblPerformance.Location = new System.Drawing.Point(25, 770);
            this.lblPerformance.Name = "lblPerformance";
            this.lblPerformance.Size = new System.Drawing.Size(141, 16);
            this.lblPerformance.TabIndex = 9;
            this.lblPerformance.Text = "Performance Analytics";
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.Location = new System.Drawing.Point(25, 818);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(114, 16);
            this.lblReports.TabIndex = 10;
            this.lblReports.Text = "Reporting Module";
            // 
            // btnSubjectCourse
            // 
            this.btnSubjectCourse.Location = new System.Drawing.Point(40, 200);
            this.btnSubjectCourse.Name = "btnSubjectCourse";
            this.btnSubjectCourse.Size = new System.Drawing.Size(204, 40);
            this.btnSubjectCourse.TabIndex = 2;
            this.btnSubjectCourse.Text = "Subject / Course Info";
            this.btnSubjectCourse.UseVisualStyleBackColor = true;
            // 
            // btnCourseSection
            // 
            this.btnCourseSection.Location = new System.Drawing.Point(40, 269);
            this.btnCourseSection.Name = "btnCourseSection";
            this.btnCourseSection.Size = new System.Drawing.Size(204, 40);
            this.btnCourseSection.TabIndex = 11;
            this.btnCourseSection.Text = "Course Sections";
            this.btnCourseSection.UseVisualStyleBackColor = true;
            // 
            // btnStudentInfo
            // 
            this.btnStudentInfo.Location = new System.Drawing.Point(40, 339);
            this.btnStudentInfo.Name = "btnStudentInfo";
            this.btnStudentInfo.Size = new System.Drawing.Size(204, 40);
            this.btnStudentInfo.TabIndex = 12;
            this.btnStudentInfo.Text = "Student Info";
            this.btnStudentInfo.UseVisualStyleBackColor = true;
            this.btnStudentInfo.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnTeacherAssignments
            // 
            this.btnTeacherAssignments.Location = new System.Drawing.Point(40, 409);
            this.btnTeacherAssignments.Name = "btnTeacherAssignments";
            this.btnTeacherAssignments.Size = new System.Drawing.Size(204, 40);
            this.btnTeacherAssignments.TabIndex = 13;
            this.btnTeacherAssignments.Text = "Teacher Assignments";
            this.btnTeacherAssignments.UseVisualStyleBackColor = true;
            // 
            // lblSAS
            // 
            this.lblSAS.AutoSize = true;
            this.lblSAS.Location = new System.Drawing.Point(59, 23);
            this.lblSAS.Name = "lblSAS";
            this.lblSAS.Size = new System.Drawing.Size(177, 16);
            this.lblSAS.TabIndex = 14;
            this.lblSAS.Text = "Student Assessment System";
            // 
            // btnLogOut
            // 
            this.btnLogOut.Location = new System.Drawing.Point(858, 16);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(100, 32);
            this.btnLogOut.TabIndex = 14;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            // 
            // btnAcademicTerm
            // 
            this.btnAcademicTerm.Location = new System.Drawing.Point(40, 476);
            this.btnAcademicTerm.Name = "btnAcademicTerm";
            this.btnAcademicTerm.Size = new System.Drawing.Size(204, 40);
            this.btnAcademicTerm.TabIndex = 14;
            this.btnAcademicTerm.Text = "Academic Term Management";
            this.btnAcademicTerm.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(985, 963);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblUserAcc;
        private System.Windows.Forms.Label lblSubInfo;
        private System.Windows.Forms.Label lbldashboard;
        private System.Windows.Forms.Label lbltestassessment;
        private System.Windows.Forms.Label lbltestadmin;
        private System.Windows.Forms.Label lblScoreGrading;
        private System.Windows.Forms.Label lblItemAnalysis;
        private System.Windows.Forms.Label lblPerformance;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Button btnCourseSection;
        private System.Windows.Forms.Button btnSubjectCourse;
        private System.Windows.Forms.Button btnTeacherAssignments;
        private System.Windows.Forms.Button btnStudentInfo;
        private System.Windows.Forms.Label lblSAS;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnAcademicTerm;
    }
}

