﻿using Student_Assessment_System.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Module
{
    public  class Teacher : Employee
    {
        

    }
}
