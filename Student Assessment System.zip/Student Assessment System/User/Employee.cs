﻿using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.User
{
    public abstract class Employee
    {
        protected int Emp_ID;
        public string DepartmentaName { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string Address { get; set; }
        public DateTime Birthdate { get; set; }
        public string Gender { get; set; }
        public string Contact_number { get; set; }
        public string Email { get; set; }
       

        public void setEmp_ID(int Emp_ID)
        {
            this.Emp_ID = Emp_ID;
        }

        public int emp_ID
        {
            get { return Emp_ID; }
        }
        public string GetEmpFullname()
        {
            return $"{this.LastName}, {this.FirstName}";
        }
    }
}
