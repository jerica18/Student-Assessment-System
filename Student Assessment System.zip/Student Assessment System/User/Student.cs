﻿using Student_Assessment_System.Course___Subject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Module
{
    public class Student 
    {
        public int StudentID { get; set; }
        public int Section_ID { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string Address { get; set; }
        public DateTime Birthdate { get; set; }
        public string Gender { get; set; }
        public string Contact_number { get; set; }

        public string Email {  get; set; }
        

        public void setstudentID(int StudentID)
        {
            this.StudentID = StudentID;
        }

        public int studentID
        {
            get { return StudentID; }
        }
        public string GetStudentFullname()
        {
            return $"{this.LastName}, {this.FirstName}";
        }

    }

}
