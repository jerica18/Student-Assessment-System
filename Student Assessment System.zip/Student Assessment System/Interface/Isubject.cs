﻿using Student_Assessment_System.Course___Subject_infromation;
using Student_Assessment_System.Module;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Interface
{
    public interface Isubject
    {
        void SaveSubject(Subject e);
        Subject GetSubjectbyid(int SubjectId);

        void RemoveSubject(int SubjectId);
        void UpdateSubject(Subject e);

    }
}
