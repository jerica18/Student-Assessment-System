﻿using Student_Assessment_System.Module;
using Student_Assessment_System.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Assessment_System.Interface
{
    public interface ITerm
    {
        void SaveTerm(AcademicTermManagement e);
        AcademicTermManagement GetAcademicTermbyid(int TermID);

        void RemoveTerm(int TermID);
        void UpdateTerm(AcademicTermManagement e);
    }
}
